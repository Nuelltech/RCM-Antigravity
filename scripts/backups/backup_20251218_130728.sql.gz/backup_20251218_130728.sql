-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: rcm_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('cfdaf849-a0bd-4c2c-8f98-50ce0589fafb','a3b0f246928b7799b3fc171d59a8c706fd1da59f605fcf35b88953bbcf979b36','2025-11-24 16:55:22.261','20251124165519_add_combo_categorias',NULL,NULL,'2025-11-24 16:55:19.345',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alertas_ai`
--

DROP TABLE IF EXISTS `alertas_ai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alertas_ai` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_alerta` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `titulo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entidade_tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entidade_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `severidade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `acoes_sugeridas` json DEFAULT NULL,
  `dados_contexto` json DEFAULT NULL,
  `lido` tinyint(1) NOT NULL DEFAULT '0',
  `lido_por` int DEFAULT NULL,
  `data_leitura` datetime(3) DEFAULT NULL,
  `arquivado` tinyint(1) NOT NULL DEFAULT '0',
  `expira_em` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `alertas_ai_tenant_id_fkey` (`tenant_id`),
  CONSTRAINT `alertas_ai_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alertas_ai`
--

LOCK TABLES `alertas_ai` WRITE;
/*!40000 ALTER TABLE `alertas_ai` DISABLE KEYS */;
INSERT INTO `alertas_ai` VALUES (1,1,'9d456945-0f48-4930-8490-8f1fb5ed2453','cmv','Bife à Portuguesa','CMV muito alto (42.1%). Meta: <30%','MenuItem','1','high',NULL,'{\"value\": 42.14, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-02 11:33:14.242'),(2,1,'bb7e884d-fa30-46ad-8d81-fe78b2de34cb','cmv','Combo de bife à portuguesa -sopa- Prato- Agua -Sobremesa','CMV muito alto (39.8%). Meta: <30%','MenuItem','2','high',NULL,'{\"value\": 39.78, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-02 11:33:14.385'),(3,1,'4cae7008-2556-4a70-950e-8f7c824e9b9e','cost_increase','Alcatra','Ligeiro aumento de custo: +8.8%','HistoricoPreco','2','info',NULL,'{\"value\": 8.8, \"threshold\": 5}',0,NULL,NULL,0,NULL,'2025-12-02 11:33:14.421'),(4,1,'10549771-130e-42a1-b2ff-f4ebd74f43e1','cmv','Dourada Grelhada','CMV muito alto (48.8%). Meta: <30%','MenuItem','3','high',NULL,'{\"value\": 48.76, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-04 10:37:57.508'),(5,1,'f2bab3a2-f010-4209-801f-73ceef942a08','cmv','Copo 0,25L','CMV muito alto (37.6%). Meta: <30%','MenuItem','5','high',NULL,'{\"value\": 37.6, \"threshold\": 35}',0,NULL,NULL,1,NULL,'2025-12-04 10:37:57.517'),(6,1,'f31ac297-c9c9-4771-8039-aad10b67bb90','cmv','Dourada Grelhada - Sopa - Prato- Bebida','CMV muito alto (65.7%). Meta: <30%','MenuItem','6','high',NULL,'{\"value\": 65.65, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-04 10:37:57.528'),(7,1,'ce5b38ce-8d35-465d-a292-706d3aa15c46','inactivity','Vendas','Sem vendas registadas há 13 dias.','Venda','27','high',NULL,'{\"value\": 13, \"threshold\": 6}',0,NULL,NULL,0,NULL,'2025-12-09 11:01:37.441'),(8,1,'85559625-ef65-4b4a-932b-7e9700665a06','cmv','Pacheca Premium Douro Copo de 25 cl','CMV muito alto (68.8%). Meta: <30%','MenuItem','9','high',NULL,'{\"value\": 68.75, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-09 16:26:04.073'),(9,1,'6495340e-38ec-40a8-a605-8700d7de7074','cmv','Terras do Demo garrafa 75 cl','CMV muito alto (49.9%). Meta: <30%','MenuItem','10','high',NULL,'{\"value\": 49.94, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-09 18:02:09.157'),(10,1,'1c762ac0-447e-4fc8-93f0-737aaeb16625','cmv','Terras do Demo Copo de 25 cl','CMV muito alto (42.9%). Meta: <30%','MenuItem','11','high',NULL,'{\"value\": 42.86, \"threshold\": 35}',0,NULL,NULL,0,NULL,'2025-12-09 18:02:09.327'),(11,1,'2159ad63-87b8-40e3-9acb-666caf44d58a','stale_price','Lombo de Porco','Preço nunca atualizado.','Produto','9','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.713'),(12,1,'fbf66e9f-66e1-483e-9ded-65cab1fc3380','stale_price','Dourada','Preço nunca atualizado.','Produto','23','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.718'),(13,1,'6caf4ef3-92a4-44f3-a5a3-405c0425caf4','stale_price','Pescada','Preço nunca atualizado.','Produto','24','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.723'),(14,1,'90b9fc1b-f2f5-4d61-a469-d21e9adb84ae','stale_price','Cenoura','Preço nunca atualizado.','Produto','36','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.729'),(15,1,'8e0245d2-0892-4ee2-904c-bacaf7ba37a6','stale_price','Cebola','Preço nunca atualizado.','Produto','37','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.734'),(16,1,'740a8b2f-4980-4c15-b129-c5453a47138c','stale_price','Alho','Preço nunca atualizado.','Produto','38','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.740'),(17,1,'bf00dc46-3ab1-47d4-ade3-effdf471a9ad','stale_price','Tomate','Preço nunca atualizado.','Produto','44','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.747'),(18,1,'893c9b1f-8865-4479-a427-85720d3d44be','stale_price','Leite Integral','Preço nunca atualizado.','Produto','53','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.758'),(19,1,'d59fc59c-db72-4391-af2d-f5dc9212d01f','stale_price','Manteiga Com Sal','Preço nunca atualizado.','Produto','63','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.808'),(20,1,'702f1f1b-42fb-4a81-a22f-62c3e3f447e4','stale_price','Arroz','Preço nunca atualizado.','Produto','65','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.817'),(21,1,'61fb8910-6050-42d6-af14-9f73f7c118a2','stale_price','Farinha de Trigo','Preço nunca atualizado.','Produto','67','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.821'),(22,1,'01f52cf4-d702-4fde-bf51-9661dd5d72cb','stale_price','Azeite','Preço nunca atualizado.','Produto','69','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.826'),(23,1,'5f9980f5-032e-47d6-bdf0-d26d77b64556','stale_price','Óleo Vegetal','Preço nunca atualizado.','Produto','70','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.830'),(24,1,'7144496b-02ef-408c-9dcb-4c5304018b04','stale_price','Sal','Preço nunca atualizado.','Produto','71','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.835'),(25,1,'3db4355a-25ba-4b57-a4a3-3e2144ec1695','stale_price','Coca-Cola','Preço nunca atualizado.','Produto','79','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.839'),(26,1,'466e4565-62bc-4584-bd75-48e380be2a79','stale_price','Água com Gás','Preço nunca atualizado.','Produto','85','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.845'),(27,1,'d923c20f-ba4f-400f-bbce-fc3e27acd65e','stale_price','Vinho Tinto','Preço nunca atualizado.','Produto','86','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.849'),(28,1,'71ce48e6-e95c-4004-897c-d302b3bd23f7','stale_price','Vinho Branco','Preço nunca atualizado.','Produto','87','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.854'),(29,1,'9c498697-5487-4b4a-9e21-672800781345','stale_price','Banha','Preço nunca atualizado.','Produto','91','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.859'),(30,1,'e617f5c8-dfb2-4ee7-83b3-e1745dc260ed','stale_price','Pimentão-doce','Preço nunca atualizado.','Produto','92','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.864'),(31,1,'f909d6c6-9969-4754-a4d0-e90abaf8e5e0','stale_price','Louro (Folhas)','Preço nunca atualizado.','Produto','93','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.868'),(32,1,'03886040-b49b-4ecf-80e6-d58480843eec','stale_price','Pau de Canela','Preço nunca atualizado.','Produto','94','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.872'),(33,1,'02c55796-58dc-40b6-a46d-a7dc67f02151','stale_price','Feijão Vermelho','Preço nunca atualizado.','Produto','95','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.877'),(34,1,'c9367c6f-097f-4fbb-a0e2-aa3d47471f97','stale_price','Alho Francês','Preço nunca atualizado.','Produto','96','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.882'),(35,1,'8dbc22af-84df-4332-b5b4-09e01376432d','stale_price','Nabo','Preço nunca atualizado.','Produto','97','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.891'),(36,1,'c69bf610-4326-4224-8d27-8c7708ac103f','stale_price','Curgete','Preço nunca atualizado.','Produto','98','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,1,NULL,'2025-12-10 11:45:37.895'),(37,1,'ab83d0d9-0733-4f70-befd-458747dcd21d','stale_price','Couve Portuguesa','Preço nunca atualizado.','Produto','99','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.900'),(38,1,'38984387-e8f2-4e06-bcfb-e7d986110708','stale_price','Carnes Fumadas','Preço nunca atualizado.','Produto','100','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.906'),(39,1,'a435100e-364c-4742-a723-6528c3a9bcb1','stale_price','Linguiça','Preço nunca atualizado.','Produto','101','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.910'),(40,1,'bd9fbdfc-76a7-46ba-85cf-013b57f8d991','stale_price','Presunto','Preço nunca atualizado.','Produto','102','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.915'),(41,1,'3d664415-3038-40dd-b740-9994ca2b06e1','stale_price','Maisena','Preço nunca atualizado.','Produto','103','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.920'),(42,1,'185e16b2-dfb7-4ac1-8504-ae5f2d77ff88','stale_price','Vinho do Porto','Preço nunca atualizado.','Produto','104','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.925'),(43,1,'a183c64f-82fc-443c-9f66-0c05ae4f3759','stale_price','Chocolate Culinária','Preço nunca atualizado.','Produto','105','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.930'),(44,1,'d63ed59e-8637-43d1-9c05-7dbf661903ad','stale_price','Gelado Baunilha','Preço nunca atualizado.','Produto','106','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.933'),(45,1,'622e57f6-79f0-4a1a-9c65-b268569427ab','stale_price','Limão','Preço nunca atualizado.','Produto','107','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.937'),(46,1,'95a459be-0847-4b75-aa8d-bb2f54c5a2a8','stale_price','Salsa Fresca','Preço nunca atualizado.','Produto','108','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.941'),(47,1,'0686ef1c-d226-4e9d-8e8c-710235a53daf','stale_price','Malagueta','Preço nunca atualizado.','Produto','109','warning',NULL,'{\"value\": \"N/A\", \"threshold\": 30}',0,NULL,NULL,0,NULL,'2025-12-10 11:45:37.945'),(48,1,'760e9a87-38ef-47b6-ada5-4a29fe8f6d4f','cost_increase','Cerveja Super Bock','Aumento grave de custo: +51.5%','HistoricoPreco','11','high',NULL,'{\"value\": 51.52, \"threshold\": 5}',0,NULL,NULL,0,NULL,'2025-12-15 09:27:48.611'),(49,1,'641d4bdf-ff79-45d2-8872-cd50b135b14a','cost_increase','Cerveja Super Bock','Aumento grave de custo: +19.4%','HistoricoPreco','13','high',NULL,'{\"value\": 19.45, \"threshold\": 5}',0,NULL,NULL,0,NULL,'2025-12-15 14:58:14.454');
/*!40000 ALTER TABLE `alertas_ai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_log`
--

DROP TABLE IF EXISTS `audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `acao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `entidade_tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entidade_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dados_anteriores` json DEFAULT NULL,
  `dados_novos` json DEFAULT NULL,
  `ip_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultado` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `timestamp` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `audit_log_tenant_id_timestamp_idx` (`tenant_id`,`timestamp`),
  KEY `audit_log_user_id_fkey` (`user_id`),
  CONSTRAINT `audit_log_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `audit_log_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_log`
--

LOCK TABLES `audit_log` WRITE;
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combo_categoria_opcoes`
--

DROP TABLE IF EXISTS `combo_categoria_opcoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combo_categoria_opcoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `categoria_id` int NOT NULL,
  `receita_id` int DEFAULT NULL,
  `formato_venda_id` int DEFAULT NULL,
  `custo_unitario` decimal(10,4) NOT NULL,
  `ordem` int NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `combo_categoria_opcoes_tenant_id_fkey` (`tenant_id`),
  KEY `combo_categoria_opcoes_categoria_id_fkey` (`categoria_id`),
  KEY `combo_categoria_opcoes_receita_id_fkey` (`receita_id`),
  KEY `combo_categoria_opcoes_formato_venda_id_fkey` (`formato_venda_id`),
  CONSTRAINT `combo_categoria_opcoes_categoria_id_fkey` FOREIGN KEY (`categoria_id`) REFERENCES `combo_categorias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `combo_categoria_opcoes_formato_venda_id_fkey` FOREIGN KEY (`formato_venda_id`) REFERENCES `formatos_venda` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `combo_categoria_opcoes_receita_id_fkey` FOREIGN KEY (`receita_id`) REFERENCES `receitas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `combo_categoria_opcoes_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combo_categoria_opcoes`
--

LOCK TABLES `combo_categoria_opcoes` WRITE;
/*!40000 ALTER TABLE `combo_categoria_opcoes` DISABLE KEYS */;
INSERT INTO `combo_categoria_opcoes` VALUES (5,1,4,1,NULL,0.3799,0,'2025-12-04 16:41:59.955'),(6,1,5,6,NULL,6.3387,0,'2025-12-04 16:41:59.955'),(7,1,6,NULL,110,0.7500,0,'2025-12-04 16:41:59.955'),(8,1,6,NULL,82,2.8000,1,'2025-12-04 16:41:59.955'),(9,1,6,NULL,113,0.5000,2,'2025-12-04 16:41:59.955');
/*!40000 ALTER TABLE `combo_categoria_opcoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combo_categorias`
--

DROP TABLE IF EXISTS `combo_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combo_categorias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `combo_id` int NOT NULL,
  `categoria` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordem` int NOT NULL DEFAULT '0',
  `obrigatoria` tinyint(1) NOT NULL DEFAULT '1',
  `custo_max_calculado` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `combo_categorias_combo_id_categoria_key` (`combo_id`,`categoria`),
  KEY `combo_categorias_tenant_id_fkey` (`tenant_id`),
  CONSTRAINT `combo_categorias_combo_id_fkey` FOREIGN KEY (`combo_id`) REFERENCES `combos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `combo_categorias_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combo_categorias`
--

LOCK TABLES `combo_categorias` WRITE;
/*!40000 ALTER TABLE `combo_categorias` DISABLE KEYS */;
INSERT INTO `combo_categorias` VALUES (4,1,2,'Sopa',0,1,0.3799,'2025-12-04 16:41:59.955','2025-12-15 16:51:04.018'),(5,1,2,'Prato',1,1,6.3387,'2025-12-04 16:41:59.955','2025-12-15 16:51:04.010'),(6,1,2,'Bebida',2,1,2.8000,'2025-12-04 16:41:59.955','2025-12-15 16:51:04.001');
/*!40000 ALTER TABLE `combo_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combo_itens`
--

DROP TABLE IF EXISTS `combo_itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combo_itens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `combo_id` int NOT NULL,
  `receita_id` int DEFAULT NULL,
  `produto_id` int DEFAULT NULL,
  `quantidade` decimal(10,4) NOT NULL,
  `custo_unitario` decimal(10,4) NOT NULL,
  `custo_total` decimal(10,4) NOT NULL,
  `ordem` int NOT NULL DEFAULT '0',
  `observacoes` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `combo_itens_tenant_id_fkey` (`tenant_id`),
  KEY `combo_itens_combo_id_fkey` (`combo_id`),
  KEY `combo_itens_receita_id_idx` (`receita_id`),
  KEY `combo_itens_produto_id_idx` (`produto_id`),
  CONSTRAINT `combo_itens_combo_id_fkey` FOREIGN KEY (`combo_id`) REFERENCES `combos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `combo_itens_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `combo_itens_receita_id_fkey` FOREIGN KEY (`receita_id`) REFERENCES `receitas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `combo_itens_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combo_itens`
--

LOCK TABLES `combo_itens` WRITE;
/*!40000 ALTER TABLE `combo_itens` DISABLE KEYS */;
INSERT INTO `combo_itens` VALUES (1,1,1,5,NULL,1.0000,4.0034,4.0034,0,NULL),(2,1,1,NULL,85,1.0000,0.6500,0.6500,1,NULL),(3,1,1,8,NULL,1.0000,0.1383,0.1383,2,NULL),(4,1,1,1,NULL,1.0000,0.3799,0.3799,3,NULL);
/*!40000 ALTER TABLE `combo_itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combos`
--

DROP TABLE IF EXISTS `combos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Simples',
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `imagem_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custo_total` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `combos_tenant_id_nome_key` (`tenant_id`,`nome`),
  CONSTRAINT `combos_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combos`
--

LOCK TABLES `combos` WRITE;
/*!40000 ALTER TABLE `combos` DISABLE KEYS */;
INSERT INTO `combos` VALUES (1,1,'3903a079-3f83-48a9-92de-c7afb11793cb','Combo de bife à portuguesa -sopa- Prato- Agua -Sobremesa','Complexo','sopa- Prato- Agua -Sobremesa , so n tem cafe e espirituosas. A agua coloquei a mais cara. ',NULL,5.1716,1,'2025-11-24 18:13:04.308','2025-12-15 16:51:04.001'),(2,1,'58ca79a0-065d-4b21-8b5f-903c5824b78d','Dourada Grelhada - Sopa - Prato- Bebida','Simples',NULL,NULL,9.5186,1,'2025-12-01 18:28:55.380','2025-12-15 16:51:04.023');
/*!40000 ALTER TABLE `combos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_compra` datetime(3) NOT NULL,
  `variacao_produto_id` int NOT NULL,
  `quantidade_comprada` decimal(10,4) NOT NULL,
  `preco_unitario` decimal(10,4) NOT NULL,
  `preco_total` decimal(10,2) NOT NULL,
  `fornecedor` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_fatura` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metodo_entrada` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `documento_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validado` tinyint(1) NOT NULL DEFAULT '1',
  `data_validacao` datetime(3) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `fatura_importacao_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compras_tenant_id_fkey` (`tenant_id`),
  KEY `compras_variacao_produto_id_fkey` (`variacao_produto_id`),
  KEY `compras_user_id_fkey` (`user_id`),
  KEY `compras_fatura_importacao_id_fkey` (`fatura_importacao_id`),
  CONSTRAINT `compras_fatura_importacao_id_fkey` FOREIGN KEY (`fatura_importacao_id`) REFERENCES `faturas_importacao` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `compras_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `compras_variacao_produto_id_fkey` FOREIGN KEY (`variacao_produto_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras_faturas`
--

DROP TABLE IF EXISTS `compras_faturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras_faturas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fornecedor_nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fornecedor_nif` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_fatura` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_fatura` datetime(3) NOT NULL,
  `total_sem_iva` decimal(10,2) NOT NULL,
  `total_iva` decimal(10,2) NOT NULL,
  `total_com_iva` decimal(10,2) NOT NULL,
  `metodo_entrada` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `documento_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fatura_importacao_id` int DEFAULT NULL,
  `validado` tinyint(1) NOT NULL DEFAULT '0',
  `data_validacao` datetime(3) DEFAULT NULL,
  `validado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compras_faturas_tenant_id_fkey` (`tenant_id`),
  KEY `compras_faturas_validado_por_fkey` (`validado_por`),
  KEY `compras_faturas_fatura_importacao_id_fkey` (`fatura_importacao_id`),
  CONSTRAINT `compras_faturas_fatura_importacao_id_fkey` FOREIGN KEY (`fatura_importacao_id`) REFERENCES `faturas_importacao` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `compras_faturas_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_faturas_validado_por_fkey` FOREIGN KEY (`validado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras_faturas`
--

LOCK TABLES `compras_faturas` WRITE;
/*!40000 ALTER TABLE `compras_faturas` DISABLE KEYS */;
INSERT INTO `compras_faturas` VALUES (1,1,'d43aa1b5-1efb-42a0-a67b-8cec9e9de7dd','Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'OCR','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765545010997.jpg',14,0,NULL,NULL,'2025-12-12 15:12:49.294','2025-12-12 15:12:49.294'),(2,1,'d5624ea8-821c-4e3b-860c-b393bf2a4bff','FRUTAS PEDRO CRUZ LDA','510885837','PT 25/26326','2025-11-11 00:00:00.000',67.75,3.44,71.19,'OCR','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_5_1765815015470.jpg',17,0,NULL,NULL,'2025-12-15 16:22:28.048','2025-12-15 16:22:28.048'),(3,1,'556b2cf1-6ad0-4e77-bb7e-5957d843eac6','FRUTAS PEDRO CRUZ LDA','510885837','PT 25/26326','2025-11-11 00:00:00.000',67.75,3.44,71.19,'OCR','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_5_1765817359898.jpg',19,0,NULL,NULL,'2025-12-15 16:51:03.865','2025-12-15 16:51:03.865');
/*!40000 ALTER TABLE `compras_faturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras_itens`
--

DROP TABLE IF EXISTS `compras_itens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras_itens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `compra_fatura_id` int NOT NULL,
  `produto_id` int NOT NULL,
  `variacao_id` int DEFAULT NULL,
  `descricao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` decimal(10,4) NOT NULL,
  `unidade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco_unitario` decimal(10,4) NOT NULL,
  `preco_total` decimal(10,2) NOT NULL,
  `iva_percentual` decimal(5,2) DEFAULT NULL,
  `iva_valor` decimal(10,2) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `compras_itens_tenant_id_fkey` (`tenant_id`),
  KEY `compras_itens_compra_fatura_id_fkey` (`compra_fatura_id`),
  KEY `compras_itens_produto_id_fkey` (`produto_id`),
  KEY `compras_itens_variacao_id_fkey` (`variacao_id`),
  CONSTRAINT `compras_itens_compra_fatura_id_fkey` FOREIGN KEY (`compra_fatura_id`) REFERENCES `compras_faturas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_itens_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_itens_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_itens_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras_itens`
--

LOCK TABLES `compras_itens` WRITE;
/*!40000 ALTER TABLE `compras_itens` DISABLE KEYS */;
INSERT INTO `compras_itens` VALUES (1,1,1,113,115,'BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.0000,'KG',7.3500,29.40,23.00,6.76,'2025-12-12 15:12:49.362','2025-12-12 15:12:49.362'),(2,1,1,114,116,'CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.0000,'KG',7.2500,14.50,23.00,3.34,'2025-12-12 15:12:49.436','2025-12-12 15:12:49.436'),(3,1,1,115,117,'CAPRICHOS ALASKA Kg NOS',2.0000,'UN',6.3500,12.70,23.00,2.92,'2025-12-12 15:12:49.444','2025-12-12 15:12:49.444'),(4,1,1,116,118,'CHOCO LP 2/4 AV E/O',10.0000,'KG',5.9500,59.50,6.00,3.57,'2025-12-12 15:12:49.452','2025-12-12 15:12:49.452'),(5,1,1,117,119,'M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.0000,'UN',8.5000,85.00,23.00,19.55,'2025-12-12 15:12:49.460','2025-12-12 15:12:49.460'),(6,1,1,118,120,'PASTEIS BACALHAU SC 20un CATERING',6.0000,'UN',2.7500,16.50,23.00,3.80,'2025-12-12 15:12:49.467','2025-12-12 15:12:49.467'),(7,1,1,119,121,'POLVO ROTO cx 2 x 7,5kg E/O',15.0000,'KG',9.5000,142.50,6.00,8.55,'2025-12-12 15:12:49.475','2025-12-12 15:12:49.475'),(8,1,1,120,122,'SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.0000,'KG',3.5500,35.50,23.00,8.17,'2025-12-12 15:12:49.481','2025-12-12 15:12:49.481'),(9,1,2,44,44,'TOMATE GR CAT II PORTUGAL',25.3000,'KG',0.8900,22.52,6.00,1.35,'2025-12-15 16:22:28.184','2025-12-15 16:22:28.184'),(10,1,2,40,40,'ALFACE FRISADA CAT II PORTUGAL',6.7000,'KG',0.9900,6.63,6.00,0.40,'2025-12-15 16:22:28.273','2025-12-15 16:22:28.273'),(11,1,2,36,36,'CENOURA CAT I ESPANHA',10.0000,'KG',0.6400,6.40,6.00,0.38,'2025-12-15 16:22:28.282','2025-12-15 16:22:28.282'),(12,1,2,45,45,'PIMENTO VERMELHO CAT II PAISES BAIXOS',6.5000,'KG',2.4400,15.86,6.00,0.95,'2025-12-15 16:22:28.339','2025-12-15 16:22:28.339'),(13,1,3,98,98,'CORGETS CAT II PORTUGAL MARROCOS',5.9000,'KG',0.9900,5.84,6.00,0.35,'2025-12-15 16:51:03.887','2025-12-15 16:51:03.887'),(14,1,3,44,44,'TOMATE GR CAT II PORTUGAL',25.3000,'KG',0.8900,22.52,6.00,1.35,'2025-12-15 16:51:03.909','2025-12-15 16:51:03.909'),(15,1,3,40,40,'ALFACE FRISADA CAT II PORTUGAL',6.7000,'KG',0.9900,6.63,6.00,0.40,'2025-12-15 16:51:03.925','2025-12-15 16:51:03.925'),(16,1,3,36,36,'CENOURA CAT I ESPANHA',10.0000,'G',0.6400,6.40,6.00,0.38,'2025-12-15 16:51:03.932','2025-12-15 16:51:03.932'),(17,1,3,45,45,'PIMENTO VERMELHO CAT II PAISES BAIXOS',6.5000,'KG',2.4400,15.86,6.00,0.95,'2025-12-15 16:51:03.948','2025-12-15 16:51:03.948');
/*!40000 ALTER TABLE `compras_itens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras_temporarias`
--

DROP TABLE IF EXISTS `compras_temporarias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras_temporarias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `sessao_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `produto_reconhecido` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `variacao_id` int DEFAULT NULL,
  `quantidade` decimal(10,4) DEFAULT NULL,
  `preco_unitario` decimal(10,4) DEFAULT NULL,
  `preco_total` decimal(10,2) DEFAULT NULL,
  `fornecedor` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_compra` datetime(3) DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pendente',
  `confianca_ocr` int DEFAULT NULL,
  `dados_ocr_raw` json DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `compras_temporarias_tenant_id_fkey` (`tenant_id`),
  KEY `compras_temporarias_variacao_id_fkey` (`variacao_id`),
  KEY `compras_temporarias_user_id_fkey` (`user_id`),
  CONSTRAINT `compras_temporarias_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `compras_temporarias_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `compras_temporarias_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras_temporarias`
--

LOCK TABLES `compras_temporarias` WRITE;
/*!40000 ALTER TABLE `compras_temporarias` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras_temporarias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conversas_ai`
--

DROP TABLE IF EXISTS `conversas_ai`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conversas_ai` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `user_id` int NOT NULL,
  `sessao_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mensagem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokens_usados` int DEFAULT NULL,
  `contexto_adicional` json DEFAULT NULL,
  `timestamp` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `conversas_ai_tenant_id_fkey` (`tenant_id`),
  KEY `conversas_ai_user_id_fkey` (`user_id`),
  CONSTRAINT `conversas_ai_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `conversas_ai_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conversas_ai`
--

LOCK TABLES `conversas_ai` WRITE;
/*!40000 ALTER TABLE `conversas_ai` DISABLE KEYS */;
/*!40000 ALTER TABLE `conversas_ai` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custos_estrutura`
--

DROP TABLE IF EXISTS `custos_estrutura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custos_estrutura` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `classificacao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_mensal` decimal(10,2) NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custos_estrutura_tenant_id_ativo_idx` (`tenant_id`,`ativo`),
  CONSTRAINT `custos_estrutura_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custos_estrutura`
--

LOCK TABLES `custos_estrutura` WRITE;
/*!40000 ALTER TABLE `custos_estrutura` DISABLE KEYS */;
INSERT INTO `custos_estrutura` VALUES (1,1,'353f4aed-c6ce-4fab-9e86-f71565f2fecf','Salario chef','Salário',1300.00,1,'2025-12-01 15:18:45.905','2025-12-01 15:18:45.905'),(2,1,'7a7d9e9f-4be9-4589-b9ff-458aa92494bd','salario ajudante cozinha','Salário',900.00,1,'2025-12-01 15:19:09.678','2025-12-01 15:19:09.678'),(3,1,'c1be896e-2306-4ba3-b271-8847bd6d44f0','Salario ajudante cozinha 2','Salário',950.00,1,'2025-12-01 15:19:47.952','2025-12-01 15:19:47.952'),(4,1,'41efaeca-7a3a-49fc-bc20-b73c0c2e28c3','Luz','Eletricidade',1500.00,1,'2025-12-01 15:20:12.309','2025-12-01 15:20:12.309'),(5,1,'d8ffa405-71ad-40e8-a8e7-b0eb7e5a4bed','Agua','Água',700.00,1,'2025-12-01 15:20:33.711','2025-12-01 15:20:33.711'),(6,1,'d79b17d9-7163-4dc0-bc45-86c9680fbb29','marketing','Marketing',500.00,1,'2025-12-01 15:20:56.742','2025-12-01 15:20:56.742'),(7,1,'dec585e6-e283-4599-a10c-8faa03a147a6','POS','Sistemas',300.00,1,'2025-12-01 15:21:15.879','2025-12-01 15:21:15.879'),(8,1,'d2615fe5-748b-4957-8529-b96f2623b99b','Renda do Restaurante','Renda',1200.00,1,'2025-12-01 15:21:40.671','2025-12-01 15:21:40.671'),(9,1,'56f6df65-c71f-4869-b2d0-4d2f25f66884','Contabilista','Contabilidade',200.00,1,'2025-12-01 15:22:01.320','2025-12-01 15:22:01.320'),(10,1,'22b65b8a-e93f-4b9e-85b6-58262689ba4d','MEO','Internet',60.00,1,'2025-12-01 15:22:15.848','2025-12-01 15:22:15.848'),(11,1,'60aec65f-1f9b-49ca-8bac-7032496fc136','Empregado de mesa 1','Salário',950.00,1,'2025-12-01 15:22:53.097','2025-12-01 15:22:53.097'),(12,1,'90d0b14b-d511-4ca9-9ea8-ea10903709fc','Empregado de Mesa 2','Salário',970.00,1,'2025-12-01 15:23:11.160','2025-12-01 15:23:11.160');
/*!40000 ALTER TABLE `custos_estrutura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dados_restaurante`
--

DROP TABLE IF EXISTS `dados_restaurante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dados_restaurante` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `numero_lugares` int NOT NULL DEFAULT '0',
  `horas_trabalho_dia` decimal(4,2) NOT NULL DEFAULT '8.00',
  `dias_trabalho_semana` decimal(3,1) NOT NULL DEFAULT '5.0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `alerta_aumento_custo_grave` decimal(5,2) NOT NULL DEFAULT '15.00',
  `alerta_aumento_custo_leve` decimal(5,2) NOT NULL DEFAULT '5.00',
  `alerta_aumento_custo_medio` decimal(5,2) NOT NULL DEFAULT '10.00',
  `alerta_inatividade_grave` int NOT NULL DEFAULT '10',
  `alerta_inatividade_leve` int NOT NULL DEFAULT '3',
  `alerta_inatividade_medio` int NOT NULL DEFAULT '6',
  `cmv_alerta_amarelo` decimal(5,2) NOT NULL DEFAULT '30.00',
  `cmv_alerta_vermelho` decimal(5,2) NOT NULL DEFAULT '35.00',
  `dias_alerta_preco_estagnado` int NOT NULL DEFAULT '30',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dados_restaurante_tenant_id_key` (`tenant_id`),
  CONSTRAINT `dados_restaurante_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dados_restaurante`
--

LOCK TABLES `dados_restaurante` WRITE;
/*!40000 ALTER TABLE `dados_restaurante` DISABLE KEYS */;
INSERT INTO `dados_restaurante` VALUES (1,1,140,8.00,6.0,'2025-12-01 15:14:17.030','2025-12-04 21:29:55.486',15.00,5.00,10.00,10,3,6,30.00,35.00,30),(2,2,0,8.00,5.0,'2025-12-04 17:54:11.603','2025-12-04 17:54:11.603',15.00,5.00,10.00,10,3,6,30.00,35.00,30);
/*!40000 ALTER TABLE `dados_restaurante` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapas_receita`
--

DROP TABLE IF EXISTS `etapas_receita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `etapas_receita` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `receita_id` int NOT NULL,
  `numero_etapa` int NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempo_estimado` int DEFAULT NULL,
  `temperatura` int DEFAULT NULL,
  `equipamento` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `etapas_receita_receita_id_numero_etapa_key` (`receita_id`,`numero_etapa`),
  KEY `etapas_receita_tenant_id_fkey` (`tenant_id`),
  CONSTRAINT `etapas_receita_receita_id_fkey` FOREIGN KEY (`receita_id`) REFERENCES `receitas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `etapas_receita_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapas_receita`
--

LOCK TABLES `etapas_receita` WRITE;
/*!40000 ALTER TABLE `etapas_receita` DISABLE KEYS */;
INSERT INTO `etapas_receita` VALUES (1,1,1,1,'Lave, descasque, pese os ingredientes brutos e prepare os legumes até alcançar as quantidades líquidas necessárias.',NULL,NULL,NULL),(2,1,1,2,'Coza legumes em água com sal, triture, junte couve, coza mais e finalize com azeite.',NULL,NULL,NULL),(3,1,2,1,'Pese carne limpa ou limpe e pese a quantidade líquida após descontar ossos/gorduras.',NULL,NULL,NULL),(4,1,2,2,'Tempere e asse com acompanhamentos, controlando perdas ao final do procedimento.',NULL,NULL,NULL),(7,1,4,1,'Prepare os ingredientes considerando o rendimento final esperado ao limpar e processar.',NULL,NULL,NULL),(8,1,4,2,'Coza e refogue como indicado.',NULL,NULL,NULL),(11,1,6,1,'Limpe peixe (retire vísceras e barbatanas).',NULL,NULL,NULL),(12,1,6,2,'Proceda normalmente.',NULL,NULL,NULL),(13,1,7,1,'Filete peixe fresco ou pese já limpo como base líquida.',NULL,NULL,NULL),(14,1,7,2,'Proceda normalmente.',NULL,NULL,NULL),(16,1,5,1,'Retire excessos/gorduras dos bifes (quantidade final líquida).',NULL,NULL,NULL),(17,1,5,2,'Proceda normalmente.',NULL,NULL,NULL),(18,1,3,1,'Todos os ingredientes medidos em bruto igual à líquida (sem preparação extra).',NULL,NULL,NULL),(19,1,3,2,'Cozinhar normalmente.',NULL,NULL,NULL),(26,1,8,1,'Separe gemas (peso líquido), pese canela/casca já limpa.',NULL,NULL,NULL);
/*!40000 ALTER TABLE `etapas_receita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `familias`
--

DROP TABLE IF EXISTS `familias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `familias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem` int NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `familias_tenant_id_nome_key` (`tenant_id`,`nome`),
  CONSTRAINT `familias_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `familias`
--

LOCK TABLES `familias` WRITE;
/*!40000 ALTER TABLE `familias` DISABLE KEYS */;
INSERT INTO `familias` VALUES (1,1,'37679449-fe48-470a-a917-01444b29f63d','Carnes','CAR',NULL,NULL,0,1,'2025-11-24 16:55:26.123','2025-11-24 16:55:26.123'),(2,1,'d16bb3eb-d528-4281-9ce9-a3311ff08026','Peixes e Mariscos','PEI',NULL,NULL,0,1,'2025-11-24 16:55:26.127','2025-11-24 16:55:26.127'),(3,1,'bf0c98c6-d911-4f89-8b12-568cbe132fb1','Legumes e Verduras','LEG',NULL,NULL,0,1,'2025-11-24 16:55:26.134','2025-11-24 16:55:26.134'),(4,1,'33ef3965-a5a9-4aa0-bc45-63a91ee9b873','Frutas','FRU',NULL,NULL,0,1,'2025-11-24 16:55:26.139','2025-11-24 16:55:26.139'),(5,1,'183c0ba4-6875-498a-b3e5-0ecc6336266d','Mercearia Seca','MER',NULL,NULL,0,1,'2025-11-24 16:55:26.145','2025-11-24 16:55:26.145'),(6,1,'fd300a9e-2ce3-4a53-af42-7095f5e0cc4d','Temperos e Condimentos','TEM',NULL,NULL,0,1,'2025-11-24 16:55:26.150','2025-11-24 16:55:26.150'),(7,1,'414a7792-dbec-4f7c-a3b4-4de55718cad8','Laticínios e Ovos','LAT',NULL,NULL,0,1,'2025-11-24 16:55:26.156','2025-11-24 16:55:26.156'),(8,1,'6b62591b-36cb-4d34-b6ea-d87a275789fc','Óleos e Gorduras','OLE',NULL,NULL,0,1,'2025-11-24 16:55:26.164','2025-11-24 16:55:26.164'),(9,1,'3d4957cd-57c1-4ace-a1c5-c3067eeb8517','Enlatados e Conservas','ENL',NULL,NULL,0,1,'2025-11-24 16:55:26.171','2025-11-24 16:55:26.171'),(10,1,'7bd24c9c-8a28-4e1a-a3da-c5b37791c195','Padaria e Pastelaria','PAD',NULL,NULL,0,1,'2025-11-24 16:55:26.179','2025-11-24 16:55:26.179'),(11,1,'06b3093a-36ed-42ba-aba4-043bcd9f1764','Pré-preparados de Cozinha','PRE',NULL,NULL,0,1,'2025-11-24 16:55:26.194','2025-11-24 16:55:26.194'),(12,1,'1b4c6127-eb0b-4e7b-ae45-d7e1784a09f3','Diversos','DIV',NULL,NULL,0,1,'2025-11-24 16:55:26.202','2025-11-24 16:55:26.202'),(13,1,'293bc9f3-c4f0-4d09-8f55-91728172dc6f','Despensa','DES',NULL,NULL,0,1,'2025-11-24 17:06:04.206','2025-11-24 17:06:04.206'),(14,1,'3f40043f-d8d3-4e36-afa3-a12f1deb3bd3','Bebidas','BEB',NULL,NULL,0,1,'2025-11-24 17:06:04.443','2025-11-24 17:06:04.443'),(15,2,'ab09707b-cd18-4391-acae-b59d124f982d','Carnes','CAR',NULL,NULL,0,1,'2025-11-27 16:52:28.556','2025-11-27 16:52:28.556'),(16,2,'1c17155f-2f55-410f-a25a-6c83deff511f','Peixes e Mariscos','PEI',NULL,NULL,0,1,'2025-11-27 16:52:28.559','2025-11-27 16:52:28.559'),(17,2,'6da864fe-2628-4873-a82b-02c35f95d6e9','Legumes e Verduras','LEG',NULL,NULL,0,1,'2025-11-27 16:52:28.561','2025-11-27 16:52:28.561'),(18,2,'f8b35a03-44f0-453e-8604-20c668d572b4','Frutas','FRU',NULL,NULL,0,1,'2025-11-27 16:52:28.563','2025-11-27 16:52:28.563'),(19,2,'6faee5be-95fb-43d3-9875-4586f0de9296','Mercearia Seca','MER',NULL,NULL,0,1,'2025-11-27 16:52:28.566','2025-11-27 16:52:28.566'),(20,2,'81f30089-2e7b-4ad2-88ba-266c561e16c2','Temperos e Condimentos','TEM',NULL,NULL,0,1,'2025-11-27 16:52:28.568','2025-11-27 16:52:28.568'),(21,2,'baace8da-6e48-406c-af03-1074c0b37073','Laticínios e Ovos','LAT',NULL,NULL,0,1,'2025-11-27 16:52:28.569','2025-11-27 16:52:28.569'),(22,2,'208fa2ca-b2b9-47e1-a6bc-3ed08c9706ce','Óleos e Gorduras','OLE',NULL,NULL,0,1,'2025-11-27 16:52:28.571','2025-11-27 16:52:28.571'),(23,2,'b0e791f0-0659-4c5e-96ad-d51a2f462afe','Enlatados e Conservas','ENL',NULL,NULL,0,1,'2025-11-27 16:52:28.573','2025-11-27 16:52:28.573'),(24,2,'855f9f63-5787-4a0b-94c9-c1a9889f2407','Padaria e Pastelaria','PAD',NULL,NULL,0,1,'2025-11-27 16:52:28.575','2025-11-27 16:52:28.575'),(25,2,'ea8f1068-c9ba-4e74-963c-ec04e44b843a','Pré-preparados de Cozinha','PRE',NULL,NULL,0,1,'2025-11-27 16:52:28.577','2025-11-27 16:52:28.577'),(26,2,'a97868a0-5603-4e73-b320-3de81d7b6f36','Diversos','DIV',NULL,NULL,0,1,'2025-11-27 16:52:28.578','2025-11-27 16:52:28.578');
/*!40000 ALTER TABLE `familias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faturas_importacao`
--

DROP TABLE IF EXISTS `faturas_importacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faturas_importacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `fornecedor_nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fornecedor_nif` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_fatura` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_fatura` datetime(3) DEFAULT NULL,
  `total_sem_iva` decimal(10,2) DEFAULT NULL,
  `total_iva` decimal(10,2) DEFAULT NULL,
  `total_com_iva` decimal(10,2) DEFAULT NULL,
  `ficheiro_nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ficheiro_tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ocr_texto_bruto` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ocr_metadata` json DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `erro_mensagem` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `processado_em` datetime(3) DEFAULT NULL,
  `aprovado_em` datetime(3) DEFAULT NULL,
  `aprovado_por` int DEFAULT NULL,
  `ficheiro_paths` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faturas_importacao_tenant_id_status_idx` (`tenant_id`,`status`),
  KEY `faturas_importacao_tenant_id_data_fatura_idx` (`tenant_id`,`data_fatura`),
  CONSTRAINT `faturas_importacao_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faturas_importacao`
--

LOCK TABLES `faturas_importacao` WRITE;
/*!40000 ALTER TABLE `faturas_importacao` DISABLE KEYS */;
INSERT INTO `faturas_importacao` VALUES (1,1,'INDUSTRIA DE CONGELADOS','518634108','FABIO',NULL,NULL,56.65,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765474687490.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765474687490.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected','\nInvalid `prisma.faturaLinhaImportacao.create()` invocation in\n/workspaces/RCM-Antigravity/backend/src/modules/invoices/invoices.module.ts:366:48\n\n  363     parsed.header.fornecedorNome\n  364 );\n  365 \n→ 366 await prisma.faturaLinhaImportacao.create(\nValue out of range for the type. Out of range value for column \'preco_total\' at row 1','2025-12-11 17:38:07.501','2025-12-11 17:49:42.239','2025-12-11 17:49:42.237',NULL,NULL,NULL),(2,1,'INDUSTRIA DE CONGELADOS','518634108','FABIO',NULL,NULL,56.65,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765475766667.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765475766667.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 17:56:06.668','2025-12-11 18:04:58.350','2025-12-11 18:04:58.349',NULL,NULL,NULL),(3,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765478536061.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765478536061.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 18:42:16.063','2025-12-11 18:50:16.391','2025-12-11 18:50:16.389',NULL,NULL,NULL),(4,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765479028338.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765479028338.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 18:50:28.339','2025-12-11 18:54:44.473','2025-12-11 18:54:44.470',NULL,NULL,NULL),(5,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765479295959.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765479295959.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 18:54:55.964','2025-12-11 19:04:45.305','2025-12-11 19:04:45.302',NULL,NULL,NULL),(6,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765479900503.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765479900503.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 19:05:00.505','2025-12-11 19:08:04.978','2025-12-11 19:08:04.975',NULL,NULL,NULL),(7,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_3_1765480096125.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765480096125.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 19:08:16.126','2025-12-11 19:28:16.157','2025-12-11 19:28:16.153',NULL,NULL,NULL),(8,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765481307375.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765481307375.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-11 19:28:27.376','2025-12-12 11:20:12.150','2025-12-12 11:20:12.146',NULL,NULL,NULL),(9,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765538461479.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765538461479.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-12 11:21:01.481','2025-12-12 11:37:07.981','2025-12-12 11:37:07.978',NULL,NULL,NULL),(10,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765539441044.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765539441044.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-12 11:37:21.045','2025-12-12 12:03:47.687','2025-12-12 12:03:47.685',NULL,NULL,NULL),(11,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765541042876.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765541042876.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-12 12:04:02.877','2025-12-12 12:46:08.934','2025-12-12 12:46:08.931',NULL,NULL,NULL),(12,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765543587339.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765543587339.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-12 12:46:27.341','2025-12-12 13:03:18.792','2025-12-12 13:03:18.789',NULL,NULL,NULL),(13,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765544613824.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765544613824.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','rejected',NULL,'2025-12-12 13:03:33.826','2025-12-12 15:52:41.776','2025-12-12 15:52:41.774',NULL,NULL,NULL),(14,1,'Coelho & Dias, S.A.','501122583','FTV 25001/070673','2025-11-11 00:00:00.000',395.60,56.65,452.25,'Compras_Restaurante_Alambique_exemplo_3_1765545010997.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_3_1765545010997.jpg','jpeg','Coelho & Dias. SA\nINDUSTRIA DE CONGELADOS\nCoelho & Dias, S.A.\nSede: PASCOAL, 3515-221 VISEU\nTel: 232 459 001/232 459 878/232 451 211\nFax: 232 451 726\nEmail: geral@coelhoedias.pt\nNIPC: 501 122 583\nProdutor/Embalador n.\" PT01104280\nCE\nBAP\n(0045 02P) (Roos1 02 217CE\nFal: Zona Industrial de Constantim-5000-082 Constantim-Vila Real Tel: 250 336 815-Fax 259 336 989\nFilial: Zona Industrial R. Belmiro Mendes Oliveira Lt6e7-4000-134-Guimarães Tel: 253 553 600\nChamadas pars a rede fixa nacional\nIBAN: PT50 0033 0000 0002 3604 95105/IBAN: PT50 0033 0000 0548 0539 63331\nATCUD JJ64YTB-070673\nORIGINAL\nPAG.\n16\nSUPREME CHICHEN ACT.HOTELEIRAS, Unip.,\nALAMBIQUE CAFE RESTAURANTE\nESTRADA NACIONAL N2\nSOCIAL 4.000.000,00 EUROS-CONSERVATÓRIA REG. COM. DE VISEU MAT. N°1058 Cerrificado Comercial nº 2831212006\n3460-321\nTONDELA\nNIF: 518634108\nCliente: C090303\nVendedor: V018\nDATA\n2025-11-11 16:59\nPRODUTO\nDATA VENC\n2025-11-11\nCOND. PAGAMENTO\nPronto Pagamento\nVENDEDOR\nZONA\nFATURA\nFABIO RODRIGUES\n09\nFTV 25001/070673\nLOTE\nQNT. UNID\nIVA\nPREÇO\nDESC.\nVALOR\nIPSV 006/001113.019 de 2025-11-11\n235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG\n261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova\n26371 CAPRICHOS ALASKA Kg NOS\n20703 CHOCO LP 2/4 AV E/O\n263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA\n256461 PASTEIS BACALHAU SC 20un CATERING\n033967 POLVO ROTO cx 2 x 7,5kg E/O\n0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND\n01138622\n4,000 KG 23%\n7,350\n29,40\nPR1125\nSN17\n2,000 KG\n2,000 UN\n23%\n7,250\n14,50\n23%\n6,350\n12,70\n4E20\n10,000 KG 6%\n5,950\n59,50\n4M15\n10,000 UN\n23%\n8,500\n85,00\n307050925\n6,000 UN 23%\n2,750\n16,50\n250408\n15,000 KG 6%\n9,500\n142,50\n53708864\n10,000 KG 23%\n3,550\n35,50\nCARGA\n2025-11-11 17:04\nDESCARGA\n2025-11-15\n23:59\nIVA\nRESUMO\nPASCOAL\nS/N°\nALAMBIQUE CAFE\nRESTAURANTE\nVal.\nTaxa\nVal. IVA\nValor\n3515-221 VISEU\nESTRADA NACIONAL N2\n3460-321 TONDELA\nN/Viatura\nom5X-Emitido por programa certificado n. 445/AT || N.° Único FT FTV.25001/070673\nOs artigos facturados foram colocados à disposição do adquirente na data do documento.\nA responsabilidade pela gestão de todos os residuos de embalagens fol transferido para a\nSoc.Ponto Verde\nMais informações incluido os valores das prestações financeiras fixadas a favor daquelas\n193,60\nPT 23%\n44,53\nValor Desc.\n395,60\n0,00\n202,00\nPT 6%\n12,12\nTotal IVA\n56,65\nTOTAL EUR\n452,25\nDireto da Universidade de Lisboa, Campus de Campolide 1009-002 LISBOA Emat nace un\nde Centro de Resolucio alternativa de tigios de consumos: CNIACC-Centro Nacional de informação Abgem de Conde de','{\"pages\": 1, \"confidence\": 0.9429102242696648}','approved',NULL,'2025-12-12 13:10:10.999','2025-12-12 15:12:49.488','2025-12-12 15:12:49.487','2025-12-12 15:12:49.487',1,NULL),(15,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_1_1765554779001.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_1_1765554779001.jpg','jpeg','AM. Distribuição\nAntero Marques Loureiro\'\nParque Industrial Adiça, Lt 32\n3460-321 TONDELA | amldistribuicao@gmail.com\nTel 232 816 583 [chamada para a rede fixa nacional]\nNIF 149 459 459\nIBAN PT50 0045 3182 4003 3689 0188 4\nfacebook.com/amldistribulcao\ncervejas, sangria, sumos, néctares, refrigerantes, águas,\nleite, vinhos, espumante, vinho do porto, whisky.\naguardentes, ginja, anis, ponche, amêndoa amarga,\nlicores, gin, vodka, rum, cafés, chás, azeitonas, pickles,\ntremoços, amendoins, batata frita, chocolates, pastilhas,\ncaramelos, rebuçados, gomas, carvão, toalhas em papel,\nconsumiveis descartáveis para hotelaria (toalhas, sacos,\nembalagens de aluminio, talheres, papéis de limpeza),\ndetergentes aprovados HACCP.\nExmo (s) Senhor (es)\nALAMBIQUE CF REST.-SUPREME CHICKEN ACT.HOT. UNI\nESTRADA NACIONAL 2\nADICA\n3460-321 TONDELA\nRequisição G. Remessa Vendedor\nCliente\n49\n3078\nContribuinte\n518634108\nCondições\n0 Dias\nVencimento\n2025-10-02\nFATURA FT 25/7179\nDATA: 2025-10-02\nORIGINAL\nPg 1\n101\n167\nLocal Carga: PARQUE INDUSTRIAL ADICA\n3460-321 TONDELA\nData: 2025-10-03 Hora: 08:00\nCódigo Designação:\nSUPER BOCK TR 0,331 x 24\nSB mini TR 0,20L x 30\nLocal Descarga: ESTRADA NACIONAL 21\n3460-321 TONDELA\nData: 2025-10-03 Hora: 23:59 N/ CARRO\nQuantid. UN\n€ Preço Desc Liquido IVA\n20 GR\n11,96 0.00\n11,96 23%\n15 GR\n10,80 0.00\n10,80 23%\n5036\nSAGRES mini TR 020Lx24\n10 GR\n10,37 0.00\n10,37 23%\n5035\nSAGRES TR 0331x24\n4 GR\n14,98 0.00\n14,98 23%\n7006\nCOCA-COLA TR 0,35L x 24\n2 GR\n20,74 0.00\n20,74 23%\n7155\nCOCA-COLA ZERO TR 0,35L x 24\n1 GR\n19,68 0.00\n19,68 23%\n7168\nLIPTON LIMÃO TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7170\nLIPTON PESSEGO TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7169\nLIPTON MANGA TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7886\nSUMOL LARANJA TR 0.30 x 24 GRADE\n1 GR\n12,30 0.00\n12,30 23%\n7769\nSEVEN UP TR 0,30L x 24 GRADE\n1 GR\n12,30 0.00\n12,30 23%\n164\nSB STOUT TR 0,33L x 24\n1 CX\n14,11 0.00\n14,11 23%\n178\nSB STOUT Mini TR 0,20L x 30\n1 GR\n12,00 0.00\n12,00 23%\n329\nPEDRAS SALGADAS TR 0,25L x 24\n2 EB\n8,40 0.00\n8,40 13%\n7149\nCALDAS DE PENACOVA PET 1,5L x 6\n10 EB\n1,63 0.00\n1,63 13%\n8252\nSERRANA AGUA PREMIUM 1Lx6\n1 EB\n1,66 *****\n0,00 13%\n7554\nBESTEIROS LIMA LIMÃO 1.5Lx6 PET\n1 EB\n4,55 0.00\n4,55 23%\n5242\nJOI LARANJA 1,5L x 6.\n1 EB\n5,93 5.00\n5,63 23%\n7235\nFRIZE LIMÃO TP 025Lx24\n1 EB\n12,00 0.00\n12,00 23%\n7519\nSOMERSBY SIDRA MACA TP 033Lx15\n1 EB\n13,88 5.00\n13,19 23%\n7209\nAML. TINTO 13% BIB 10L\n5 UN\n11,07 0.00\n11,07 13%\n7208\nAML. BRANCO 12.5% BIB 5L\n5 UN\n5,77 0.00\n5,77 13%\nContinua na página seguinte.','{\"pages\": 1, \"confidence\": 0.9514810698054604}','reviewing',NULL,'2025-12-12 15:52:59.003','2025-12-12 15:53:41.288',NULL,NULL,NULL,NULL),(16,1,'AM. Distribuição Antero Marques Loureiro','149459459','FT 25/7179','2025-10-02 00:00:00.000',NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_1_1765556277759.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_1_1765556277759.jpg','jpeg','AM. Distribuição\nAntero Marques Loureiro\'\nParque Industrial Adiça, Lt 32\n3460-321 TONDELA | amldistribuicao@gmail.com\nTel 232 816 583 [chamada para a rede fixa nacional]\nNIF 149 459 459\nIBAN PT50 0045 3182 4003 3689 0188 4\nfacebook.com/amldistribulcao\ncervejas, sangria, sumos, néctares, refrigerantes, águas,\nleite, vinhos, espumante, vinho do porto, whisky.\naguardentes, ginja, anis, ponche, amêndoa amarga,\nlicores, gin, vodka, rum, cafés, chás, azeitonas, pickles,\ntremoços, amendoins, batata frita, chocolates, pastilhas,\ncaramelos, rebuçados, gomas, carvão, toalhas em papel,\nconsumiveis descartáveis para hotelaria (toalhas, sacos,\nembalagens de aluminio, talheres, papéis de limpeza),\ndetergentes aprovados HACCP.\nExmo (s) Senhor (es)\nALAMBIQUE CF REST.-SUPREME CHICKEN ACT.HOT. UNI\nESTRADA NACIONAL 2\nADICA\n3460-321 TONDELA\nRequisição G. Remessa Vendedor\nCliente\n49\n3078\nContribuinte\n518634108\nCondições\n0 Dias\nVencimento\n2025-10-02\nFATURA FT 25/7179\nDATA: 2025-10-02\nORIGINAL\nPg 1\n101\n167\nLocal Carga: PARQUE INDUSTRIAL ADICA\n3460-321 TONDELA\nData: 2025-10-03 Hora: 08:00\nCódigo Designação:\nSUPER BOCK TR 0,331 x 24\nSB mini TR 0,20L x 30\nLocal Descarga: ESTRADA NACIONAL 21\n3460-321 TONDELA\nData: 2025-10-03 Hora: 23:59 N/ CARRO\nQuantid. UN\n€ Preço Desc Liquido IVA\n20 GR\n11,96 0.00\n11,96 23%\n15 GR\n10,80 0.00\n10,80 23%\n5036\nSAGRES mini TR 020Lx24\n10 GR\n10,37 0.00\n10,37 23%\n5035\nSAGRES TR 0331x24\n4 GR\n14,98 0.00\n14,98 23%\n7006\nCOCA-COLA TR 0,35L x 24\n2 GR\n20,74 0.00\n20,74 23%\n7155\nCOCA-COLA ZERO TR 0,35L x 24\n1 GR\n19,68 0.00\n19,68 23%\n7168\nLIPTON LIMÃO TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7170\nLIPTON PESSEGO TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7169\nLIPTON MANGA TR 0,33L x 24\n1 GR\n14,70 5.00\n13,97 23%\n7886\nSUMOL LARANJA TR 0.30 x 24 GRADE\n1 GR\n12,30 0.00\n12,30 23%\n7769\nSEVEN UP TR 0,30L x 24 GRADE\n1 GR\n12,30 0.00\n12,30 23%\n164\nSB STOUT TR 0,33L x 24\n1 CX\n14,11 0.00\n14,11 23%\n178\nSB STOUT Mini TR 0,20L x 30\n1 GR\n12,00 0.00\n12,00 23%\n329\nPEDRAS SALGADAS TR 0,25L x 24\n2 EB\n8,40 0.00\n8,40 13%\n7149\nCALDAS DE PENACOVA PET 1,5L x 6\n10 EB\n1,63 0.00\n1,63 13%\n8252\nSERRANA AGUA PREMIUM 1Lx6\n1 EB\n1,66 *****\n0,00 13%\n7554\nBESTEIROS LIMA LIMÃO 1.5Lx6 PET\n1 EB\n4,55 0.00\n4,55 23%\n5242\nJOI LARANJA 1,5L x 6.\n1 EB\n5,93 5.00\n5,63 23%\n7235\nFRIZE LIMÃO TP 025Lx24\n1 EB\n12,00 0.00\n12,00 23%\n7519\nSOMERSBY SIDRA MACA TP 033Lx15\n1 EB\n13,88 5.00\n13,19 23%\n7209\nAML. TINTO 13% BIB 10L\n5 UN\n11,07 0.00\n11,07 13%\n7208\nAML. BRANCO 12.5% BIB 5L\n5 UN\n5,77 0.00\n5,77 13%\nContinua na página seguinte.','{\"pages\": 1, \"confidence\": 0.9514810698054604}','rejected',NULL,'2025-12-12 16:17:57.760','2025-12-12 16:22:02.157','2025-12-12 16:22:02.155',NULL,NULL,NULL),(17,1,'FRUTAS PEDRO CRUZ LDA','510885837','PT 25/26326','2025-11-11 00:00:00.000',67.75,3.44,71.19,'Compras_Restaurante_Alambique_exemplo_5_1765815015470.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_5_1765815015470.jpg','jpeg','FRUTAS\npedrocruz\nFRUTAS PEDRO CRUZ LDA\nSite: www.frutaspedrocruz.pt\nTIP: 232431185 Tim: 916332671\nEmail: geral@frutaspedrocruz.pt\nencomendas@frutaspedrocruz.pt\nAALLLLLL\nExmo(s) Senhor (es)\n\\der\\pider PME lider23 PME lider 24\nSUPREME CHICKEN ACT HOT LDA (ALAMBIQUE )\nESTRADA NACIONAL 2\nADIÇA\n3460-321 TONDELA\nRequisição G. Remessa Vendedor Cliente Contribuinte Condições Vencimento\n1201 518634108\nLocal Carga: Rua Vale da Casa, Ucha\n30 Dias 2025-12-11\nLocal Descarga: ESTRADA NACIONAL 2\n3460-321 TONDELA\nData: 2025-11-11 Hora: 23:59\nORIGINAL\nFATURA PT 25/26326 Pg 1\nDATA: 2025-11-11\n3510-426 Vila Cha de Sa-VISEU\nData: 2025-11-11 Bora: 07:37\nCódigo\n1841\n2081\n1541\n801\nDesignação\nCORGETS CAT II PORTUGAL MARROCOS\nTOMATE GR CAT II PORTUGAL\nALFACE FRISADA CAT II PORTUGAL\nCENOURA CAT I ESPANHA\n022\nPIMENTO VERMELHO CAT II PAISES BAIXOS\n8888\nCODIGO DA ARA SALDO TARAS SALDO RC/BG\nQTD LEVA\nGOO\n/CARSO\nLotes Quantid. UN\n€ Preço Desc A liquido\n5.900 KG\n0,990 0.00 6\n25.300 KG\n0,890 0.00 6\n6.700 KG\n0,990 0.00 6\n10.000 G\n0,640 0.00 64\n6.500 KG\n2,440 0.00 69 15,8\nQED ENTREGA RECEBIMOS TD.PAGACS SALDO TARAS SALDO RC/PG\n200\n(CAIXAS TARA 1,50) CO (CAIXAS TARA 1.50) C3 (CAIXAS TARA\nARAS ISENÇÃO IVA (M1) ARTIGO 18\" N6 ALINEAC) CIVA\nOs Produtos/Serviços Facturados foran colocados à disposição do adquirente sa data: 2025-11-11\nIncidência Taxa Valor Imposto\nATCUD:JJ43VNSR-26326\n10,50 08\n0,00\n57,25 68\n3,44\n0,00\n138\n0,00\n0,00\n239\n0,00\ncenciado para: FRUTAS PEDRO CRUL, LDA Por 25F, Ld\nIBAN: PT50 0045 3252 4026 1325 6896 1\nBIC/SWIFT: CCCMPTPL\nTOTAIS GERAIS DO DOCUMENTO\nValor Iliquido:\n67,75 €\nValor de IVA:\n3,44 €\nValor Descontos:\n0.00 €\nValor Taras\n10,50 €\nTOTAL DOCUMENTO:\n71,19€\n136-PROCESSADO FOR ROMANA PECADO W10/AT\nRua Nova do Vale da Casa, 13\nNIPC 510 885 837\nVila chã de Sá 3510-423 Viseu\nHF 0129435','{\"pages\": 1, \"confidence\": 0.8603016556105946}','approved_partial',NULL,'2025-12-15 16:10:15.472','2025-12-15 16:22:28.348','2025-12-15 16:22:28.347','2025-12-15 16:22:28.347',1,NULL),(18,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Compras_Restaurante_Alambique_exemplo_5_1765817274676.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_5_1765817274676.jpg','jpeg',NULL,NULL,'error','Parsing failed: No line items extracted. This could be due to API failures or unsupported invoice format.','2025-12-15 16:47:54.678','2025-12-15 16:48:21.872',NULL,NULL,NULL,NULL),(19,1,'FRUTAS PEDRO CRUZ LDA','510885837','PT 25/26326','2025-11-11 00:00:00.000',67.75,3.44,71.19,'Compras_Restaurante_Alambique_exemplo_5_1765817359898.jpg','/workspaces/RCM-Antigravity/backend/uploads/invoices/tenant_1/Compras_Restaurante_Alambique_exemplo_5_1765817359898.jpg','jpeg','FRUTAS\npedrocruz\nFRUTAS PEDRO CRUZ LDA\nSite: www.frutaspedrocruz.pt\nTIP: 232431185 Tim: 916332671\nEmail: geral@frutaspedrocruz.pt\nencomendas@frutaspedrocruz.pt\nAALLLLLL\nExmo(s) Senhor (es)\n\\der\\pider PME lider23 PME lider 24\nSUPREME CHICKEN ACT HOT LDA (ALAMBIQUE )\nESTRADA NACIONAL 2\nADIÇA\n3460-321 TONDELA\nRequisição G. Remessa Vendedor Cliente Contribuinte Condições Vencimento\n1201 518634108\nLocal Carga: Rua Vale da Casa, Ucha\n30 Dias 2025-12-11\nLocal Descarga: ESTRADA NACIONAL 2\n3460-321 TONDELA\nData: 2025-11-11 Hora: 23:59\nORIGINAL\nFATURA PT 25/26326 Pg 1\nDATA: 2025-11-11\n3510-426 Vila Cha de Sa-VISEU\nData: 2025-11-11 Bora: 07:37\nCódigo\n1841\n2081\n1541\n801\nDesignação\nCORGETS CAT II PORTUGAL MARROCOS\nTOMATE GR CAT II PORTUGAL\nALFACE FRISADA CAT II PORTUGAL\nCENOURA CAT I ESPANHA\n022\nPIMENTO VERMELHO CAT II PAISES BAIXOS\n8888\nCODIGO DA ARA SALDO TARAS SALDO RC/BG\nQTD LEVA\nGOO\n/CARSO\nLotes Quantid. UN\n€ Preço Desc A liquido\n5.900 KG\n0,990 0.00 6\n25.300 KG\n0,890 0.00 6\n6.700 KG\n0,990 0.00 6\n10.000 G\n6.500 KG\n0,640 0.00 64\n2,440 0.00 69\n15,8\nQED ENTREGA RECEBIMOS TD.PAGACS SALDO TARAS SALDO RC/PG\n200\n(CAIXAS TARA 1,50) CO (CAIXAS TARA 1.50) C3 (CAIXAS TARA\nARAS ISENÇÃO IVA (M1) ARTIGO 18\" N6 ALINEAC) CIVA\nOs Produtos/Serviços Facturados foran colocados à disposição do adquirente sa data: 2025-11-11\nIncidência Taxa Valor Imposto\nATCUD:JJ43VNSR-26326\n10,50 08\n0,00\n57,25 68\n3,44\n0,00\n138\n0,00\n0,00\n239\n0,00\ncenciado para: FRUTAS PEDRO CRUL, LDA Por 25F, Ld\nIBAN: PT50 0045 3252 4026 1325 6896 1\nBIC/SWIFT: CCCMPTPL\nTOTAIS GERAIS DO DOCUMENTO\nValor Iliquido:\n67,75 €\nValor de IVA:\n3,44 €\nValor Descontos:\n0.00 €\nValor Taras\n10,50 €\nTOTAL DOCUMENTO:\n71,19€\n136-PROCESSADO FOR ROMANA PECADO W10/AT\nRua Nova do Vale da Casa, 13\nNIPC 510 885 837\nVila chã de Sá 3510-423 Viseu\nHF 0129435','{\"pages\": 1, \"confidence\": 0.8609315539486855}','approved',NULL,'2025-12-15 16:49:19.900','2025-12-15 16:51:03.955','2025-12-15 16:51:03.953','2025-12-15 16:51:03.953',1,NULL);
/*!40000 ALTER TABLE `faturas_importacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faturas_linhas_importacao`
--

DROP TABLE IF EXISTS `faturas_linhas_importacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faturas_linhas_importacao` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fatura_importacao_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `linha_numero` int NOT NULL,
  `descricao_original` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` decimal(10,3) DEFAULT NULL,
  `unidade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco_unitario` decimal(10,4) DEFAULT NULL,
  `preco_total` decimal(10,2) DEFAULT NULL,
  `iva_percentual` decimal(5,2) DEFAULT NULL,
  `iva_valor` decimal(10,2) DEFAULT NULL,
  `produto_id` int DEFAULT NULL,
  `variacao_id` int DEFAULT NULL,
  `confianca_match` decimal(5,2) DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `familia_id` int DEFAULT NULL,
  `subfamilia_id` int DEFAULT NULL,
  `criar_produto` tinyint(1) NOT NULL DEFAULT '0',
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `descricao_limpa` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emb_quantidade` decimal(10,3) DEFAULT NULL,
  `emb_tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emb_unidade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preco_por_kg` decimal(10,4) DEFAULT NULL,
  `preco_por_litro` decimal(10,4) DEFAULT NULL,
  `preco_por_unidade` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `faturas_linhas_importacao_fatura_importacao_id_idx` (`fatura_importacao_id`),
  KEY `faturas_linhas_importacao_tenant_id_status_idx` (`tenant_id`,`status`),
  KEY `faturas_linhas_importacao_produto_id_idx` (`produto_id`),
  KEY `faturas_linhas_importacao_variacao_id_fkey` (`variacao_id`),
  CONSTRAINT `faturas_linhas_importacao_fatura_importacao_id_fkey` FOREIGN KEY (`fatura_importacao_id`) REFERENCES `faturas_importacao` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `faturas_linhas_importacao_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `faturas_linhas_importacao_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `faturas_linhas_importacao_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faturas_linhas_importacao`
--

LOCK TABLES `faturas_linhas_importacao` WRITE;
/*!40000 ALTER TABLE `faturas_linhas_importacao` DISABLE KEYS */;
INSERT INTO `faturas_linhas_importacao` VALUES (1,1,1,1,'Coelho',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.254','2025-12-11 17:38:08.254',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,1,2,'Coelho',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.286','2025-12-11 17:38:08.286',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,1,1,3,'Sede',NULL,NULL,3515.0000,221.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.300','2025-12-11 17:38:08.300',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,1,1,4,'Tel',232.000,NULL,459.0000,1.00,NULL,NULL,10,NULL,76.00,'manual_review',NULL,NULL,0,'{\"matchReason\": \"Fuzzy match (score: 0.24)\"}','2025-12-11 17:38:08.309','2025-12-11 17:38:08.309',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,1,1,5,'Fax',232.000,NULL,451.0000,726.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.326','2025-12-11 17:38:08.326',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,1,1,6,'Email',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.334','2025-12-11 17:38:08.334',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,1,1,7,'NIPC',501.000,NULL,122.0000,583.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.342','2025-12-11 17:38:08.342',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,1,1,8,'(',45.000,NULL,2.0000,1.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.350','2025-12-11 17:38:08.350',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,1,1,9,'Fal',5000.000,NULL,82.0000,250.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.360','2025-12-11 17:38:08.360',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,1,1,10,'Filial',NULL,NULL,6.0000,7.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.371','2025-12-11 17:38:08.371',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,1,1,11,'IBAN',50.000,NULL,33.0000,NULL,NULL,NULL,91,NULL,62.00,'manual_review',NULL,NULL,0,'{\"matchReason\": \"Fuzzy match (score: 0.38)\"}','2025-12-11 17:38:08.381','2025-12-11 17:38:08.381',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,1,1,12,'ATCUD JJ',64.000,NULL,NULL,70673.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.404','2025-12-11 17:38:08.404',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,1,1,13,'PAG.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.410','2025-12-11 17:38:08.410',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,1,1,14,'SUPREME CHICHEN ACT.HOTELEIRAS, Unip.,',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.432','2025-12-11 17:38:08.432',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,1,1,15,'ESTRADA NACIONAL N',NULL,NULL,NULL,2.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:38:08.444','2025-12-11 17:38:08.444',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,2,1,1,'Coelh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.180','2025-12-11 17:56:07.180',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,2,1,2,'Coelh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.193','2025-12-11 17:56:07.193',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,2,1,3,'(0045 0',45.000,NULL,2.0000,1.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.208','2025-12-11 17:56:07.208',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,2,1,4,'ATCUD',64.000,NULL,70673.0000,64.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.218','2025-12-11 17:56:07.218',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,2,1,5,'SUPREME CHI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.232','2025-12-11 17:56:07.232',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,2,1,6,'ESTRA',2.000,NULL,NULL,2.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.241','2025-12-11 17:56:07.241',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,2,1,7,'Clie',90303.000,NULL,NULL,90303.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.248','2025-12-11 17:56:07.248',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,2,1,8,'Vend',18.000,NULL,NULL,18.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.258','2025-12-11 17:56:07.258',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,2,1,9,'COND',NULL,NULL,NULL,NULL,NULL,NULL,7,NULL,62.00,'manual_review',NULL,NULL,0,'{\"matchReason\": \"Fuzzy match (score: 0.38)\"}','2025-12-11 17:56:07.271','2025-12-11 17:56:07.271',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,2,1,10,'FTV',25001.000,NULL,NULL,70673.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.279','2025-12-11 17:56:07.279',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,2,1,11,'IPSV',6.000,NULL,1113.0190,2025.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.286','2025-12-11 17:56:07.286',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,2,1,12,'235743 BIFE',235743.000,'CX',4.0000,235743.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.294','2025-12-11 17:56:07.294',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,2,1,13,'261703 CAMARA',261703.000,'CX',20.0000,30.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.305','2025-12-11 17:56:07.305',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,2,1,14,'26371 CA',26371.000,'KG',NULL,26371.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.321','2025-12-11 17:56:07.321',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,2,1,15,'20703 C',20703.000,NULL,2.0000,4.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.336','2025-12-11 17:56:07.336',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,2,1,16,'263135 M. CAMA',263135.000,NULL,NULL,31.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.353','2025-12-11 17:56:07.353',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,2,1,17,'256461 PASTE',256461.000,NULL,20.0000,256461.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.360','2025-12-11 17:56:07.360',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,2,1,18,'033967 POL',33967.000,'CX',2.0000,7.50,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.367','2025-12-11 17:56:07.367',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,2,1,19,'0223993 SALTE',223993.000,NULL,4.0000,2.50,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.375','2025-12-11 17:56:07.375',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,2,1,20,'4,0',4.000,'KG',23.0000,4.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.382','2025-12-11 17:56:07.382',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,2,1,21,'10,',10.000,'KG',6.0000,10.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.388','2025-12-11 17:56:07.388',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,2,1,22,'6,0',6.000,'UN',23.0000,6.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.394','2025-12-11 17:56:07.394',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,2,1,23,'15,',15.000,'KG',6.0000,15.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.400','2025-12-11 17:56:07.400',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,2,1,24,'10,',10.000,'KG',23.0000,10.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.406','2025-12-11 17:56:07.406',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,2,1,25,'3515',3515.000,NULL,221.0000,3515.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.413','2025-12-11 17:56:07.413',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,2,1,26,'ESTRA',2.000,NULL,NULL,2.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.422','2025-12-11 17:56:07.422',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,2,1,27,'3460',3460.000,NULL,321.0000,3460.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.434','2025-12-11 17:56:07.434',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,2,1,28,'om5X-Emitido por programa certificado n.',5.000,NULL,NULL,445.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.463','2025-12-11 17:56:07.463',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,2,1,29,'Soc.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.470','2025-12-11 17:56:07.470',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,2,1,30,'PT',NULL,NULL,NULL,23.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.477','2025-12-11 17:56:07.477',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,2,1,31,'PT',NULL,NULL,NULL,6.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.483','2025-12-11 17:56:07.483',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,2,1,32,'Direto da Universidade de Lisboa, Campus de Campolide',NULL,'UN',1009.0000,2.00,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 17:56:07.496','2025-12-11 17:56:07.496',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,8,1,1,'BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.277','2025-12-11 19:28:43.277',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(49,8,1,2,'CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.303','2025-12-11 19:28:43.303',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,8,1,3,'CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.316','2025-12-11 19:28:43.316',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,8,1,4,'CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.332','2025-12-11 19:28:43.332',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,8,1,5,'M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.351','2025-12-11 19:28:43.351',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,8,1,6,'PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.369','2025-12-11 19:28:43.369',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,8,1,7,'POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.384','2025-12-11 19:28:43.384',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,8,1,8,'SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-11 19:28:43.401','2025-12-11 19:28:43.401',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,9,1,1,'235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.064','2025-12-12 11:21:47.064',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,9,1,2,'261703 CAMARAO 20/30 VANNAMEI cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.090','2025-12-12 11:21:47.090',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,9,1,3,'26371 CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.102','2025-12-12 11:21:47.102',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59,9,1,4,'20703 CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.112','2025-12-12 11:21:47.112',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,9,1,5,'263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.128','2025-12-12 11:21:47.128',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(61,9,1,6,'256461 PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.143','2025-12-12 11:21:47.143',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,9,1,7,'033967 POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.159','2025-12-12 11:21:47.159',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,9,1,8,'0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:21:47.183','2025-12-12 11:21:47.183',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,10,1,1,'BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.254','2025-12-12 11:37:59.254','BIFE FRANGO PANADO CERVAS HIG',4.000,'caixa','kg',7.3500,NULL,NULL),(65,10,1,2,'CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.276','2025-12-12 11:37:59.276','CAMARAO 20/30 VANNAME! Pescanova',2.000,'caixa','kg',7.2500,NULL,NULL),(66,10,1,3,'CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.290','2025-12-12 11:37:59.290','CAPRICHOS ALASKA Kg NOS',NULL,NULL,NULL,NULL,NULL,6.3500),(67,10,1,4,'CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.306','2025-12-12 11:37:59.306','CHOCO LP 2/4 AV E/O',NULL,NULL,NULL,5.9500,NULL,NULL),(68,10,1,5,'M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.336','2025-12-12 11:37:59.336','M. CAMARAO 31/40 VN stripa INDIA',800.000,'saco','g',10.6250,NULL,NULL),(69,10,1,6,'PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.366','2025-12-12 11:37:59.366','PASTEIS BACALHAU CATERING',20.000,'embalagem','un',NULL,NULL,0.1375),(70,10,1,7,'POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.394','2025-12-12 11:37:59.394','POLVO ROTO E/O',15.000,'caixa','kg',9.5000,NULL,NULL),(71,10,1,8,'SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 11:37:59.422','2025-12-12 11:37:59.422','SALTEADO CAMPESTRE Minute BOND',NULL,NULL,NULL,3.5500,NULL,NULL),(72,11,1,1,'235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:46.952','2025-12-12 12:04:46.952','BIFE FRANGO PANADO CERVAS',4.000,'caixa','kg',7.3500,NULL,NULL),(73,11,1,2,'261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:46.970','2025-12-12 12:04:46.970','CAMARAO 20/30 VANNAME!',2.000,'caixa','kg',7.2500,NULL,NULL),(74,11,1,3,'26371 CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:46.983','2025-12-12 12:04:46.983','CAPRICHOS ALASKA',NULL,NULL,NULL,NULL,NULL,NULL),(75,11,1,4,'20703 CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:46.995','2025-12-12 12:04:46.995','CHOCO LP 2/4 AV E/O',NULL,NULL,NULL,5.9500,NULL,NULL),(76,11,1,5,'263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:47.013','2025-12-12 12:04:47.013','M. CAMARAO 31/40 VN stripa',800.000,'saco','g',10.6300,NULL,NULL),(77,11,1,6,'256461 PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:47.035','2025-12-12 12:04:47.035','PASTEIS BACALHAU',20.000,'saco','un',NULL,NULL,0.1400),(78,11,1,7,'033967 POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:47.065','2025-12-12 12:04:47.065','POLVO ROTO',15.000,'caixa','kg',9.5000,NULL,NULL),(79,11,1,8,'0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:04:47.106','2025-12-12 12:04:47.106','SALTEADO CAMPESTRE',NULL,NULL,NULL,3.5500,NULL,NULL),(80,12,1,1,'235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.418','2025-12-12 12:47:12.418','BIFE FRANGO PANADO CERVAS HIG',4.000,'caixa','kg',7.3500,NULL,NULL),(81,12,1,2,'261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.442','2025-12-12 12:47:12.442','CAMARAO 20/30 VANNAME! Pescanova',2.000,'caixa','kg',7.2500,NULL,NULL),(82,12,1,3,'26371 CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.458','2025-12-12 12:47:12.458','CAPRICHOS ALASKA Kg NOS',NULL,NULL,NULL,NULL,NULL,6.3500),(83,12,1,4,'20703 CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.476','2025-12-12 12:47:12.476','CHOCO LP 2/4 AV E/O',NULL,NULL,NULL,5.9500,NULL,NULL),(84,12,1,5,'263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.499','2025-12-12 12:47:12.499','M. CAMARAO 31/40 VN stripa INDIA',800.000,'saco','g',10.6250,NULL,8.5000),(85,12,1,6,'256461 PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.519','2025-12-12 12:47:12.519','PASTEIS BACALHAU CATERING',20.000,'saco','un',NULL,NULL,0.1380),(86,12,1,7,'033967 POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.539','2025-12-12 12:47:12.539','POLVO ROTO E/O',15.000,'caixa','kg',9.5000,NULL,NULL),(87,12,1,8,'0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 12:47:12.558','2025-12-12 12:47:12.558','SALTEADO CAMPESTRE Minute BOND',10.000,'pacote','kg',3.5500,NULL,NULL),(88,13,1,1,'235743 BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.575','2025-12-12 13:04:14.575','BIFE FRANGO PANADO CERVAS HIG',4.000,'caixa','kg',7.3500,NULL,NULL),(89,13,1,2,'261703 CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.593','2025-12-12 13:04:14.593','CAMARAO 20/30 VANNAME! Pescanova',2.000,'caixa','kg',7.2500,NULL,NULL),(90,13,1,3,'26371 CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.605','2025-12-12 13:04:14.605','CAPRICHOS ALASKA Kg NOS',NULL,NULL,NULL,NULL,NULL,6.3500),(91,13,1,4,'20703 CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.616','2025-12-12 13:04:14.616','CHOCO LP 2/4 AV E/O',NULL,NULL,NULL,5.9500,NULL,NULL),(92,13,1,5,'263135 M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.632','2025-12-12 13:04:14.632','M. CAMARAO 31/40 VN stripa INDIA',800.000,'saco','g',10.6250,NULL,NULL),(93,13,1,6,'256461 PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.649','2025-12-12 13:04:14.649','PASTEIS BACALHAU CATERING',20.000,'saco','un',NULL,NULL,0.1375),(94,13,1,7,'033967 POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.666','2025-12-12 13:04:14.666','POLVO ROTO E/O',15.000,'caixa','kg',9.5000,NULL,NULL),(95,13,1,8,'0223993 SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 13:04:14.683','2025-12-12 13:04:14.683','SALTEADO CAMPESTRE Minute BOND',10.000,'pacote','kg',3.5500,NULL,NULL),(96,14,1,1,'BIFE FRANGO PANADO CERVAS cx 4kg HIG',4.000,'KG',7.3500,29.40,23.00,6.76,113,115,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.839','2025-12-12 14:52:42.873','BIFE FRANGO PANADO CERVAS HIG',4.000,'caixa','kg',7.3500,NULL,NULL),(97,14,1,2,'CAMARAO 20/30 VANNAME! cx 2Kg Pescanova',2.000,'KG',7.2500,14.50,23.00,3.34,114,116,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.859','2025-12-12 14:54:17.527','CAMARAO 20/30 VANNAME! Pescanova',2.000,'caixa','kg',7.2500,NULL,NULL),(98,14,1,3,'CAPRICHOS ALASKA Kg NOS',2.000,'UN',6.3500,12.70,23.00,2.92,115,117,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.871','2025-12-12 15:00:33.431','CAPRICHOS ALASKA Kg NOS',NULL,NULL,NULL,NULL,NULL,6.3500),(99,14,1,4,'CHOCO LP 2/4 AV E/O',10.000,'KG',5.9500,59.50,6.00,3.57,116,118,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.884','2025-12-12 15:01:45.791','CHOCO LP 2/4 AV E/O',NULL,NULL,NULL,5.9500,NULL,NULL),(100,14,1,5,'M. CAMARAO 31/40 VN stripa Sc 800g INDIA',10.000,'UN',8.5000,85.00,23.00,19.55,117,119,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.909','2025-12-12 15:05:30.726','M. CAMARAO 31/40 VN stripa INDIA',800.000,'saco','g',10.6250,NULL,NULL),(101,14,1,6,'PASTEIS BACALHAU SC 20un CATERING',6.000,'UN',2.7500,16.50,23.00,3.80,118,120,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.931','2025-12-12 15:07:29.488','PASTEIS BACALHAU CATERING',20.000,'saco','un',NULL,NULL,0.1375),(102,14,1,7,'POLVO ROTO cx 2 x 7,5kg E/O',15.000,'KG',9.5000,142.50,6.00,8.55,119,121,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.943','2025-12-12 15:09:50.674','POLVO ROTO E/O',15.000,'caixa','kg',9.5000,NULL,NULL),(103,14,1,8,'SALTEADO CAMPESTRE 4x2.5KG Minute BOND',10.000,'KG',3.5500,35.50,23.00,8.17,120,122,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 13:10:59.960','2025-12-12 15:12:40.593','SALTEADO CAMPESTRE 4x2.5KG Minute BOND',NULL,NULL,NULL,3.5500,NULL,NULL),(104,16,1,1,'SUPER BOCK TR 0,331 x 24',20.000,'GR',11.9600,239.20,23.00,55.02,89,124,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 16:19:46.571','2025-12-15 15:23:54.166','SUPER BOCK TR',24.000,'embalagem','un',NULL,1.5100,0.5000),(105,16,1,2,'SB mini TR 0,20L x 30',15.000,'GR',10.8000,162.00,23.00,37.26,89,NULL,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 16:19:46.586','2025-12-15 10:11:17.650','SB mini TR',30.000,'embalagem','un',NULL,1.8000,0.3600),(106,16,1,3,'SAGRES mini TR 020Lx24',10.000,'GR',10.3700,103.70,23.00,23.85,90,90,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 16:19:46.597','2025-12-12 18:17:33.424','SAGRES mini TR',24.000,'embalagem','un',NULL,2.1600,0.4300),(107,16,1,4,'SAGRES TR 0331x24',4.000,'GR',14.9800,59.92,23.00,13.78,90,90,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 16:19:46.616','2025-12-12 18:15:16.200','SAGRES TR',24.000,'embalagem','un',NULL,1.8800,0.6200),(108,16,1,5,'COCA-COLA TR 0,35L x 24',2.000,'GR',20.7400,41.48,23.00,9.54,79,79,100.00,'matched',NULL,NULL,0,NULL,'2025-12-12 16:19:46.628','2025-12-12 18:10:06.286','COCA-COLA TR',24.000,'embalagem','un',NULL,2.4700,0.8600),(109,16,1,6,'COCA-COLA ZERO TR 0,35L x 24',1.000,'GR',19.6800,19.68,23.00,4.53,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.640','2025-12-12 16:19:46.640','COCA-COLA ZERO TR',24.000,'embalagem','un',NULL,2.3400,0.8200),(110,16,1,7,'LIPTON LIMÃO TR 0,33L x 24',1.000,'GR',13.9700,13.97,23.00,3.21,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.658','2025-12-12 16:19:46.658','LIPTON LIMÃO TR',24.000,'embalagem','un',NULL,1.7600,0.5800),(111,16,1,8,'LIPTON PESSEGO TR 0,33L x 24',1.000,'GR',13.9700,13.97,23.00,3.21,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.679','2025-12-12 16:19:46.679','LIPTON PESSEGO TR',24.000,'embalagem','un',NULL,1.7600,0.5800),(112,16,1,9,'LIPTON MANGA TR 0,33L x 24',1.000,'GR',13.9700,13.97,23.00,3.21,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.696','2025-12-12 16:19:46.696','LIPTON MANGA TR',24.000,'embalagem','un',NULL,1.7600,0.5800),(113,16,1,10,'SUMOL LARANJA TR 0.30 x 24 GRADE',1.000,'GR',12.3000,12.30,23.00,2.83,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.713','2025-12-12 16:19:46.713','SUMOL LARANJA TR',24.000,'embalagem','un',NULL,1.7100,0.5100),(114,16,1,11,'SEVEN UP TR 0,30L x 24 GRADE',1.000,'GR',12.3000,12.30,23.00,2.83,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.724','2025-12-12 16:19:46.724','SEVEN UP TR',24.000,'embalagem','un',NULL,1.7100,0.5100),(115,16,1,12,'SB STOUT TR 0,33L x 24',1.000,'CX',14.1100,14.11,23.00,3.25,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.734','2025-12-12 16:19:46.734','SB STOUT TR',24.000,'caixa','un',NULL,1.7800,0.5900),(116,16,1,13,'SB STOUT Mini TR 0,20L x 30',1.000,'GR',12.0000,12.00,23.00,2.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.751','2025-12-12 16:19:46.751','SB STOUT Mini TR',30.000,'embalagem','un',NULL,2.0000,0.4000),(117,16,1,14,'PEDRAS SALGADAS TR 0,25L x 24',2.000,'EB',8.4000,16.80,13.00,2.18,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.766','2025-12-12 16:19:46.766','PEDRAS SALGADAS TR',24.000,'embalagem','un',NULL,1.4000,0.3500),(118,16,1,15,'CALDAS DE PENACOVA PET 1,5L x 6',10.000,'EB',1.6300,16.30,13.00,2.12,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.779','2025-12-12 16:19:46.779','CALDAS DE PENACOVA',6.000,'garrafa','un',NULL,0.1800,0.2700),(119,16,1,16,'SERRANA AGUA PREMIUM 1Lx6',1.000,'EB',NULL,NULL,13.00,NULL,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.789','2025-12-12 16:19:46.789','SERRANA AGUA PREMIUM',6.000,'embalagem','un',NULL,NULL,NULL),(120,16,1,17,'BESTEIROS LIMA LIMÃO 1.5Lx6 PET',1.000,'EB',4.5500,4.55,23.00,1.05,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.800','2025-12-12 16:19:46.800','BESTEIROS LIMA LIMÃO',6.000,'garrafa','un',NULL,0.5100,0.7600),(121,16,1,18,'JOI LARANJA 1,5L x 6.',1.000,'EB',5.6300,5.63,23.00,1.30,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.821','2025-12-12 16:19:46.821','JOI LARANJA',6.000,'embalagem','un',NULL,0.6300,0.9400),(122,16,1,19,'FRIZE LIMÃO TP 025Lx24',1.000,'EB',12.0000,12.00,23.00,2.76,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.831','2025-12-12 16:19:46.831','FRIZE LIMÃO TP',24.000,'embalagem','un',NULL,2.0000,0.5000),(123,16,1,20,'SOMERSBY SIDRA MACA TP 033Lx15',1.000,'EB',13.1900,13.19,23.00,3.03,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.843','2025-12-12 16:19:46.843','SOMERSBY SIDRA MACA TP',15.000,'embalagem','un',NULL,2.6600,0.8800),(124,16,1,21,'AML. TINTO 13% BIB 10L',5.000,'UN',11.0700,55.35,13.00,7.20,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.857','2025-12-12 16:19:46.857','AML. TINTO 13%',1.000,'caixa','un',NULL,1.1100,11.0700),(125,16,1,22,'AML. BRANCO 12.5% BIB 5L',5.000,'UN',5.7700,28.85,13.00,3.75,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-12 16:19:46.866','2025-12-12 16:19:46.866','AML. BRANCO 12.5%',1.000,'caixa','un',NULL,1.1500,5.7700),(126,17,1,1,'CORGETS CAT II PORTUGAL MARROCOS',5.900,'KG',0.9900,5.84,6.00,0.35,NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-15 16:11:25.754','2025-12-15 16:11:25.754','CORGETS CAT II PORTUGAL MARROCOS',NULL,NULL,NULL,0.9900,NULL,NULL),(127,17,1,2,'TOMATE GR CAT II PORTUGAL',25.300,'KG',0.8900,22.52,6.00,1.35,44,44,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:11:25.790','2025-12-15 16:12:39.957','TOMATE GR CAT II PORTUGAL',NULL,NULL,NULL,0.8900,NULL,NULL),(128,17,1,3,'ALFACE FRISADA CAT II PORTUGAL',6.700,'KG',0.9900,6.63,6.00,0.40,40,40,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:11:25.803','2025-12-15 16:12:53.705','ALFACE FRISADA CAT II PORTUGAL',NULL,NULL,NULL,0.9900,NULL,NULL),(129,17,1,4,'CENOURA CAT I ESPANHA',10.000,'KG',0.6400,6.40,6.00,0.38,36,36,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:11:25.814','2025-12-15 16:12:58.268','CENOURA CAT I ESPANHA',NULL,NULL,NULL,0.6400,NULL,NULL),(130,17,1,5,'PIMENTO VERMELHO CAT II PAISES BAIXOS',6.500,'KG',2.4400,15.86,6.00,0.95,45,45,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:11:25.833','2025-12-15 16:13:14.958','PIMENTO VERMELHO CAT II PAISES BAIXOS',NULL,NULL,NULL,2.4400,NULL,NULL),(131,19,1,1,'CORGETS CAT II PORTUGAL MARROCOS',5.900,'KG',0.9900,5.84,6.00,0.35,98,98,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:50:03.991','2025-12-15 16:50:54.479','CORGETS CAT II PORTUGAL MARROCOS',NULL,NULL,NULL,NULL,NULL,NULL),(132,19,1,2,'TOMATE GR CAT II PORTUGAL',25.300,'KG',0.8900,22.52,6.00,1.35,44,44,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:50:04.010','2025-12-15 16:50:19.446','TOMATE GR CAT II PORTUGAL',NULL,NULL,NULL,NULL,NULL,NULL),(133,19,1,3,'ALFACE FRISADA CAT II PORTUGAL',6.700,'KG',0.9900,6.63,6.00,0.40,40,40,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:50:04.025','2025-12-15 16:50:30.846','ALFACE FRISADA CAT II PORTUGAL',NULL,NULL,NULL,NULL,NULL,NULL),(134,19,1,4,'CENOURA CAT I ESPANHA',10.000,'G',0.6400,6.40,6.00,0.38,36,36,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:50:04.037','2025-12-15 16:50:34.523','CENOURA CAT I ESPANHA',NULL,NULL,NULL,NULL,NULL,NULL),(135,19,1,5,'PIMENTO VERMELHO CAT II PAISES BAIXOS',6.500,'KG',2.4400,15.86,6.00,0.95,45,45,100.00,'matched',NULL,NULL,0,NULL,'2025-12-15 16:50:04.056','2025-12-15 16:50:39.427','PIMENTO VERMELHO CAT II PAISES BAIXOS',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `faturas_linhas_importacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `formatos_venda`
--

DROP TABLE IF EXISTS `formatos_venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `formatos_venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `produto_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `codigo_interno` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantidade_vendida` decimal(10,3) NOT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco_venda` decimal(10,2) DEFAULT NULL,
  `custo_unitario` decimal(10,2) NOT NULL,
  `margem_percentual` decimal(5,2) DEFAULT NULL,
  `variacao_origem_id` int DEFAULT NULL,
  `conversao_necessaria` tinyint(1) NOT NULL DEFAULT '0',
  `data_inicio_vigencia` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `data_fim_vigencia` datetime(3) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `disponivel_menu` tinyint(1) NOT NULL DEFAULT '1',
  `ordem_exibicao` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `template_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `formatos_venda_tenant_id_produto_id_idx` (`tenant_id`,`produto_id`),
  KEY `formatos_venda_tenant_id_ativo_disponivel_menu_idx` (`tenant_id`,`ativo`,`disponivel_menu`),
  KEY `formatos_venda_data_fim_vigencia_idx` (`data_fim_vigencia`),
  KEY `formatos_venda_produto_id_fkey` (`produto_id`),
  KEY `formatos_venda_variacao_origem_id_fkey` (`variacao_origem_id`),
  KEY `formatos_venda_template_id_idx` (`template_id`),
  CONSTRAINT `formatos_venda_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `formatos_venda_template_id_fkey` FOREIGN KEY (`template_id`) REFERENCES `template_formato_venda` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `formatos_venda_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `formatos_venda_variacao_origem_id_fkey` FOREIGN KEY (`variacao_origem_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `formatos_venda`
--

LOCK TABLES `formatos_venda` WRITE;
/*!40000 ALTER TABLE `formatos_venda` DISABLE KEYS */;
INSERT INTO `formatos_venda` VALUES (79,1,79,'Coca-Cola (Por L)',NULL,NULL,1.000,'L',2.10,1.50,40.00,79,0,'2025-11-25 10:20:50.004',NULL,1,1,NULL,'2025-11-25 10:20:50.004','2025-11-25 10:20:50.004',NULL),(80,1,80,'Sprite (Por L)',NULL,NULL,1.000,'L',2.10,1.50,40.00,80,0,'2025-11-25 10:20:50.014',NULL,1,1,NULL,'2025-11-25 10:20:50.014','2025-11-25 10:20:50.014',NULL),(81,1,81,'Fanta (Por L)',NULL,NULL,1.000,'L',2.10,1.50,40.00,81,0,'2025-11-25 10:20:50.023',NULL,1,1,NULL,'2025-11-25 10:20:50.023','2025-11-25 10:20:50.023',NULL),(82,1,82,'Sumo de Laranja (Por L)',NULL,NULL,1.000,'L',3.92,2.80,40.00,82,0,'2025-11-25 10:20:50.032',NULL,1,1,NULL,'2025-11-25 10:20:50.032','2025-11-25 10:20:50.032',NULL),(83,1,83,'Sumo de Maçã (Por L)',NULL,NULL,1.000,'L',3.50,2.50,40.00,83,0,'2025-11-25 10:20:50.050',NULL,1,1,NULL,'2025-11-25 10:20:50.050','2025-11-25 10:20:50.050',NULL),(84,1,84,'Água Mineral (Por L)',NULL,NULL,1.000,'L',0.70,0.50,40.00,84,0,'2025-11-25 10:20:50.057',NULL,1,1,NULL,'2025-11-25 10:20:50.057','2025-11-25 10:20:50.057',NULL),(85,1,85,'Água com Gás (Por L)',NULL,NULL,1.000,'L',0.91,0.65,40.00,85,0,'2025-11-25 10:20:50.092',NULL,1,1,NULL,'2025-11-25 10:20:50.092','2025-11-25 10:20:50.092',NULL),(86,1,86,'Vinho Tinto (Por L)',NULL,NULL,1.000,'L',10.50,7.50,40.00,86,0,'2025-11-25 10:20:50.119',NULL,1,1,NULL,'2025-11-25 10:20:50.119','2025-11-25 10:20:50.119',NULL),(87,1,87,'Vinho Branco (Por L)',NULL,NULL,1.000,'L',9.52,6.80,40.00,87,0,'2025-11-25 10:20:50.132',NULL,1,1,NULL,'2025-11-25 10:20:50.132','2025-11-25 10:20:50.132',NULL),(88,1,88,'Vinho Verde (Por L)',NULL,NULL,1.000,'L',7.70,5.50,40.00,88,0,'2025-11-25 10:20:50.152',NULL,1,1,NULL,'2025-11-25 10:20:50.152','2025-11-25 10:20:50.152',NULL),(89,1,89,'Cerveja Super Bock (Por L)',NULL,NULL,1.000,'L',1.68,1.20,40.00,89,0,'2025-11-25 10:20:50.162',NULL,1,1,NULL,'2025-11-25 10:20:50.162','2025-11-25 10:20:50.162',NULL),(90,1,90,'Cerveja Sagres (Por L)',NULL,NULL,1.000,'L',1.68,1.20,40.00,90,0,'2025-11-25 10:20:50.175',NULL,1,1,NULL,'2025-11-25 10:20:50.175','2025-11-25 10:20:50.175',NULL),(104,1,104,'Vinho do Porto (Por L)',NULL,NULL,1.000,'L',17.50,12.50,40.00,104,0,'2025-11-25 10:20:50.340',NULL,1,1,NULL,'2025-11-25 10:20:50.340','2025-11-25 10:20:50.340',NULL),(110,1,79,'Copo 0,5L',NULL,NULL,0.500,'L',2.60,0.75,246.67,79,0,'2025-11-25 15:33:22.070',NULL,1,1,NULL,'2025-11-25 15:33:22.070','2025-11-25 15:33:22.070',NULL),(111,1,86,'Copo 0,25L',NULL,NULL,0.250,'L',3.00,1.88,60.00,86,0,'2025-11-25 15:35:51.377',NULL,1,1,NULL,'2025-11-25 15:35:51.377','2025-11-25 15:35:51.377',NULL),(112,1,85,'Água com Gás Copo 33 cl',NULL,NULL,0.330,'L',1.20,0.21,459.44,85,0,'2025-12-02 19:56:08.634',NULL,1,1,NULL,'2025-12-02 19:56:08.634','2025-12-02 19:56:08.634',3),(113,1,79,'Coca-Cola Lata 33 cl',NULL,NULL,0.330,'L',2.00,0.50,304.04,NULL,0,'2025-12-03 09:17:52.121',NULL,1,1,NULL,'2025-12-03 09:17:52.121','2025-12-03 09:17:52.121',4),(114,1,111,'Pacheca Premium Douro Copo de 25 cl',NULL,NULL,0.250,'L',4.00,2.75,45.63,113,0,'2025-12-09 12:30:57.612',NULL,1,1,NULL,'2025-12-09 12:30:57.612','2025-12-09 12:30:57.612',1),(115,1,111,'Pacheca Premium Douro garrafa 75 cl',NULL,NULL,0.750,'L',16.00,8.24,94.17,113,0,'2025-12-09 16:31:21.882',NULL,1,1,NULL,'2025-12-09 16:31:21.882','2025-12-09 16:31:21.882',6),(116,1,112,'Terras do Demo garrafa 75 cl',NULL,NULL,0.750,'L',18.00,8.99,100.22,NULL,0,'2025-12-09 17:26:22.233',NULL,1,1,NULL,'2025-12-09 17:26:22.233','2025-12-09 17:26:22.233',6),(117,1,112,'Terras do Demo Copo de 25 cl',NULL,NULL,0.250,'L',5.00,3.00,66.85,114,0,'2025-12-09 17:27:58.799',NULL,1,1,NULL,'2025-12-09 17:27:58.799','2025-12-09 17:27:58.799',1);
/*!40000 ALTER TABLE `formatos_venda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fornecedores`
--

DROP TABLE IF EXISTS `fornecedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fornecedores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nif` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `morada` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fornecedores_nif_key` (`nif`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fornecedores`
--

LOCK TABLES `fornecedores` WRITE;
/*!40000 ALTER TABLE `fornecedores` DISABLE KEYS */;
INSERT INTO `fornecedores` VALUES (1,'0c794456-373d-47ae-b949-f83616b006c6','AM. Distribuição','518634108',NULL,NULL,NULL,1,'2025-12-11 18:42:16.713','2025-12-12 15:53:41.279'),(2,'3fb73f58-9411-4b57-80e8-682501d06494','FRUTAS','232431185',NULL,NULL,NULL,1,'2025-12-15 16:11:25.438','2025-12-15 16:11:25.438');
/*!40000 ALTER TABLE `fornecedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historico_precos`
--

DROP TABLE IF EXISTS `historico_precos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `historico_precos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `variacao_produto_id` int NOT NULL,
  `preco_anterior` decimal(10,2) NOT NULL,
  `preco_novo` decimal(10,2) NOT NULL,
  `preco_unitario_anterior` decimal(10,4) DEFAULT NULL,
  `preco_unitario_novo` decimal(10,4) DEFAULT NULL,
  `percentual_mudanca` decimal(5,2) NOT NULL,
  `origem` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'MANUAL',
  `alterado_por` int DEFAULT NULL,
  `receitas_afetadas` int NOT NULL DEFAULT '0',
  `menus_afetados` int NOT NULL DEFAULT '0',
  `data_mudanca` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `historico_precos_tenant_id_fkey` (`tenant_id`),
  KEY `historico_precos_variacao_produto_id_fkey` (`variacao_produto_id`),
  KEY `historico_precos_alterado_por_fkey` (`alterado_por`),
  CONSTRAINT `historico_precos_alterado_por_fkey` FOREIGN KEY (`alterado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `historico_precos_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `historico_precos_variacao_produto_id_fkey` FOREIGN KEY (`variacao_produto_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historico_precos`
--

LOCK TABLES `historico_precos` WRITE;
/*!40000 ALTER TABLE `historico_precos` DISABLE KEYS */;
INSERT INTO `historico_precos` VALUES (1,1,2,18.50,14.00,18.5000,14.0000,-24.32,'MANUAL',NULL,1,2,'2025-11-25 20:18:37.452'),(2,1,1,12.50,13.60,12.5000,13.6000,8.80,'MANUAL',NULL,0,0,'2025-11-26 13:04:50.064'),(3,1,111,8.20,8.30,0.8200,0.8300,1.22,'MANUAL',NULL,3,2,'2025-12-03 10:54:39.315'),(4,1,111,8.30,8.31,0.8300,0.8310,0.12,'MANUAL',NULL,3,2,'2025-12-03 11:57:18.513'),(5,1,111,8.31,8.20,0.8310,0.8200,-1.32,'MANUAL',NULL,3,2,'2025-12-03 12:00:59.407'),(6,1,111,8.20,8.42,0.8200,0.8420,2.68,'MANUAL',NULL,3,2,'2025-12-03 12:45:33.365'),(7,1,111,8.42,8.80,0.8420,0.8800,4.51,'MANUAL',NULL,3,2,'2025-12-03 14:52:13.128'),(8,1,112,24.00,23.00,2.4000,2.3000,-4.17,'MANUAL',NULL,3,3,'2025-12-04 21:55:52.819'),(9,1,113,0.00,8.24,0.0000,10.9867,0.00,'MANUAL',NULL,0,0,'2025-12-09 12:29:59.850'),(10,1,114,0.00,8.99,0.0000,11.9867,0.00,'MANUAL',NULL,0,0,'2025-12-09 17:26:21.850'),(11,1,123,0.00,0.60,1.2000,1.8182,51.52,'MANUAL',NULL,0,0,'2025-12-15 09:27:48.571'),(12,1,123,0.60,0.60,1.8182,0.6000,-67.00,'MANUAL',NULL,0,0,'2025-12-15 09:42:56.432'),(13,1,124,0.00,17.20,0.6000,0.7167,19.45,'MANUAL',NULL,0,0,'2025-12-15 14:58:14.307'),(14,1,98,1.80,0.99,1.8000,0.9900,-45.00,'COMPRA',NULL,0,0,'2025-12-15 16:51:03.901');
/*!40000 ALTER TABLE `historico_precos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredientes_receita`
--

DROP TABLE IF EXISTS `ingredientes_receita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredientes_receita` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `receita_id` int NOT NULL,
  `produto_id` int DEFAULT NULL,
  `receita_preparo_id` int DEFAULT NULL,
  `quantidade_bruta` decimal(10,4) NOT NULL,
  `quantidade_liquida` decimal(10,4) DEFAULT NULL,
  `rentabilidade` decimal(5,2) DEFAULT NULL,
  `unidade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `custo_ingrediente` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `ordem` int NOT NULL DEFAULT '0',
  `notas` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ingredientes_receita_tenant_id_fkey` (`tenant_id`),
  KEY `ingredientes_receita_receita_id_fkey` (`receita_id`),
  KEY `ingredientes_receita_produto_id_idx` (`produto_id`),
  KEY `ingredientes_receita_receita_preparo_id_idx` (`receita_preparo_id`),
  CONSTRAINT `ingredientes_receita_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ingredientes_receita_receita_id_fkey` FOREIGN KEY (`receita_id`) REFERENCES `receitas` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `ingredientes_receita_receita_preparo_id_fkey` FOREIGN KEY (`receita_preparo_id`) REFERENCES `receitas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ingredientes_receita_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredientes_receita`
--

LOCK TABLES `ingredientes_receita` WRITE;
/*!40000 ALTER TABLE `ingredientes_receita` DISABLE KEYS */;
INSERT INTO `ingredientes_receita` VALUES (1,1,1,35,NULL,0.2100,0.1600,76.19,'KG',0.4830,0,NULL),(2,1,1,36,NULL,0.1500,0.1200,80.00,'KG',0.1425,0,NULL),(3,1,1,37,NULL,0.1000,0.0800,80.00,'KG',0.0750,0,NULL),(4,1,1,96,NULL,0.1100,0.0800,72.73,'KG',0.2750,0,NULL),(5,1,1,97,NULL,0.1100,0.0800,72.73,'KG',0.1320,0,NULL),(6,1,1,98,NULL,0.1000,0.0800,80.00,'KG',0.0990,0,NULL),(7,1,1,99,NULL,0.1000,0.0800,80.00,'KG',0.1400,0,NULL),(8,1,1,69,NULL,0.0200,0.0200,100.00,'L',0.1700,0,NULL),(9,1,1,71,NULL,0.0050,0.0050,100.00,'KG',0.0030,0,'q.b.'),(10,1,2,9,NULL,0.9000,0.7200,80.00,'KG',6.1200,0,NULL),(11,1,2,91,NULL,0.0400,0.0400,100.00,'KG',0.1800,0,NULL),(12,1,2,70,NULL,0.0280,0.0280,100.00,'L',0.0784,0,NULL),(13,1,2,87,NULL,0.0360,0.0360,100.00,'L',0.2448,0,NULL),(14,1,2,38,NULL,0.0160,0.0120,75.00,'KG',0.1040,0,NULL),(15,1,2,92,NULL,0.0080,0.0080,100.00,'KG',0.1024,0,NULL),(16,1,2,108,NULL,0.0100,0.0080,80.00,'KG',0.0850,0,NULL),(17,1,2,93,NULL,0.0020,0.0020,100.00,'KG',0.0370,0,'4 folhas'),(18,1,2,71,NULL,0.0050,0.0050,100.00,'KG',0.0030,0,'q.b.'),(19,1,2,35,NULL,0.5000,0.4000,80.00,'KG',1.1500,0,NULL),(23,1,4,95,NULL,0.4000,0.3200,80.00,'KG',1.1200,0,'Seco, antes de demolho'),(24,1,4,100,NULL,0.2000,0.1600,80.00,'KG',1.7800,0,NULL),(25,1,4,101,NULL,0.0500,0.0400,80.00,'KG',0.3750,0,NULL),(26,1,4,102,NULL,0.0500,0.0400,80.00,'KG',0.9250,0,NULL),(27,1,4,37,NULL,0.1000,0.0800,80.00,'KG',0.0750,0,NULL),(28,1,4,108,NULL,0.0100,0.0080,80.00,'KG',0.0850,0,NULL),(29,1,4,38,NULL,0.0100,0.0080,80.00,'KG',0.0650,0,NULL),(30,1,4,93,NULL,0.0020,0.0020,100.00,'KG',0.0370,0,'4 folhas'),(31,1,4,69,NULL,0.0240,0.0240,100.00,'L',0.2040,0,NULL),(32,1,4,109,NULL,0.0020,0.0020,100.00,'KG',0.0300,0,'Temperos, q.b.'),(40,1,6,23,NULL,1.6000,1.2000,75.00,'KG',24.8000,0,'Peixe inteiro, após limpeza'),(41,1,6,69,NULL,0.0400,0.0400,100.00,'L',0.3400,0,NULL),(42,1,6,107,NULL,0.0750,0.0600,80.00,'KG',0.2100,0,NULL),(43,1,6,71,NULL,0.0080,0.0080,100.00,'KG',0.0048,0,NULL),(44,1,7,24,NULL,0.6000,0.4800,80.00,'KG',7.3800,0,'Filetes limpos'),(45,1,7,107,NULL,0.0500,0.0400,80.00,'KG',0.1400,0,NULL),(46,1,7,67,NULL,0.0600,0.0600,100.00,'KG',0.0510,0,NULL),(47,1,7,44,NULL,0.1500,0.1200,80.00,'KG',0.2700,0,NULL),(48,1,7,65,NULL,0.2400,0.2400,100.00,'KG',0.2880,0,NULL),(49,1,7,37,NULL,0.0750,0.0600,80.00,'KG',0.0563,0,NULL),(50,1,7,38,NULL,0.0150,0.0120,80.00,'KG',0.0975,0,NULL),(51,1,7,69,NULL,0.0320,0.0320,100.00,'L',0.2720,0,NULL),(52,1,7,108,NULL,0.0100,0.0080,80.00,'KG',0.0850,0,NULL),(59,1,9,73,NULL,0.0800,0.0800,100.00,'KG',0.0704,0,NULL),(60,1,9,53,NULL,0.1600,0.1600,100.00,'L',0.1520,0,NULL),(61,1,9,104,NULL,0.0080,0.0080,100.00,'L',0.1000,0,NULL),(62,1,9,107,NULL,0.0050,0.0040,80.00,'KG',0.0140,0,'Casca citrinos'),(63,1,10,105,NULL,0.1200,0.1200,100.00,'KG',1.0200,0,NULL),(64,1,10,63,NULL,0.0800,0.0800,100.00,'KG',0.6000,0,NULL),(65,1,10,73,NULL,0.0800,0.0800,100.00,'KG',0.0704,0,NULL),(66,1,10,67,NULL,0.0400,0.0400,100.00,'KG',0.0340,0,NULL),(67,1,10,106,NULL,0.2000,0.2000,100.00,'KG',2.4000,0,'4 bolas, ~50g cada'),(68,1,5,2,NULL,0.9000,0.7200,80.00,'KG',12.6000,0,'Bife lombo cru'),(69,1,5,102,NULL,0.0750,0.0600,80.00,'KG',1.3875,0,''),(70,1,5,35,NULL,0.6000,0.4800,80.00,'KG',1.3800,0,''),(71,1,5,38,NULL,0.0100,0.0080,80.00,'KG',0.0650,0,''),(72,1,5,87,NULL,0.0400,0.0400,100.00,'L',0.2720,0,''),(73,1,5,69,NULL,0.0320,0.0320,100.00,'L',0.2720,0,''),(74,1,5,93,NULL,0.0020,0.0020,100.00,'KG',0.0370,0,'4 folhas'),(75,1,3,65,NULL,0.2400,0.2400,100.00,'KG',0.2880,0,''),(76,1,3,71,NULL,0.0080,0.0080,100.00,'KG',0.0048,0,''),(77,1,3,70,NULL,0.0120,0.0120,100.00,'L',0.0336,0,''),(118,1,8,53,NULL,0.3200,0.3200,100.00,'L',0.3040,0,''),(119,1,8,73,NULL,0.0640,0.0640,100.00,'KG',0.0563,0,''),(120,1,8,107,NULL,0.0100,0.0080,80.00,'KG',0.0280,0,'Casca de limão'),(121,1,8,103,NULL,0.0160,0.0160,100.00,'KG',0.0512,0,''),(122,1,8,94,NULL,0.0040,0.0040,100.00,'KG',0.0960,0,'2 unidades'),(123,1,8,73,NULL,0.0200,0.0200,100.00,'KG',0.0176,0,'Para queimar');
/*!40000 ALTER TABLE `ingredientes_receita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integracoes`
--

DROP TABLE IF EXISTS `integracoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integracoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `tipo_integracao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `provedor` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT '1',
  `configuracao` json DEFAULT NULL,
  `ultimo_sync` datetime(3) DEFAULT NULL,
  `status_ultimo_sync` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mensagem_erro` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `integracoes_tenant_id_fkey` (`tenant_id`),
  KEY `integracoes_criado_por_fkey` (`criado_por`),
  CONSTRAINT `integracoes_criado_por_fkey` FOREIGN KEY (`criado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `integracoes_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integracoes`
--

LOCK TABLES `integracoes` WRITE;
/*!40000 ALTER TABLE `integracoes` DISABLE KEYS */;
/*!40000 ALTER TABLE `integracoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_templates`
--

DROP TABLE IF EXISTS `invoice_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fornecedor_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_version` int NOT NULL DEFAULT '1',
  `header_config` json NOT NULL,
  `table_config` json NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `confidence_score` double NOT NULL DEFAULT '0',
  `times_used` int NOT NULL DEFAULT '0',
  `times_successful` int NOT NULL DEFAULT '0',
  `created_from_ai` tinyint(1) NOT NULL DEFAULT '0',
  `ai_prompt_used` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_by_tenant` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_templates_fornecedor_id_key` (`fornecedor_id`),
  KEY `invoice_templates_fornecedor_id_idx` (`fornecedor_id`),
  KEY `invoice_templates_is_active_idx` (`is_active`),
  KEY `invoice_templates_created_by_tenant_fkey` (`created_by_tenant`),
  CONSTRAINT `invoice_templates_created_by_tenant_fkey` FOREIGN KEY (`created_by_tenant`) REFERENCES `tenants` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `invoice_templates_fornecedor_id_fkey` FOREIGN KEY (`fornecedor_id`) REFERENCES `fornecedores` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_templates`
--

LOCK TABLES `invoice_templates` WRITE;
/*!40000 ALTER TABLE `invoice_templates` DISABLE KEYS */;
INSERT INTO `invoice_templates` VALUES (1,1,'81e5652e-c100-49c8-93e8-e3e7f9e5f845','Coelho & Dias. SA - Auto-generated',1,'{\"nif_pattern\": \"NIF[:\\\\s]+(\\\\d{9})\", \"data_pattern\": \"Data[:\\\\s]+(\\\\d{2}[-\\\\/]\\\\d{2}[-\\\\/]\\\\d{4})\", \"nome_pattern\": \"^([A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝ\\\\s&.,]+)$\", \"total_pattern\": \"Total[:\\\\s]+EUR?[:\\\\s]+([\\\\d.,]+)\", \"numero_fatura_pattern\": \"FT[TV]?[:\\\\s]+([A-Z0-9\\\\/\\\\-]+)\"}','{\"columns\": [{\"name\": \"descricao\", \"type\": \"string\", \"index\": 0}, {\"name\": \"quantidade\", \"type\": \"number\", \"index\": 1}, {\"name\": \"unidade\", \"type\": \"string\", \"index\": 2}, {\"name\": \"precoUnitario\", \"type\": \"number\", \"index\": 3}, {\"name\": \"precoTotal\", \"type\": \"number\", \"index\": 4}], \"end_marker\": \"RESUMO|TOTAL|OBSERVA[ÇC]\", \"row_pattern\": \"^(.+?)\\\\s+([\\\\d.,]+)\\\\s+(\\\\w+)\\\\s+([\\\\d.,]+)\\\\s+([\\\\d.,]+)$\", \"start_marker\": \"PRODUTO|DESCRI[ÇC][ÃA]O|ARTIGO\"}',1,60,0,0,1,NULL,1,'2025-12-11 18:42:16.724','2025-12-11 18:42:16.724'),(2,2,'ec0a4473-1272-415b-9995-af02717717db','FRUTAS - Auto-generated',1,'{\"nif_pattern\": \"NIF[:\\\\s]+(\\\\d{9})\", \"data_pattern\": \"Data[:\\\\s]+(\\\\d{2}[-\\\\/]\\\\d{2}[-\\\\/]\\\\d{4})\", \"nome_pattern\": \"^([A-ZÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝ\\\\s&.,]+)$\", \"total_pattern\": \"Total[:\\\\s]+EUR?[:\\\\s]+([\\\\d.,]+)\", \"numero_fatura_pattern\": \"FT[TV]?[:\\\\s]+([A-Z0-9\\\\/\\\\-]+)\"}','{\"columns\": [{\"name\": \"descricao\", \"type\": \"string\", \"index\": 0}, {\"name\": \"quantidade\", \"type\": \"number\", \"index\": 1}, {\"name\": \"unidade\", \"type\": \"string\", \"index\": 2}, {\"name\": \"precoUnitario\", \"type\": \"number\", \"index\": 3}, {\"name\": \"precoTotal\", \"type\": \"number\", \"index\": 4}], \"end_marker\": \"RESUMO|TOTAL|OBSERVA[ÇC]\", \"row_pattern\": \"^(.+?)\\\\s+([\\\\d.,]+)\\\\s+(\\\\w+)\\\\s+([\\\\d.,]+)\\\\s+([\\\\d.,]+)$\", \"start_marker\": \"PRODUTO|DESCRI[ÇC][ÃA]O|ARTIGO\"}',1,60,0,0,1,NULL,1,'2025-12-15 16:11:25.475','2025-12-15 16:11:25.475');
/*!40000 ALTER TABLE `invoice_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `itens_inventario`
--

DROP TABLE IF EXISTS `itens_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itens_inventario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `sessao_id` int NOT NULL,
  `produto_id` int NOT NULL,
  `variacao_id` int DEFAULT NULL,
  `localizacao_id` int DEFAULT NULL,
  `quantidade_contada` decimal(10,4) NOT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `custo_unitario` decimal(10,4) DEFAULT NULL,
  `valor_total` decimal(10,2) DEFAULT NULL,
  `observacoes` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itens_inventario_tenant_id_fkey` (`tenant_id`),
  KEY `itens_inventario_sessao_id_fkey` (`sessao_id`),
  KEY `itens_inventario_produto_id_fkey` (`produto_id`),
  KEY `itens_inventario_variacao_id_fkey` (`variacao_id`),
  KEY `itens_inventario_localizacao_id_fkey` (`localizacao_id`),
  KEY `itens_inventario_contado_por_fkey` (`contado_por`),
  CONSTRAINT `itens_inventario_contado_por_fkey` FOREIGN KEY (`contado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `itens_inventario_localizacao_id_fkey` FOREIGN KEY (`localizacao_id`) REFERENCES `localizacoes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `itens_inventario_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `itens_inventario_sessao_id_fkey` FOREIGN KEY (`sessao_id`) REFERENCES `sessoes_inventario` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `itens_inventario_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `itens_inventario_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itens_inventario`
--

LOCK TABLES `itens_inventario` WRITE;
/*!40000 ALTER TABLE `itens_inventario` DISABLE KEYS */;
INSERT INTO `itens_inventario` VALUES (1,1,1,1,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(2,1,1,2,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(3,1,1,3,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(4,1,1,4,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(5,1,1,5,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(6,1,1,6,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(7,1,1,7,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(8,1,1,8,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(9,1,1,9,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(10,1,1,10,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(11,1,1,11,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(12,1,1,12,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(13,1,1,13,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(14,1,1,14,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(15,1,1,15,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(16,1,1,16,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(17,1,1,17,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(18,1,1,18,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(19,1,1,19,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(20,1,1,20,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(21,1,1,21,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(22,1,1,22,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(23,1,1,23,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(24,1,1,24,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(25,1,1,25,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(26,1,1,26,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(27,1,1,27,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(28,1,1,28,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(29,1,1,29,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(30,1,1,30,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(31,1,1,31,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(32,1,1,32,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(33,1,1,33,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(34,1,1,34,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(35,1,1,35,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(36,1,1,36,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(37,1,1,37,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(38,1,1,38,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(39,1,1,39,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(40,1,1,40,NULL,NULL,0.0000,'Unidade',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(41,1,1,41,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(42,1,1,42,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(43,1,1,43,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(44,1,1,44,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(45,1,1,45,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(46,1,1,46,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(47,1,1,47,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(48,1,1,48,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(49,1,1,49,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(50,1,1,50,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(51,1,1,51,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(52,1,1,52,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(53,1,1,53,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(54,1,1,54,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(55,1,1,55,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(56,1,1,56,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(57,1,1,57,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(58,1,1,58,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(59,1,1,59,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(60,1,1,60,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(61,1,1,61,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(62,1,1,62,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(63,1,1,63,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(64,1,1,64,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(65,1,1,65,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(66,1,1,66,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(67,1,1,67,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(68,1,1,68,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(69,1,1,69,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(70,1,1,70,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(71,1,1,71,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(72,1,1,72,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(73,1,1,73,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(74,1,1,74,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(75,1,1,75,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(76,1,1,76,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(77,1,1,77,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(78,1,1,78,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(79,1,1,79,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(80,1,1,80,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(81,1,1,81,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(82,1,1,82,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(83,1,1,83,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(84,1,1,84,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(85,1,1,85,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(86,1,1,86,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(87,1,1,87,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(88,1,1,88,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(89,1,1,89,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(90,1,1,90,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(91,1,1,91,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(92,1,1,92,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(93,1,1,93,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(94,1,1,94,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(95,1,1,95,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(96,1,1,96,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(97,1,1,97,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(98,1,1,98,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(99,1,1,99,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(100,1,1,100,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(101,1,1,101,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(102,1,1,102,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(103,1,1,103,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(104,1,1,104,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(105,1,1,105,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(106,1,1,106,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(107,1,1,107,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(108,1,1,108,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(109,1,1,109,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(110,1,1,110,NULL,NULL,0.0000,'Unidade',NULL,NULL,NULL,NULL,'2025-12-04 20:49:14.622','2025-12-04 20:49:14.622'),(111,1,1,48,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,1,'2025-12-04 20:49:54.466','2025-12-04 20:49:54.466'),(112,1,2,1,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(113,1,2,2,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(114,1,2,3,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(115,1,2,4,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(116,1,2,5,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(117,1,2,6,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(118,1,2,7,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(119,1,2,8,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(120,1,2,9,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(121,1,2,10,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(122,1,2,11,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(123,1,2,12,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(124,1,2,13,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(125,1,2,14,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(126,1,2,15,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(127,1,2,16,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(128,1,2,17,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(129,1,2,18,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(130,1,2,19,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(131,1,2,20,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(132,1,2,21,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(133,1,2,22,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(134,1,2,23,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(135,1,2,24,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(136,1,2,25,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(137,1,2,26,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(138,1,2,27,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(139,1,2,28,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(140,1,2,29,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(141,1,2,30,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(142,1,2,31,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(143,1,2,32,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(144,1,2,33,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(145,1,2,34,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(146,1,2,35,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(147,1,2,36,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(148,1,2,37,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(149,1,2,38,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(150,1,2,39,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(151,1,2,40,NULL,NULL,0.0000,'Unidade',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(152,1,2,41,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(153,1,2,42,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(154,1,2,43,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(155,1,2,44,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(156,1,2,45,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(157,1,2,46,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(158,1,2,47,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(159,1,2,48,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(160,1,2,49,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(161,1,2,50,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(162,1,2,51,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(163,1,2,52,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(164,1,2,53,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(165,1,2,54,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(166,1,2,55,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(167,1,2,56,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(168,1,2,57,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(169,1,2,58,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(170,1,2,59,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(171,1,2,60,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(172,1,2,61,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(173,1,2,62,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(174,1,2,63,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(175,1,2,64,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(176,1,2,65,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(177,1,2,66,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(178,1,2,67,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(179,1,2,68,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(180,1,2,69,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(181,1,2,70,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(182,1,2,71,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(183,1,2,72,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(184,1,2,73,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(185,1,2,74,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(186,1,2,75,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(187,1,2,76,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(188,1,2,77,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(189,1,2,78,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(190,1,2,79,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(191,1,2,80,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(192,1,2,81,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(193,1,2,82,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(194,1,2,83,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(195,1,2,84,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(196,1,2,85,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(197,1,2,86,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(198,1,2,87,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(199,1,2,88,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(200,1,2,89,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(201,1,2,90,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(202,1,2,91,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(203,1,2,92,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(204,1,2,93,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(205,1,2,94,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(206,1,2,95,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(207,1,2,96,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(208,1,2,97,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(209,1,2,98,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(210,1,2,99,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(211,1,2,100,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(212,1,2,101,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(213,1,2,102,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(214,1,2,103,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(215,1,2,104,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(216,1,2,105,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(217,1,2,106,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(218,1,2,107,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(219,1,2,108,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(220,1,2,109,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(221,1,2,110,NULL,NULL,0.0000,'Unidade',NULL,NULL,NULL,NULL,'2025-12-04 20:51:38.897','2025-12-04 20:51:38.897'),(222,1,3,2,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(223,1,3,35,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(224,1,3,38,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(225,1,3,69,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(226,1,3,87,NULL,NULL,0.0000,'L',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(227,1,3,93,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(228,1,3,102,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,NULL,'2025-12-04 21:07:33.233','2025-12-04 21:07:33.233'),(229,1,3,35,NULL,NULL,0.0000,'KG',NULL,NULL,NULL,1,'2025-12-04 21:10:35.715','2025-12-04 21:10:35.715');
/*!40000 ALTER TABLE `itens_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `listas_calculadora`
--

DROP TABLE IF EXISTS `listas_calculadora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `listas_calculadora` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `itens` json NOT NULL,
  `criado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `listas_calculadora_tenant_id_fkey` (`tenant_id`),
  KEY `listas_calculadora_criado_por_fkey` (`criado_por`),
  CONSTRAINT `listas_calculadora_criado_por_fkey` FOREIGN KEY (`criado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `listas_calculadora_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `listas_calculadora`
--

LOCK TABLES `listas_calculadora` WRITE;
/*!40000 ALTER TABLE `listas_calculadora` DISABLE KEYS */;
INSERT INTO `listas_calculadora` VALUES (1,1,'sabado',NULL,'[{\"id\": 2, \"tipo\": \"produto\", \"quantidade\": 2.7}, {\"id\": 102, \"tipo\": \"produto\", \"quantidade\": 0.225}, {\"id\": 35, \"tipo\": \"produto\", \"quantidade\": 1.8}, {\"id\": 69, \"tipo\": \"produto\", \"quantidade\": 0.096}, {\"id\": 87, \"tipo\": \"produto\", \"quantidade\": 0.12}, {\"id\": 38, \"tipo\": \"produto\", \"quantidade\": 0.03}, {\"id\": 93, \"tipo\": \"produto\", \"quantidade\": 0.006}]',1,'2025-12-04 20:48:29.712','2025-12-04 20:48:29.712');
/*!40000 ALTER TABLE `listas_calculadora` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localizacoes`
--

DROP TABLE IF EXISTS `localizacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `localizacoes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `localizacoes_tenant_id_nome_key` (`tenant_id`,`nome`),
  CONSTRAINT `localizacoes_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localizacoes`
--

LOCK TABLES `localizacoes` WRITE;
/*!40000 ALTER TABLE `localizacoes` DISABLE KEYS */;
INSERT INTO `localizacoes` VALUES (1,1,'Arca frigorifica 1','',1,'2025-12-04 21:27:42.095','2025-12-04 21:27:42.095'),(2,1,'Armazem','',1,'2025-12-04 21:27:52.537','2025-12-04 21:27:52.537'),(3,1,'Arca frigorifica 2','',1,'2025-12-04 21:28:15.253','2025-12-04 21:28:15.253'),(4,1,'Frigorifico Branco','',1,'2025-12-04 21:28:32.403','2025-12-04 21:28:32.403'),(5,1,'Frigorifico Cinza','',1,'2025-12-04 21:28:46.078','2025-12-04 21:28:46.078'),(6,1,'Garrafeira de frio de Bar','',1,'2025-12-04 21:29:08.034','2025-12-04 21:29:08.034'),(7,1,'Garrafeira exposta 1','Garrafeira exposta do Restaurante',1,'2025-12-04 21:29:44.545','2025-12-04 21:29:44.545');
/*!40000 ALTER TABLE `localizacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mapeamento_pos`
--

DROP TABLE IF EXISTS `mapeamento_pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mapeamento_pos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `integracao_id` int NOT NULL,
  `pos_item_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pos_item_nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_item_id` int NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mapeamento_pos_tenant_id_integracao_id_pos_item_id_key` (`tenant_id`,`integracao_id`,`pos_item_id`),
  KEY `mapeamento_pos_integracao_id_fkey` (`integracao_id`),
  KEY `mapeamento_pos_menu_item_id_fkey` (`menu_item_id`),
  CONSTRAINT `mapeamento_pos_integracao_id_fkey` FOREIGN KEY (`integracao_id`) REFERENCES `integracoes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `mapeamento_pos_menu_item_id_fkey` FOREIGN KEY (`menu_item_id`) REFERENCES `menu` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `mapeamento_pos_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mapeamento_pos`
--

LOCK TABLES `mapeamento_pos` WRITE;
/*!40000 ALTER TABLE `mapeamento_pos` DISABLE KEYS */;
/*!40000 ALTER TABLE `mapeamento_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matching_historico`
--

DROP TABLE IF EXISTS `matching_historico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matching_historico` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `descricao_fatura` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fornecedor_nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `produto_id` int NOT NULL,
  `variacao_id` int DEFAULT NULL,
  `confianca_inicial` decimal(5,2) DEFAULT NULL,
  `confirmado_por` int NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `matching_historico_tenant_id_descricao_fatura_idx` (`tenant_id`,`descricao_fatura`),
  KEY `matching_historico_produto_id_idx` (`produto_id`),
  KEY `matching_historico_variacao_id_fkey` (`variacao_id`),
  KEY `matching_historico_confirmado_por_fkey` (`confirmado_por`),
  CONSTRAINT `matching_historico_confirmado_por_fkey` FOREIGN KEY (`confirmado_por`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `matching_historico_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `matching_historico_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `matching_historico_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matching_historico`
--

LOCK TABLES `matching_historico` WRITE;
/*!40000 ALTER TABLE `matching_historico` DISABLE KEYS */;
INSERT INTO `matching_historico` VALUES (1,1,'SUPER BOCK TR 0,331 x 24',NULL,89,NULL,NULL,1,'2025-12-12 17:10:08.171'),(2,1,'SAGRES mini TR 020Lx24',NULL,90,NULL,NULL,1,'2025-12-12 17:29:02.740'),(3,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:08:50.308'),(4,1,'SAGRES TR 0331x24',NULL,90,90,NULL,1,'2025-12-12 18:09:00.196'),(5,1,'COCA-COLA TR 0,35L x 24',NULL,79,79,NULL,1,'2025-12-12 18:10:06.291'),(6,1,'SAGRES TR 0331x24',NULL,90,90,NULL,1,'2025-12-12 18:15:16.206'),(7,1,'SAGRES mini TR 020Lx24',NULL,90,90,NULL,1,'2025-12-12 18:17:33.429'),(8,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:26:18.571'),(9,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:31:38.732'),(10,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:36:27.027'),(11,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:43:31.334'),(12,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-12 18:52:01.914'),(13,1,'SUPER BOCK TR 0,331 x 24',NULL,89,89,NULL,1,'2025-12-15 09:18:32.243'),(14,1,'SUPER BOCK TR 0,331 x 24',NULL,89,123,NULL,1,'2025-12-15 09:30:10.526'),(15,1,'SUPER BOCK TR 0,331 x 24',NULL,89,123,NULL,1,'2025-12-15 09:44:43.676'),(16,1,'SUPER BOCK TR 0,331 x 24',NULL,89,123,NULL,1,'2025-12-15 09:48:58.243'),(17,1,'SB mini TR 0,20L x 30',NULL,89,NULL,NULL,1,'2025-12-15 10:10:04.830'),(18,1,'SB mini TR 0,20L x 30',NULL,89,NULL,NULL,1,'2025-12-15 10:10:20.405'),(19,1,'SB mini TR 0,20L x 30',NULL,89,NULL,NULL,1,'2025-12-15 10:11:17.655'),(20,1,'SUPER BOCK TR 0,331 x 24',NULL,89,124,NULL,1,'2025-12-15 15:23:54.188'),(21,1,'TOMATE GR CAT II PORTUGAL',NULL,44,44,NULL,1,'2025-12-15 16:12:39.968'),(22,1,'ALFACE FRISADA CAT II PORTUGAL',NULL,40,40,NULL,1,'2025-12-15 16:12:53.711'),(23,1,'CENOURA CAT I ESPANHA',NULL,36,36,NULL,1,'2025-12-15 16:12:58.275'),(24,1,'PIMENTO VERMELHO CAT II PAISES BAIXOS',NULL,45,45,NULL,1,'2025-12-15 16:13:14.973'),(25,1,'TOMATE GR CAT II PORTUGAL',NULL,44,44,NULL,1,'2025-12-15 16:50:19.455'),(26,1,'ALFACE FRISADA CAT II PORTUGAL',NULL,40,40,NULL,1,'2025-12-15 16:50:30.854'),(27,1,'CENOURA CAT I ESPANHA',NULL,36,36,NULL,1,'2025-12-15 16:50:34.530'),(28,1,'PIMENTO VERMELHO CAT II PAISES BAIXOS',NULL,45,45,NULL,1,'2025-12-15 16:50:39.432'),(29,1,'CORGETS CAT II PORTUGAL MARROCOS',NULL,98,98,NULL,1,'2025-12-15 16:50:54.486');
/*!40000 ALTER TABLE `matching_historico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `receita_id` int DEFAULT NULL,
  `combo_id` int DEFAULT NULL,
  `formato_venda_id` int DEFAULT NULL,
  `nome_comercial` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pvp` decimal(10,2) NOT NULL,
  `margem_bruta` decimal(10,2) DEFAULT NULL,
  `margem_percentual` decimal(5,2) DEFAULT NULL,
  `cmv_percentual` decimal(5,2) DEFAULT NULL,
  `categoria_menu` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao_menu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `alergenos` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calorias` int DEFAULT NULL,
  `tempo_servico` int DEFAULT NULL,
  `posicao_menu` int NOT NULL DEFAULT '0',
  `destacado` tinyint(1) NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `imagem_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_tenant_id_fkey` (`tenant_id`),
  KEY `menu_receita_id_fkey` (`receita_id`),
  KEY `menu_combo_id_fkey` (`combo_id`),
  KEY `menu_formato_venda_id_fkey` (`formato_venda_id`),
  CONSTRAINT `menu_combo_id_fkey` FOREIGN KEY (`combo_id`) REFERENCES `combos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `menu_formato_venda_id_fkey` FOREIGN KEY (`formato_venda_id`) REFERENCES `formatos_venda` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `menu_receita_id_fkey` FOREIGN KEY (`receita_id`) REFERENCES `receitas` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `menu_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,1,'a28ee0e8-72dd-4fa2-a4e1-6c9a808079f6',5,NULL,NULL,'Bife à Portuguesa',9.50,5.50,57.86,42.14,'Principais',NULL,NULL,NULL,NULL,0,0,1,NULL,'2025-11-25 16:43:17.549','2025-12-04 21:55:52.802'),(2,1,'52e70bb3-4931-4441-990a-e00f11054db7',NULL,1,NULL,'Combo de bife à portuguesa -sopa- Prato- Agua -Sobremesa',13.00,7.83,60.22,39.78,'Combos',NULL,NULL,NULL,NULL,0,0,1,NULL,'2025-11-25 16:43:54.654','2025-12-15 16:51:04.039'),(3,1,'cadfca5e-48de-4205-a021-dc6902d95229',6,NULL,NULL,'Dourada Grelhada',13.00,6.66,51.24,48.76,'Principais',NULL,NULL,NULL,NULL,0,0,1,NULL,'2025-11-25 16:44:31.640','2025-12-04 10:36:54.368'),(4,1,'eab9b227-c090-4e3a-a04b-220b90a7e445',8,NULL,NULL,'Leite Creme',3.50,3.36,96.05,3.95,'Sobremesas',NULL,NULL,NULL,NULL,0,0,1,NULL,'2025-11-25 16:45:18.662','2025-12-03 16:11:05.729'),(5,1,'0d62b62c-1cb9-4d28-8c45-4e6aedae7bc9',NULL,NULL,111,'Copo 0,25L',6.50,4.62,71.08,28.92,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-11-25 18:04:52.119','2025-12-04 10:40:09.052'),(6,1,'ac5286b0-1b14-43bb-91e4-1cc88c288a25',NULL,2,NULL,'Dourada Grelhada - Sopa - Prato- Bebida',14.50,4.98,34.35,65.65,'Combos','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-01 18:30:06.755','2025-12-15 16:51:04.038'),(7,1,'053d1ccd-6cf5-436f-8dde-437bcffecaae',NULL,NULL,112,'Água com Gás Copo 33 cl',1.25,1.04,83.20,16.80,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-02 19:57:34.871','2025-12-04 10:37:50.382'),(8,1,'3e2ecaef-fbbd-4335-aa04-606d27d96d20',NULL,NULL,113,'Coca-Cola Lata 33 cl',2.20,1.70,77.27,22.73,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-03 09:19:47.756','2025-12-04 10:37:08.729'),(9,1,'ab7c16c0-5613-46ed-b599-816b5e480766',NULL,NULL,114,'Pacheca Premium Douro Copo de 25 cl',4.00,1.25,31.25,68.75,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-09 12:31:25.480','2025-12-09 12:31:25.480'),(10,1,'1d9398be-939e-484f-8a62-6ecc31133a24',NULL,NULL,116,'Terras do Demo garrafa 75 cl',18.00,9.01,50.06,49.94,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-09 17:27:18.502','2025-12-09 17:27:18.502'),(11,1,'1282e379-d040-4850-82e3-0d0f57133668',NULL,NULL,117,'Terras do Demo Copo de 25 cl',7.00,4.00,57.14,42.86,'Bebidas','',NULL,NULL,NULL,0,0,1,NULL,'2025-12-09 17:28:39.398','2025-12-09 17:28:39.398');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime(3) NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_resets_token_key` (`token`),
  KEY `password_resets_token_idx` (`token`),
  KEY `password_resets_user_id_idx` (`user_id`),
  CONSTRAINT `password_resets_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `produtos`
--

DROP TABLE IF EXISTS `produtos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produtos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `familia_id` int DEFAULT NULL,
  `subfamilia_id` int NOT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `imagem_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_interno` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendavel` tinyint(1) NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `produtos_tenant_id_subfamilia_id_nome_key` (`tenant_id`,`subfamilia_id`,`nome`),
  KEY `produtos_subfamilia_id_fkey` (`subfamilia_id`),
  CONSTRAINT `produtos_subfamilia_id_fkey` FOREIGN KEY (`subfamilia_id`) REFERENCES `subfamilias` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `produtos_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produtos`
--

LOCK TABLES `produtos` WRITE;
/*!40000 ALTER TABLE `produtos` DISABLE KEYS */;
INSERT INTO `produtos` VALUES (1,1,'a50386b1-1475-4818-a32a-dba8720eba35','Alcatra',NULL,2,'KG','','','CAR-BOV-001',0,1,'2025-11-24 17:06:02.872','2025-11-26 13:05:04.316'),(2,1,'d12d4b6a-1bf1-4d9a-ba5f-9455d3d674f4','Vazia',NULL,36,'KG',NULL,NULL,'CAR-BOV-002',0,1,'2025-11-24 17:06:02.891','2025-11-25 15:53:59.884'),(3,1,'1f8606bf-4283-4de7-bb06-41ba7361e81f','Lombo',NULL,36,'KG',NULL,NULL,'CAR-BOV-003',0,1,'2025-11-24 17:06:02.907','2025-11-25 15:53:59.884'),(4,1,'1d78fc5e-b86b-45a2-bad7-3520a3e81fa2','Picanha',NULL,36,'KG',NULL,NULL,'CAR-BOV-004',0,1,'2025-11-24 17:06:02.919','2025-11-25 15:53:59.884'),(5,1,'4209ca13-8ca6-459a-9b9b-3ebf7f1f4abd','Maminha',NULL,36,'KG',NULL,NULL,'CAR-BOV-005',0,1,'2025-11-24 17:06:02.932','2025-11-25 15:53:59.884'),(6,1,'aa534969-91fd-4d33-9d55-9514a70c5418','Fraldinha',NULL,36,'KG',NULL,NULL,'CAR-BOV-006',0,1,'2025-11-24 17:06:02.950','2025-11-25 15:53:59.884'),(7,1,'41eeefbd-db13-4483-9281-ad73804b40a7','Contra-Filé',NULL,36,'KG',NULL,NULL,'CAR-BOV-007',0,1,'2025-11-24 17:06:02.965','2025-11-25 15:53:59.884'),(8,1,'fd49ba7c-25fc-4cb0-a8c3-b6704a8ead84','Filé Mignon',NULL,36,'KG',NULL,NULL,'CAR-BOV-008',0,1,'2025-11-24 17:06:02.981','2025-11-25 15:53:59.884'),(9,1,'8b65c518-6721-4126-807b-5f07b50b312e','Lombo de Porco',NULL,37,'KG',NULL,NULL,'CAR-SUI-001',0,1,'2025-11-24 17:06:03.002','2025-11-25 15:53:59.884'),(10,1,'198bcabd-5422-485f-8684-90863e2c19a6','Costela de Porco',NULL,37,'KG',NULL,NULL,'CAR-SUI-002',0,1,'2025-11-24 17:06:03.015','2025-11-25 15:53:59.884'),(11,1,'dd084c00-2a0c-4255-9d1e-542b1f73a866','Barriga de Porco',NULL,37,'KG',NULL,NULL,'CAR-SUI-003',0,1,'2025-11-24 17:06:03.029','2025-11-25 15:53:59.884'),(12,1,'ea6e456e-c8b6-49f3-a9a3-70c9b5fca16b','Entrecosto',NULL,37,'KG',NULL,NULL,'CAR-SUI-004',0,1,'2025-11-24 17:06:03.048','2025-11-25 15:53:59.884'),(13,1,'e71d6202-4de4-4499-996f-64317c2bd9e5','Peito de Frango',NULL,38,'KG',NULL,NULL,'CAR-AVE-001',0,1,'2025-11-24 17:06:03.076','2025-11-25 15:53:59.884'),(14,1,'4c77b89f-e6b7-45d1-b56d-e569508ac246','Coxa de Frango',NULL,38,'KG',NULL,NULL,'CAR-AVE-002',0,1,'2025-11-24 17:06:03.098','2025-11-25 15:53:59.884'),(15,1,'030b0d24-635c-429a-831f-9dd9859e8019','Asa de Frango',NULL,38,'KG',NULL,NULL,'CAR-AVE-003',0,1,'2025-11-24 17:06:03.113','2025-11-25 15:53:59.884'),(16,1,'92af8c00-147a-40f7-b51f-ef25f7fc990a','Frango Inteiro',NULL,38,'KG',NULL,NULL,'CAR-AVE-004',0,1,'2025-11-24 17:06:03.128','2025-11-25 15:53:59.884'),(17,1,'f3f166f6-e66b-43b8-8a67-7b6ad143bf93','Peru',NULL,38,'KG',NULL,NULL,'CAR-AVE-005',0,1,'2025-11-24 17:06:03.139','2025-11-25 15:53:59.884'),(18,1,'fb0b3672-8e7d-4938-a720-7d0d2ca0d336','Pato',NULL,38,'KG',NULL,NULL,'CAR-AVE-006',0,1,'2025-11-24 17:06:03.154','2025-11-25 15:53:59.884'),(19,1,'372fb24f-3f8f-489b-bd6f-f71ec9c0a2e8','Bacalhau do Porto',NULL,6,'KG',NULL,NULL,'PEI-BAC-001',0,1,'2025-11-24 17:06:03.169','2025-11-25 15:53:59.884'),(20,1,'5002b3fb-672c-4f13-8957-25ad69947dff','Bacalhau Crescido',NULL,6,'KG',NULL,NULL,'PEI-BAC-002',0,1,'2025-11-24 17:06:03.199','2025-11-25 15:53:59.884'),(21,1,'06458173-7ff0-4850-9a54-627d383dd796','Bacalhau Demolhado',NULL,6,'KG',NULL,NULL,'PEI-BAC-003',0,1,'2025-11-24 17:06:03.215','2025-11-25 15:53:59.884'),(22,1,'e31ae905-e12d-4e1d-bdbb-d8eeb1373ec9','Robalo',NULL,39,'KG',NULL,NULL,'PEI-PBR-001',0,1,'2025-11-24 17:06:03.233','2025-11-25 15:53:59.884'),(23,1,'c17e3bd3-2d77-46e6-98af-28ba3753bc83','Dourada',NULL,39,'KG',NULL,NULL,'PEI-PBR-002',0,1,'2025-11-24 17:06:03.244','2025-11-25 15:53:59.884'),(24,1,'c8200218-da2c-4206-a9a6-54f2c469dfaf','Pescada',NULL,39,'KG',NULL,NULL,'PEI-PBR-003',0,1,'2025-11-24 17:06:03.255','2025-11-25 15:53:59.884'),(25,1,'1204369f-144e-4632-b635-27e06d3d05fc','Linguado',NULL,39,'KG',NULL,NULL,'PEI-PBR-004',0,1,'2025-11-24 17:06:03.268','2025-11-25 15:53:59.884'),(26,1,'e7f41ba1-0e11-4a6d-aa08-ca6f4395f1d1','Salmão',NULL,40,'KG',NULL,NULL,'PEI-PAZ-001',0,1,'2025-11-24 17:06:03.296','2025-11-25 15:53:59.884'),(27,1,'5c068187-974d-46cb-90d2-a92ecc95194a','Atum',NULL,40,'KG',NULL,NULL,'PEI-PAZ-002',0,1,'2025-11-24 17:06:03.309','2025-11-25 15:53:59.884'),(28,1,'a786bdac-c32c-4a03-adfc-5f0b6b487ee8','Sardinha',NULL,40,'KG',NULL,NULL,'PEI-PAZ-003',0,1,'2025-11-24 17:06:03.336','2025-11-25 15:53:59.884'),(29,1,'db621619-e0a6-4525-84c8-bf0b61e232b7','Cavala',NULL,40,'KG',NULL,NULL,'PEI-PAZ-004',0,1,'2025-11-24 17:06:03.358','2025-11-25 15:53:59.884'),(30,1,'2a047c94-3c96-434b-977f-2cf0815bda37','Camarão',NULL,41,'KG',NULL,NULL,'PEI-MAR-001',0,1,'2025-11-24 17:06:03.385','2025-11-25 15:53:59.884'),(31,1,'9144b19e-ee4d-48c2-ac34-79b43a92c0f1','Ameijoas',NULL,41,'KG',NULL,NULL,'PEI-MAR-002',0,1,'2025-11-24 17:06:03.405','2025-11-25 15:53:59.884'),(32,1,'b37760b7-b30b-47bc-8229-f4b41df0fdfd','Mexilhão',NULL,41,'KG',NULL,NULL,'PEI-MAR-003',0,1,'2025-11-24 17:06:03.426','2025-11-25 15:53:59.884'),(33,1,'74488aad-d483-46e8-ba76-6ab4edba1952','Polvo',NULL,41,'KG',NULL,NULL,'PEI-MAR-004',0,1,'2025-11-24 17:06:03.447','2025-11-25 15:53:59.884'),(34,1,'cbe521c7-63f8-4798-80f3-2a0313e5cee4','Lulas',NULL,41,'KG',NULL,NULL,'PEI-MAR-005',0,1,'2025-11-24 17:06:03.503','2025-11-25 15:53:59.884'),(35,1,'31634d92-a64d-4390-9d8a-68d2883796d9','Batata',NULL,42,'KG','','','LEG-RAI-001',0,1,'2025-11-24 17:06:03.532','2025-12-04 21:55:57.158'),(36,1,'daf7e1e2-ac21-4125-a4d9-0d1d6a52d7bf','Cenoura',NULL,42,'KG',NULL,NULL,'LEG-RAI-002',0,1,'2025-11-24 17:06:03.547','2025-11-25 15:53:59.884'),(37,1,'ec3e3a69-8027-4553-8395-3ff0a838af21','Cebola',NULL,42,'KG',NULL,NULL,'LEG-RAI-003',0,1,'2025-11-24 17:06:03.564','2025-11-25 15:53:59.884'),(38,1,'dc67a04d-bc86-4980-9dec-2527f7195ff8','Alho',NULL,42,'KG',NULL,NULL,'LEG-RAI-004',0,1,'2025-11-24 17:06:03.575','2025-11-25 15:53:59.884'),(39,1,'e9831821-f04b-4e42-be7b-404a74787dd4','Beterraba',NULL,42,'KG',NULL,NULL,'LEG-RAI-005',0,1,'2025-11-24 17:06:03.598','2025-11-25 15:53:59.884'),(40,1,'ce7d3c2f-ddcf-4a34-9d9d-976a822ef6eb','Alface',NULL,43,'Unidade',NULL,NULL,'LEG-FOL-001',0,1,'2025-11-24 17:06:03.616','2025-11-25 15:53:59.884'),(41,1,'94b9bfcd-1de7-4c51-8f75-e927ca60abf1','Espinafre',NULL,43,'KG',NULL,NULL,'LEG-FOL-002',0,1,'2025-11-24 17:06:03.631','2025-11-25 15:53:59.884'),(42,1,'d59a825a-d2fb-4069-aa0f-15a3325a2f6f','Couve',NULL,43,'KG',NULL,NULL,'LEG-FOL-003',0,1,'2025-11-24 17:06:03.647','2025-11-25 15:53:59.884'),(43,1,'e084f245-bec9-4556-a1a0-537f0a30811e','Rúcula',NULL,43,'KG',NULL,NULL,'LEG-FOL-004',0,1,'2025-11-24 17:06:03.659','2025-11-25 15:53:59.884'),(44,1,'6ee49795-b414-4ead-af3c-8870fb37e57b','Tomate',NULL,44,'KG',NULL,NULL,'LEG-FRL-001',0,1,'2025-11-24 17:06:03.679','2025-11-25 15:53:59.884'),(45,1,'13747ecb-6061-4764-8192-23ea6eef7650','Pimento',NULL,44,'KG',NULL,NULL,'LEG-FRL-002',0,1,'2025-11-24 17:06:03.696','2025-11-25 15:53:59.884'),(46,1,'ef1f2bb6-f17b-49df-abdc-e6f526a1f84f','Beringela',NULL,44,'KG',NULL,NULL,'LEG-FRL-003',0,1,'2025-11-24 17:06:03.711','2025-11-25 15:53:59.884'),(47,1,'bd8dc507-f1d8-4eb8-98e6-0df7f2d276dd','Abobrinha',NULL,44,'KG',NULL,NULL,'LEG-FRL-004',0,1,'2025-11-24 17:06:03.745','2025-11-25 15:53:59.884'),(48,1,'7a6875c0-cc46-42d1-b6c5-60c7df4b06a4','Abóbora',NULL,44,'KG',NULL,NULL,'LEG-FRL-005',0,1,'2025-11-24 17:06:03.771','2025-11-25 15:53:59.884'),(49,1,'86a12d65-00d1-414d-8c74-640e8b612a26','Ervilha',NULL,45,'KG',NULL,NULL,'LEG-VAG-001',0,1,'2025-11-24 17:06:03.808','2025-11-25 15:53:59.884'),(50,1,'6ff50192-2cba-4637-b8d2-cf15858bb4b8','Feijão Verde',NULL,45,'KG',NULL,NULL,'LEG-VAG-002',0,1,'2025-11-24 17:06:03.838','2025-11-25 15:53:59.884'),(51,1,'d01613a9-83ff-4093-9ad9-f21c7d62bfaf','Grão-de-Bico',NULL,45,'KG',NULL,NULL,'LEG-VAG-003',0,1,'2025-11-24 17:06:03.858','2025-11-25 15:53:59.884'),(52,1,'d21e4d84-602e-4686-94a5-98edeab48a8f','Feijão Preto',NULL,45,'KG',NULL,NULL,'LEG-VAG-004',0,1,'2025-11-24 17:06:03.872','2025-11-25 15:53:59.884'),(53,1,'f4192082-2256-4ad1-9fee-3ac88924cce6','Leite Integral',NULL,46,'L',NULL,NULL,'LAT-LEI-001',0,1,'2025-11-24 17:06:03.898','2025-11-25 15:53:59.884'),(54,1,'e93df8d3-6c2e-4340-843f-d0f4aec61c50','Leite Desnatado',NULL,46,'L',NULL,NULL,'LAT-LEI-002',0,1,'2025-11-24 17:06:03.925','2025-11-25 15:53:59.884'),(55,1,'fa7cfd0a-ae87-4eb6-8149-087e8e16b235','Nata',NULL,46,'L',NULL,NULL,'LAT-LEI-003',0,1,'2025-11-24 17:06:03.946','2025-11-25 15:53:59.884'),(56,1,'7007ccf1-9a37-4113-a966-9a27e850cbec','Queijo Mussarela',NULL,47,'KG',NULL,NULL,'LAT-QUE-001',0,1,'2025-11-24 17:06:03.978','2025-11-25 15:53:59.884'),(57,1,'21bcb019-a418-48aa-b225-e824ba91b684','Queijo Parmesão',NULL,47,'KG',NULL,NULL,'LAT-QUE-002',0,1,'2025-11-24 17:06:04.029','2025-11-25 15:53:59.884'),(58,1,'5d143687-fca3-43e8-bea6-4a4a1ebf233a','Queijo Serra da Estrela',NULL,47,'KG',NULL,NULL,'LAT-QUE-003',0,1,'2025-11-24 17:06:04.068','2025-11-25 15:53:59.884'),(59,1,'5e87109f-777c-4ca8-a10b-e25c5e49bf15','Queijo Fresco',NULL,47,'KG',NULL,NULL,'LAT-QUE-004',0,1,'2025-11-24 17:06:04.099','2025-11-25 15:53:59.884'),(60,1,'a087f8cb-545f-4f9f-a801-48c61622fd7e','Requeijão',NULL,47,'KG',NULL,NULL,'LAT-QUE-005',0,1,'2025-11-24 17:06:04.113','2025-11-25 15:53:59.884'),(61,1,'a4a895e2-6d8f-4c9f-b3a7-cd7134d199a5','Iogurte Natural',NULL,48,'L',NULL,NULL,'LAT-IOG-001',0,1,'2025-11-24 17:06:04.140','2025-11-25 15:53:59.884'),(62,1,'a92755f8-7249-4c79-958a-a6ec833dc731','Iogurte Grego',NULL,48,'KG',NULL,NULL,'LAT-IOG-002',0,1,'2025-11-24 17:06:04.152','2025-11-25 15:53:59.884'),(63,1,'96aabb4c-6b3c-49d2-ae91-3ebb26eb38fe','Manteiga Com Sal',NULL,49,'KG',NULL,NULL,'LAT-MAN-001',0,1,'2025-11-24 17:06:04.174','2025-11-25 15:53:59.884'),(64,1,'f0846d65-bd02-4c8d-9345-37c8f1ff56ab','Manteiga Sem Sal',NULL,49,'KG',NULL,NULL,'LAT-MAN-002',0,1,'2025-11-24 17:06:04.187','2025-11-25 15:53:59.884'),(65,1,'398fde9f-aa45-4827-a8aa-c6cb5a4a214c','Arroz',NULL,50,'KG',NULL,NULL,'DES-GRA-001',0,1,'2025-11-24 17:06:04.219','2025-11-25 15:53:59.884'),(66,1,'ec2d4f6e-e536-4626-906e-782dee0f7435','Massa',NULL,50,'KG',NULL,NULL,'DES-GRA-002',0,1,'2025-11-24 17:06:04.232','2025-11-25 15:53:59.884'),(67,1,'91395781-8a58-4ad7-bc9c-a83ab178009d','Farinha de Trigo',NULL,50,'KG',NULL,NULL,'DES-GRA-003',0,1,'2025-11-24 17:06:04.244','2025-11-25 15:53:59.884'),(68,1,'09b3a1b9-1cca-4b6d-9ec3-c04b0f09c3b0','Aveia',NULL,50,'KG',NULL,NULL,'DES-GRA-004',0,1,'2025-11-24 17:06:04.260','2025-11-25 15:53:59.884'),(69,1,'909a2465-ba51-45a5-9a3b-067a653bf9fe','Azeite',NULL,51,'L',NULL,NULL,'DES-OLE-001',0,1,'2025-11-24 17:06:04.281','2025-11-25 15:53:59.884'),(70,1,'065343ba-1106-4886-b790-fbdfc5a774c1','Óleo Vegetal',NULL,51,'L',NULL,NULL,'DES-OLE-002',0,1,'2025-11-24 17:06:04.298','2025-11-25 15:53:59.884'),(71,1,'cd4d34fb-a1e3-4e03-9952-099f60c0a4bb','Sal',NULL,52,'KG',NULL,NULL,'DES-CON-001',0,1,'2025-11-24 17:06:04.320','2025-11-25 15:53:59.884'),(72,1,'4c6dc45d-ecdd-4ba7-8e56-b30750b1758f','Pimenta Preta',NULL,52,'KG',NULL,NULL,'DES-CON-002',0,1,'2025-11-24 17:06:04.338','2025-11-25 15:53:59.884'),(73,1,'699962b2-3a07-4ea4-bc4b-474fea1a1783','Açúcar',NULL,52,'KG','','','DES-CON-003',0,1,'2025-11-24 17:06:04.357','2025-12-03 14:52:20.013'),(74,1,'6179de76-a41d-42cb-91b0-b98589c325a5','Vinagre',NULL,52,'L',NULL,NULL,'DES-CON-004',0,1,'2025-11-24 17:06:04.371','2025-11-25 15:53:59.884'),(75,1,'63f43444-671a-470c-98b5-61e987b9716a','Molho de Tomate',NULL,53,'KG',NULL,NULL,'DES-MOL-001',0,1,'2025-11-24 17:06:04.392','2025-11-25 15:53:59.884'),(76,1,'b8eab5e7-817d-46cf-a865-d614bc43b967','Mostarda',NULL,53,'KG',NULL,NULL,'DES-MOL-002',0,1,'2025-11-24 17:06:04.403','2025-11-25 15:53:59.884'),(77,1,'ec5f659c-ff7d-4019-8572-a9d06f6be38c','Ketchup',NULL,53,'KG',NULL,NULL,'DES-MOL-003',0,1,'2025-11-24 17:06:04.417','2025-11-25 15:53:59.884'),(78,1,'27f08cae-1f8b-473b-a35f-5960bcc2f561','Maionese',NULL,53,'KG',NULL,NULL,'DES-MOL-004',0,1,'2025-11-24 17:06:04.432','2025-11-25 15:53:59.884'),(79,1,'c11cfc7f-7364-4a80-aa49-339064cbaa2a','Coca-Cola',NULL,54,'L',NULL,NULL,'BEB-REF-001',1,1,'2025-11-24 17:06:04.458','2025-11-24 17:06:07.184'),(80,1,'eb0f70ef-e5e7-4bab-b877-d13af7b804e8','Sprite',NULL,54,'L',NULL,NULL,'BEB-REF-002',1,1,'2025-11-24 17:06:04.479','2025-11-25 10:20:50.009'),(81,1,'87f44462-28fc-45c0-9286-40bfdd9f2131','Fanta',NULL,54,'L',NULL,NULL,'BEB-REF-003',1,1,'2025-11-24 17:06:04.493','2025-11-25 10:20:50.017'),(82,1,'834e3e84-af24-48b9-8175-d5f7d7437160','Sumo de Laranja',NULL,55,'L',NULL,NULL,'BEB-SUM-001',1,1,'2025-11-24 17:06:04.509','2025-11-25 10:20:50.027'),(83,1,'3f8a457a-3621-4e77-a122-0c3387491997','Sumo de Maçã',NULL,55,'L',NULL,NULL,'BEB-SUM-002',1,1,'2025-11-24 17:06:04.529','2025-11-25 10:20:50.034'),(84,1,'d5b25a69-9bb9-4526-b2c8-f3faab164788','Água Mineral',NULL,56,'L',NULL,NULL,'BEB-AGU-001',1,1,'2025-11-24 17:06:04.553','2025-11-24 17:06:07.214'),(85,1,'7012f432-c6d3-46d2-830b-b98369feaa99','Água com Gás',NULL,56,'L','','','BEB-AGU-002',1,1,'2025-11-24 17:06:04.565','2025-12-01 15:24:09.284'),(86,1,'a992cd47-3990-4e0a-ac24-a6ad2c6880a0','Vinho Tinto',NULL,57,'L',NULL,NULL,'BEB-VIN-001',1,1,'2025-11-24 17:06:04.582','2025-11-25 10:20:50.100'),(87,1,'9d298dad-1bb0-4e14-8d80-2e924d86e73c','Vinho Branco',NULL,57,'L',NULL,NULL,'BEB-VIN-002',1,1,'2025-11-24 17:06:04.599','2025-11-25 10:20:50.125'),(88,1,'2f12b2b6-4c13-45e7-b580-ef8157944f28','Vinho Verde',NULL,57,'L',NULL,NULL,'BEB-VIN-003',1,1,'2025-11-24 17:06:04.620','2025-11-25 10:20:50.141'),(89,1,'ff0d0de9-4673-4d34-bb5a-3196ddff7d05','Cerveja Super Bock',NULL,58,'L','','','BEB-CER-001',1,1,'2025-11-24 17:06:04.670','2025-12-15 15:17:57.103'),(90,1,'29b60513-47f0-44de-ad28-336167bfbf3b','Cerveja Sagres',NULL,58,'L',NULL,NULL,'BEB-CER-002',1,1,'2025-11-24 17:06:04.695','2025-11-25 10:20:50.167'),(91,1,'93493704-0a26-4cc2-930c-aa12d088035f','Banha',NULL,59,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.112','2025-12-02 12:34:09.401'),(92,1,'9036ad82-fccf-4379-ba03-e5543f7de2a0','Pimentão-doce',NULL,17,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.125','2025-12-02 12:34:09.401'),(93,1,'8e6e5c5e-1779-408b-ae23-8e61ad736a0b','Louro (Folhas)',NULL,17,'KG','Folhas secas de louro',NULL,NULL,0,1,'2025-11-24 17:06:05.140','2025-12-02 12:34:09.401'),(94,1,'1ace2e66-c172-4b17-9276-b6cf33cee5d8','Pau de Canela',NULL,17,'KG','Canela em pau',NULL,NULL,0,1,'2025-11-24 17:06:05.150','2025-12-02 12:34:09.401'),(95,1,'c4f7ada3-e7f0-4ca6-ac2c-22e6dabaf723','Feijão Vermelho',NULL,15,'KG','','',NULL,0,1,'2025-11-24 17:06:05.165','2025-12-02 12:34:09.401'),(96,1,'dd86ed13-7637-4b0d-9314-435f125d91e8','Alho Francês',NULL,8,'KG','','','LEG-VER-001',0,1,'2025-11-24 17:06:05.182','2025-12-04 11:55:32.279'),(97,1,'82c5d891-8843-4dee-922e-99a99418d22f','Nabo',NULL,8,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.197','2025-12-02 12:34:09.401'),(98,1,'7f229587-10ba-450c-b0cd-0037b619375a','Curgete',NULL,8,'KG','','',NULL,0,1,'2025-11-24 17:06:05.234','2025-12-02 12:34:09.401'),(99,1,'12bad8d0-46f9-448a-8085-e01dd13db066','Couve Portuguesa',NULL,8,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.266','2025-12-02 12:34:09.401'),(100,1,'03ee3ce0-8dfe-4924-a784-accaaf9a5889','Carnes Fumadas',NULL,4,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.288','2025-12-02 12:34:09.401'),(101,1,'ea373a27-40cc-4f19-95ed-096d7676891c','Linguiça',NULL,4,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.303','2025-12-02 12:34:09.401'),(102,1,'4df8a87b-c43f-45a4-8615-564634a389c1','Presunto',NULL,4,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.320','2025-12-02 12:34:09.401'),(103,1,'919fb418-7288-4486-bbe9-95f052ab36a3','Maisena',NULL,14,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.332','2025-12-02 12:34:09.401'),(104,1,'9f58d596-c5f8-4b14-a64d-31c3dea1e6d6','Vinho do Porto',NULL,57,'L','','',NULL,1,1,'2025-11-24 17:06:05.349','2025-11-25 10:20:50.335'),(105,1,'6abdad3f-3ebd-4f6e-aa71-74e23331e94e','Chocolate Culinária',NULL,28,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.362','2025-12-02 12:34:09.401'),(106,1,'825d46d5-b444-468b-b5d5-d448a4177a54','Gelado Baunilha',NULL,28,'KG','Gelado artesanal de baunilha',NULL,NULL,0,1,'2025-11-24 17:06:05.385','2025-12-02 12:34:09.401'),(107,1,'011c3609-a5e8-40d6-80b8-53b1c6598a57','Limão',NULL,10,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.401','2025-12-02 12:34:09.401'),(108,1,'b5719d25-b460-4933-a0f4-2e4aeb9e4f59','Salsa Fresca',NULL,60,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.423','2025-12-02 12:34:09.401'),(109,1,'0e79630f-2e85-48a0-b0eb-80a6ab3713fc','Malagueta',NULL,60,'KG',NULL,NULL,NULL,0,1,'2025-11-24 17:06:05.436','2025-12-02 12:34:09.401'),(110,1,'0b6d970d-d67b-4c28-b3b1-53bae97a86ea','Ovo Galinha',NULL,22,'Unidade','','','LAT-OVO-001',0,1,'2025-12-01 19:06:26.847','2025-12-01 19:06:26.847'),(111,1,'73562696-e4d4-475b-8791-e115930a0f5d','Pacheca Premium Douro',NULL,62,'L','','','BEB-VINT-001',1,1,'2025-12-09 12:29:59.602','2025-12-09 16:28:33.698'),(112,1,'1d545338-4171-4fd5-9526-3c9eebc75d6f','Terras do Demo',NULL,65,'L','','','BEB-VINE-001',1,1,'2025-12-09 17:26:21.632','2025-12-09 17:26:21.632'),(113,1,'81f4d224-f85d-42c2-8356-7bd18f17b733','BIFE FRANGO PANADO',1,38,'KG',NULL,NULL,NULL,0,1,'2025-12-12 14:52:42.873','2025-12-12 14:52:42.873'),(114,1,'caa11b69-aba5-42a7-8070-2f55f55664ad','CAMARAO 20/30',2,41,'KG',NULL,NULL,NULL,0,1,'2025-12-12 14:54:17.527','2025-12-12 14:54:17.527'),(115,1,'4e7324b7-38cc-4d0e-bcfb-cf7c999005b3','CAPRICHOS ALASKA ',2,41,'KG',NULL,NULL,NULL,0,1,'2025-12-12 15:00:33.431','2025-12-12 15:00:33.431'),(116,1,'b11a69bd-0617-426a-88dd-51b6d8ec8fce','CHOCO LP 2/4 AV E/O',2,7,'KG',NULL,NULL,NULL,0,1,'2025-12-12 15:01:45.791','2025-12-12 15:01:45.791'),(117,1,'474b66e8-3b43-4d76-81c1-8c6278afb3e5','Miolo CAMARAO 31/40 sem tripa',2,41,'KG',NULL,NULL,NULL,0,1,'2025-12-12 15:05:30.726','2025-12-12 15:05:30.726'),(118,1,'8892ef11-36a0-4f88-8de1-347e95747272','PASTEIS BACALHAU CATERING',2,6,'Unidade',NULL,NULL,NULL,0,1,'2025-12-12 15:07:29.488','2025-12-12 15:07:29.488'),(119,1,'6e290198-03da-4272-9b10-2e0a60adea9e','POLVO ROTO E/O',2,7,'KG',NULL,NULL,NULL,0,1,'2025-12-12 15:09:50.674','2025-12-12 15:09:50.674'),(120,1,'c2b31b1c-709c-40c5-91bc-614269c9dc74','SALTEADO CAMPESTRE 4x2.5KG Minute BOND',3,9,'KG',NULL,NULL,NULL,0,1,'2025-12-12 15:12:40.593','2025-12-12 15:12:40.593');
/*!40000 ALTER TABLE `produtos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receitas`
--

DROP TABLE IF EXISTS `receitas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `receitas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_porcoes` decimal(10,2) NOT NULL DEFAULT '1.00',
  `tempo_preparacao` int DEFAULT NULL,
  `quantidade_total_produzida` decimal(10,4) DEFAULT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custo_total` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `custo_por_porcao` decimal(10,4) NOT NULL DEFAULT '0.0000',
  `imagem_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dificuldade` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categoria` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ativa` tinyint(1) NOT NULL DEFAULT '1',
  `criado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receitas_tenant_id_nome_key` (`tenant_id`,`nome`),
  KEY `receitas_criado_por_fkey` (`criado_por`),
  CONSTRAINT `receitas_criado_por_fkey` FOREIGN KEY (`criado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `receitas_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receitas`
--

LOCK TABLES `receitas` WRITE;
/*!40000 ALTER TABLE `receitas` DISABLE KEYS */;
INSERT INTO `receitas` VALUES (1,1,'7c440b84-7383-447d-8d6e-e0a0fc5c916b','Sopa de Legumes','Final',4.00,45,1.0000,'L',1.5195,0.3799,NULL,NULL,NULL,'Fácil','Sopas',1,NULL,'2025-11-24 17:06:05.807','2025-12-15 16:51:03.941'),(2,1,'7ca899dc-1923-4a96-b495-a46f57c9c6fe','Lombo de Porco Assado','Final',4.00,90,1.1000,'KG',8.1046,2.0262,NULL,NULL,NULL,'Média','Carnes',1,NULL,'2025-11-24 17:06:05.887','2025-12-04 21:55:52.724'),(3,1,'a360ced4-3128-4402-86d2-6e0e279f866b','Arroz Branco','Pre-preparo',4.00,20,0.6000,'KG',0.3264,0.0816,'https://cdn5.soreceitasfaceis.com/wp-content/uploads/2015/08/arroz-branco-soltinho.jpg','https://youtu.be/4rk9pQ98Nls?si=9NQbebGlwy7LAwsh','','Fácil','Acompanhamentos',1,NULL,'2025-11-24 17:06:05.950','2025-11-26 18:35:09.819'),(4,1,'e1955d2c-e6e4-4f98-ac4a-5319bd18018d','Feijoada à Transmontana','Final',4.00,150,1.0000,'KG',4.6960,1.1740,NULL,NULL,NULL,'Média','Carnes',1,NULL,'2025-11-24 17:06:05.980','2025-11-24 17:06:06.035'),(5,1,'41cb776e-9897-4902-88ba-2381db941a93','Bife à Portuguesa','Final',4.00,40,1.2000,'KG',16.0135,4.0034,NULL,NULL,'','Média','Carnes',1,NULL,'2025-11-24 17:06:06.045','2025-12-04 21:55:52.734'),(6,1,'482fa889-e66b-4692-a68f-239f230d3a2c','Dourada Grelhada','Final',4.00,30,1.2000,'KG',25.3548,6.3387,NULL,NULL,NULL,'Fácil','Peixes',1,NULL,'2025-11-24 17:06:06.086','2025-11-24 17:06:06.105'),(7,1,'7e9d22e1-adc4-438b-9672-4e8d56ece858','Filetes de Pescada com Arroz de Tomate','Final',4.00,45,1.1000,'KG',8.6398,2.1599,NULL,NULL,NULL,'Média','Peixes',1,NULL,'2025-11-24 17:06:06.118','2025-11-24 17:06:06.191'),(8,1,'7277a4c3-a002-4e12-afc1-9bf1f6e3198b','Leite Creme','Final',4.00,25,0.5000,'L',0.5531,0.1383,NULL,NULL,'','Média','Sobremesas',1,NULL,'2025-11-24 17:06:06.210','2025-12-03 16:11:05.669'),(9,1,'9d5e3d41-09a9-4460-9fe3-7d95c9382c97','Pudim Francês','Final',4.00,60,0.5000,'KG',0.3364,0.0841,NULL,NULL,NULL,'Média','Sobremesas',1,NULL,'2025-11-24 17:06:06.269','2025-12-03 14:52:13.053'),(10,1,'25e94bbd-1d0b-43b9-ba3b-1f605b988e39','Petit Gateaux com Bola de Gelado','Final',4.00,35,0.6000,'KG',4.1244,1.0311,NULL,NULL,NULL,'Difícil','Sobremesas',1,NULL,'2025-11-24 17:06:06.311','2025-12-03 14:52:13.066');
/*!40000 ALTER TABLE `receitas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `access_token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `refresh_token_hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` datetime(3) NOT NULL,
  `refresh_expires_at` datetime(3) NOT NULL,
  `revoked` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_fkey` (`user_id`),
  KEY `sessions_tenant_id_fkey` (`tenant_id`),
  CONSTRAINT `sessions_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `sessions_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessoes_inventario`
--

DROP TABLE IF EXISTS `sessoes_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessoes_inventario` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_inicio` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `data_fim` datetime(3) DEFAULT NULL,
  `filtros_usados` json DEFAULT NULL,
  `criado_por` int DEFAULT NULL,
  `fechado_por` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessoes_inventario_tenant_id_fkey` (`tenant_id`),
  KEY `sessoes_inventario_criado_por_fkey` (`criado_por`),
  KEY `sessoes_inventario_fechado_por_fkey` (`fechado_por`),
  CONSTRAINT `sessoes_inventario_criado_por_fkey` FOREIGN KEY (`criado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sessoes_inventario_fechado_por_fkey` FOREIGN KEY (`fechado_por`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `sessoes_inventario_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessoes_inventario`
--

LOCK TABLES `sessoes_inventario` WRITE;
/*!40000 ALTER TABLE `sessoes_inventario` DISABLE KEYS */;
INSERT INTO `sessoes_inventario` VALUES (1,1,'2a7e3c4f-e3e3-4a1c-b7d4-e88688e448ae',1,'Inventário #1','Total','Aberto','2025-12-04 20:49:14.570',NULL,'{}',1,NULL,'2025-12-04 20:49:14.570','2025-12-04 20:49:14.570'),(2,1,'0c9ca276-5bf4-4799-b3d7-2c36436da770',2,'Inventário #2','Total','Aberto','2025-12-04 20:51:38.890',NULL,'{}',1,NULL,'2025-12-04 20:51:38.890','2025-12-04 20:51:38.890'),(3,1,'5e9ecb88-a77f-42fa-a1c5-563b5e7d346c',3,'Inventário #3','Calculadora','Aberto','2025-12-04 21:07:33.227',NULL,'{\"familia_id\": 1, \"lista_calculadora_id\": 1}',1,NULL,'2025-12-04 21:07:33.227','2025-12-04 21:07:33.227');
/*!40000 ALTER TABLE `sessoes_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stock_teorico`
--

DROP TABLE IF EXISTS `stock_teorico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_teorico` (
  `tenant_id` int NOT NULL,
  `produto_id` int NOT NULL,
  `variacao_id` int NOT NULL DEFAULT '0',
  `quantidade_atual` decimal(10,4) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL,
  `data_ultima_atualizacao` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`tenant_id`,`produto_id`,`variacao_id`),
  KEY `stock_teorico_produto_id_fkey` (`produto_id`),
  KEY `stock_teorico_variacao_id_fkey` (`variacao_id`),
  CONSTRAINT `stock_teorico_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `stock_teorico_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `stock_teorico_variacao_id_fkey` FOREIGN KEY (`variacao_id`) REFERENCES `variacoes_produto` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_teorico`
--

LOCK TABLES `stock_teorico` WRITE;
/*!40000 ALTER TABLE `stock_teorico` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_teorico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subfamilias`
--

DROP TABLE IF EXISTS `subfamilias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subfamilias` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `familia_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `codigo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem` int NOT NULL DEFAULT '0',
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subfamilias_tenant_id_familia_id_nome_key` (`tenant_id`,`familia_id`,`nome`),
  KEY `subfamilias_familia_id_fkey` (`familia_id`),
  CONSTRAINT `subfamilias_familia_id_fkey` FOREIGN KEY (`familia_id`) REFERENCES `familias` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `subfamilias_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subfamilias`
--

LOCK TABLES `subfamilias` WRITE;
/*!40000 ALTER TABLE `subfamilias` DISABLE KEYS */;
INSERT INTO `subfamilias` VALUES (1,1,1,'Porco','POR',0,1,'2025-11-24 16:55:26.216','2025-11-24 16:55:26.216'),(2,1,1,'Vitela','VIT',0,1,'2025-11-24 16:55:26.224','2025-11-24 16:55:26.224'),(3,1,1,'Aves e Outras Carnes','AVE',0,1,'2025-11-24 16:55:26.232','2025-11-24 16:55:26.232'),(4,1,1,'Enchidos e Charcutaria','CHA',0,1,'2025-11-24 16:55:26.239','2025-11-24 16:55:26.239'),(5,1,2,'Peixes','PEI',0,1,'2025-11-24 16:55:26.245','2025-11-24 16:55:26.245'),(6,1,2,'Bacalhau','BAC',0,1,'2025-11-24 16:55:26.252','2025-11-24 16:55:26.252'),(7,1,2,'Mariscos e Moluscos','MAR',0,1,'2025-11-24 16:55:26.258','2025-11-24 16:55:26.258'),(8,1,3,'Frescos','VER',0,1,'2025-11-24 16:55:26.264','2025-11-24 16:55:26.264'),(9,1,3,'Congelados','CON',0,1,'2025-11-24 16:55:26.277','2025-11-24 16:55:26.277'),(10,1,4,'Frutas Frescas','FRF',0,1,'2025-11-24 16:55:26.283','2025-11-24 16:55:26.283'),(11,1,4,'Frutas Enlatadas','FRE',0,1,'2025-11-24 16:55:26.291','2025-11-24 16:55:26.291'),(12,1,5,'Arroz','ARZ',0,1,'2025-11-24 16:55:26.297','2025-11-24 16:55:26.297'),(13,1,5,'Massas','MAS',0,1,'2025-11-24 16:55:26.302','2025-11-24 16:55:26.302'),(14,1,5,'Farinhas e Amidos','FAR',0,1,'2025-11-24 16:55:26.308','2025-11-24 16:55:26.308'),(15,1,5,'Leguminosas e Grãos','LEG',0,1,'2025-11-24 16:55:26.313','2025-11-24 16:55:26.313'),(16,1,5,'Açúcares e Doces Secos','DOC',0,1,'2025-11-24 16:55:26.320','2025-11-24 16:55:26.320'),(17,1,6,'Temperos Secos','TSE',0,1,'2025-11-24 16:55:26.328','2025-11-24 16:55:26.328'),(18,1,6,'Molhos e Caldos Industriais','MOL',0,1,'2025-11-24 16:55:26.333','2025-11-24 16:55:26.333'),(19,1,7,'Leites e Natas','LEI',0,1,'2025-11-24 16:55:26.341','2025-11-24 16:55:26.341'),(20,1,7,'Queijos e Derivados','QUE',0,1,'2025-11-24 16:55:26.350','2025-11-24 16:55:26.350'),(21,1,7,'Manteigas e Gorduras Animais','MAN',0,1,'2025-11-24 16:55:26.357','2025-11-24 16:55:26.357'),(22,1,7,'Ovos','OVO',0,1,'2025-11-24 16:55:26.363','2025-11-24 16:55:26.363'),(23,1,8,'Azeites','AZE',0,1,'2025-11-24 16:55:26.369','2025-11-24 16:55:26.369'),(24,1,8,'Óleos Vegetais','OLI',0,1,'2025-11-24 16:55:26.374','2025-11-24 16:55:26.374'),(25,1,9,'Peixes e Patés','PAT',0,1,'2025-11-24 16:55:26.380','2025-11-24 16:55:26.380'),(26,1,9,'Legumes e Outros Enlatados','ENC',0,1,'2025-11-24 16:55:26.389','2025-11-24 16:55:26.389'),(27,1,10,'Pães e Derivados','PAN',0,1,'2025-11-24 16:55:26.394','2025-11-24 16:55:26.394'),(28,1,10,'Sobremesas e Bolos','SOB',0,1,'2025-11-24 16:55:26.400','2025-11-24 16:55:26.400'),(29,1,11,'Molhos e Reduções','PMO',0,1,'2025-11-24 16:55:26.409','2025-11-24 16:55:26.409'),(30,1,11,'Caldos e Fundos','PCA',0,1,'2025-11-24 16:55:26.417','2025-11-24 16:55:26.417'),(31,1,11,'Marinadas e Temperos Prontos','PMA',0,1,'2025-11-24 16:55:26.423','2025-11-24 16:55:26.423'),(32,1,11,'Cremes, Purés e Sopas Base','PCR',0,1,'2025-11-24 16:55:26.427','2025-11-24 16:55:26.427'),(33,1,11,'Semi-acabados (bases, recheios, etc.)','PSE',0,1,'2025-11-24 16:55:26.436','2025-11-24 16:55:26.436'),(34,1,11,'Sobremesas Base','PSO',0,1,'2025-11-24 16:55:26.447','2025-11-24 16:55:26.447'),(35,1,12,'Diversos','OUT',0,1,'2025-11-24 16:55:26.453','2025-11-24 16:55:26.453'),(36,1,1,'Bovino',NULL,0,1,'2025-11-24 17:06:02.660','2025-11-24 17:06:02.660'),(37,1,1,'Suíno',NULL,0,1,'2025-11-24 17:06:02.993','2025-11-24 17:06:02.993'),(38,1,1,'Aves',NULL,0,1,'2025-11-24 17:06:03.063','2025-11-24 17:06:03.063'),(39,1,2,'Peixe Branco',NULL,0,1,'2025-11-24 17:06:03.227','2025-11-24 17:06:03.227'),(40,1,2,'Peixe Azul',NULL,0,1,'2025-11-24 17:06:03.282','2025-11-24 17:06:03.282'),(41,1,2,'Marisco',NULL,0,1,'2025-11-24 17:06:03.373','2025-11-24 17:06:03.373'),(42,1,3,'Raízes',NULL,0,1,'2025-11-24 17:06:03.524','2025-11-24 17:06:03.524'),(43,1,3,'Folhas',NULL,0,1,'2025-11-24 17:06:03.611','2025-11-24 17:06:03.611'),(44,1,3,'Frutas-Legume',NULL,0,1,'2025-11-24 17:06:03.672','2025-11-24 17:06:03.672'),(45,1,3,'Vagens',NULL,0,1,'2025-11-24 17:06:03.797','2025-11-24 17:06:03.797'),(46,1,7,'Leite',NULL,0,1,'2025-11-24 17:06:03.884','2025-11-24 17:06:03.884'),(47,1,7,'Queijo',NULL,0,1,'2025-11-24 17:06:03.969','2025-11-24 17:06:03.969'),(48,1,7,'Iogurte',NULL,0,1,'2025-11-24 17:06:04.134','2025-11-24 17:06:04.134'),(49,1,7,'Manteiga',NULL,0,1,'2025-11-24 17:06:04.165','2025-11-24 17:06:04.165'),(50,1,13,'Grãos',NULL,0,1,'2025-11-24 17:06:04.212','2025-11-24 17:06:04.212'),(51,1,13,'Óleos',NULL,0,1,'2025-11-24 17:06:04.272','2025-11-24 17:06:04.272'),(52,1,13,'Condimentos',NULL,0,1,'2025-11-24 17:06:04.313','2025-11-24 17:06:04.313'),(53,1,13,'Molhos',NULL,0,1,'2025-11-24 17:06:04.385','2025-11-24 17:06:04.385'),(54,1,14,'Refrigerantes',NULL,0,1,'2025-11-24 17:06:04.450','2025-11-24 17:06:04.450'),(55,1,14,'Sumos',NULL,0,1,'2025-11-24 17:06:04.501','2025-11-24 17:06:04.501'),(56,1,14,'Águas',NULL,0,1,'2025-11-24 17:06:04.546','2025-11-24 17:06:04.546'),(57,1,14,'Vinhos',NULL,0,1,'2025-11-24 17:06:04.577','2025-11-24 17:06:04.577'),(58,1,14,'Cervejas',NULL,0,1,'2025-11-24 17:06:04.653','2025-11-24 17:06:04.653'),(59,1,8,'Gorduras Animais','GOR',0,1,'2025-11-24 17:06:05.103','2025-11-24 17:06:05.103'),(60,1,6,'Temperos Frescos','TEM',0,1,'2025-11-24 17:06:05.415','2025-11-24 17:06:05.415'),(61,1,14,'Sumos e Néctares','SUM',0,1,'2025-11-24 17:06:06.692','2025-11-24 17:06:06.692'),(62,1,14,'Vinhos Tintos','VINT',0,1,'2025-11-24 17:06:06.698','2025-11-24 17:06:06.698'),(63,1,14,'Vinhos Brancos','VINB',0,1,'2025-11-24 17:06:06.703','2025-11-24 17:06:06.703'),(64,1,14,'Vinhos Rosés','VINR',0,1,'2025-11-24 17:06:06.708','2025-11-24 17:06:06.708'),(65,1,14,'Vinhos Espumantes','VINE',0,1,'2025-11-24 17:06:06.711','2025-11-24 17:06:06.711'),(66,1,14,'Vinhos Verdes','VINV',0,1,'2025-11-24 17:06:06.715','2025-11-24 17:06:06.715'),(67,1,14,'Vinhos do Porto e Fortificados','VINP',0,1,'2025-11-24 17:06:06.724','2025-11-24 17:06:06.724'),(68,1,14,'Espirituosas','ESP',0,1,'2025-11-24 17:06:06.736','2025-11-24 17:06:06.736'),(69,1,14,'Licores e Digestivos','LIC',0,1,'2025-11-24 17:06:06.741','2025-11-24 17:06:06.741'),(70,1,14,'Café, Chá e Infusões','CAF',0,1,'2025-11-24 17:06:06.752','2025-11-24 17:06:06.752'),(71,1,14,'Outras Bebidas','OUT',0,1,'2025-11-24 17:06:06.774','2025-11-24 17:06:06.774'),(72,2,15,'Porco','POR',0,1,'2025-11-27 16:52:28.580','2025-11-27 16:52:28.580'),(73,2,15,'Vitela','VIT',0,1,'2025-11-27 16:52:28.585','2025-11-27 16:52:28.585'),(74,2,15,'Aves e Outras Carnes','AVE',0,1,'2025-11-27 16:52:28.587','2025-11-27 16:52:28.587'),(75,2,15,'Enchidos e Charcutaria','CHA',0,1,'2025-11-27 16:52:28.588','2025-11-27 16:52:28.588'),(76,2,16,'Peixes','PEI',0,1,'2025-11-27 16:52:28.589','2025-11-27 16:52:28.589'),(77,2,16,'Bacalhau','BAC',0,1,'2025-11-27 16:52:28.591','2025-11-27 16:52:28.591'),(78,2,16,'Mariscos e Moluscos','MAR',0,1,'2025-11-27 16:52:28.593','2025-11-27 16:52:28.593'),(79,2,17,'Frescos','VER',0,1,'2025-11-27 16:52:28.594','2025-11-27 16:52:28.594'),(80,2,17,'Congelados','CON',0,1,'2025-11-27 16:52:28.595','2025-11-27 16:52:28.595'),(81,2,18,'Frutas Frescas','FRF',0,1,'2025-11-27 16:52:28.597','2025-11-27 16:52:28.597'),(82,2,18,'Frutas Enlatadas','FRE',0,1,'2025-11-27 16:52:28.599','2025-11-27 16:52:28.599'),(83,2,19,'Arroz','ARZ',0,1,'2025-11-27 16:52:28.600','2025-11-27 16:52:28.600'),(84,2,19,'Massas','MAS',0,1,'2025-11-27 16:52:28.602','2025-11-27 16:52:28.602'),(85,2,19,'Farinhas e Amidos','FAR',0,1,'2025-11-27 16:52:28.604','2025-11-27 16:52:28.604'),(86,2,19,'Leguminosas e Grãos','LEG',0,1,'2025-11-27 16:52:28.605','2025-11-27 16:52:28.605'),(87,2,19,'Açúcares e Doces Secos','DOC',0,1,'2025-11-27 16:52:28.608','2025-11-27 16:52:28.608'),(88,2,20,'Temperos Secos','TSE',0,1,'2025-11-27 16:52:28.609','2025-11-27 16:52:28.609'),(89,2,20,'Molhos e Caldos Industriais','MOL',0,1,'2025-11-27 16:52:28.610','2025-11-27 16:52:28.610'),(90,2,21,'Leites e Natas','LEI',0,1,'2025-11-27 16:52:28.612','2025-11-27 16:52:28.612'),(91,2,21,'Queijos e Derivados','QUE',0,1,'2025-11-27 16:52:28.614','2025-11-27 16:52:28.614'),(92,2,21,'Manteigas e Gorduras Animais','MAN',0,1,'2025-11-27 16:52:28.616','2025-11-27 16:52:28.616'),(93,2,21,'Ovos','OVO',0,1,'2025-11-27 16:52:28.617','2025-11-27 16:52:28.617'),(94,2,22,'Azeites','AZE',0,1,'2025-11-27 16:52:28.619','2025-11-27 16:52:28.619'),(95,2,22,'Óleos Vegetais','OLI',0,1,'2025-11-27 16:52:28.620','2025-11-27 16:52:28.620'),(96,2,23,'Peixes e Patés','PAT',0,1,'2025-11-27 16:52:28.622','2025-11-27 16:52:28.622'),(97,2,23,'Legumes e Outros Enlatados','ENC',0,1,'2025-11-27 16:52:28.624','2025-11-27 16:52:28.624'),(98,2,24,'Pães e Derivados','PAN',0,1,'2025-11-27 16:52:28.625','2025-11-27 16:52:28.625'),(99,2,24,'Sobremesas e Bolos','SOB',0,1,'2025-11-27 16:52:28.627','2025-11-27 16:52:28.627'),(100,2,25,'Molhos e Reduções','PMO',0,1,'2025-11-27 16:52:28.629','2025-11-27 16:52:28.629'),(101,2,25,'Caldos e Fundos','PCA',0,1,'2025-11-27 16:52:28.630','2025-11-27 16:52:28.630'),(102,2,25,'Marinadas e Temperos Prontos','PMA',0,1,'2025-11-27 16:52:28.632','2025-11-27 16:52:28.632'),(103,2,25,'Cremes, Purés e Sopas Base','PCR',0,1,'2025-11-27 16:52:28.634','2025-11-27 16:52:28.634'),(104,2,25,'Semi-acabados (bases, recheios, etc.)','PSE',0,1,'2025-11-27 16:52:28.635','2025-11-27 16:52:28.635'),(105,2,25,'Sobremesas Base','PSO',0,1,'2025-11-27 16:52:28.636','2025-11-27 16:52:28.636'),(106,2,26,'Diversos','OUT',0,1,'2025-11-27 16:52:28.638','2025-11-27 16:52:28.638');
/*!40000 ALTER TABLE `subfamilias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_formato_venda`
--

DROP TABLE IF EXISTS `template_formato_venda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_formato_venda` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quantidade` decimal(10,3) NOT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `ordem_exibicao` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `template_formato_venda_tenant_id_ativo_idx` (`tenant_id`,`ativo`),
  CONSTRAINT `template_formato_venda_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_formato_venda`
--

LOCK TABLES `template_formato_venda` WRITE;
/*!40000 ALTER TABLE `template_formato_venda` DISABLE KEYS */;
INSERT INTO `template_formato_venda` VALUES (1,1,'Copo de 25 cl',NULL,0.250,'L',1,NULL,'2025-12-02 12:24:59.326','2025-12-02 12:24:59.326'),(2,1,'Caneca 0,5 L',NULL,0.500,'L',1,NULL,'2025-12-02 12:25:33.924','2025-12-02 12:25:33.924'),(3,1,'Copo 33 cl',NULL,0.330,'L',1,NULL,'2025-12-02 12:26:07.173','2025-12-02 12:26:07.173'),(4,1,'Lata 33 cl',NULL,0.330,'L',1,NULL,'2025-12-02 12:26:36.559','2025-12-02 12:26:36.559'),(5,1,'garrafa 33 cl',NULL,0.330,'L',1,NULL,'2025-12-02 12:26:54.959','2025-12-02 12:26:54.959'),(6,1,'garrafa 75 cl',NULL,0.750,'L',1,NULL,'2025-12-02 12:27:28.450','2025-12-02 12:27:28.450'),(7,1,'garrafa 0,5 L',NULL,0.500,'L',1,NULL,'2025-12-02 12:28:35.045','2025-12-02 12:28:35.045'),(8,1,'garrafa 25 cl',NULL,0.250,'L',1,NULL,'2025-12-02 12:29:15.887','2025-12-02 12:29:15.887');
/*!40000 ALTER TABLE `template_formato_venda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_variacao_compra`
--

DROP TABLE IF EXISTS `template_variacao_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_variacao_compra` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `descricao` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `unidades_por_compra` decimal(10,4) NOT NULL,
  `unidade_medida` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `ordem_exibicao` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `template_variacao_compra_tenant_id_ativo_idx` (`tenant_id`,`ativo`),
  KEY `template_variacao_compra_tenant_id_unidade_medida_idx` (`tenant_id`,`unidade_medida`),
  CONSTRAINT `template_variacao_compra_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_variacao_compra`
--

LOCK TABLES `template_variacao_compra` WRITE;
/*!40000 ALTER TABLE `template_variacao_compra` DISABLE KEYS */;
INSERT INTO `template_variacao_compra` VALUES (1,1,'Barril 50L','Barril de 50 litros',50.0000,'L',1,1,'2025-12-03 10:07:42.019','2025-12-03 10:07:42.019'),(2,1,'Barril 30L','Barril de 30 litros',30.0000,'L',1,2,'2025-12-03 10:07:42.132','2025-12-03 10:07:42.132'),(3,1,'Barril 20L','Barril de 20 litros',20.0000,'L',1,3,'2025-12-03 10:07:42.137','2025-12-03 10:07:42.137'),(4,1,'Pack 6x1.5L','Pack de 6 garrafas de 1.5L',9.0000,'L',1,4,'2025-12-03 10:07:42.145','2025-12-03 10:07:42.145'),(5,1,'Garrafa 5L','Garrafa de 5 litros',5.0000,'L',1,5,'2025-12-03 10:07:42.152','2025-12-03 10:07:42.152'),(6,1,'Garrafa 2L','Garrafa de 2 litros',2.0000,'L',1,6,'2025-12-03 10:07:42.161','2025-12-03 10:07:42.161'),(7,1,'Garrafa 1.5L','Garrafa de 1.5 litros',1.5000,'L',1,7,'2025-12-03 10:07:42.169','2025-12-03 10:07:42.169'),(8,1,'Garrafa 1L','Garrafa de 1 litro',1.0000,'L',1,8,'2025-12-03 10:07:42.174','2025-12-03 10:07:42.174'),(9,1,'Garrafa 75cl','Garrafa de 75 centilitros',0.7500,'L',1,9,'2025-12-03 10:07:42.178','2025-12-03 10:07:42.178'),(10,1,'Pack 12 latas 33cl','Pack de 12 latas de 33cl',3.9600,'L',1,10,'2025-12-03 10:07:42.181','2025-12-03 10:07:42.181'),(11,1,'Grade 24x33cl','Grade de 24 garrafas de 33cl',7.9200,'L',1,11,'2025-12-03 10:07:42.185','2025-12-03 10:07:42.185'),(12,1,'Lata 33cl','Lata de 33 centilitros',0.3300,'L',1,12,'2025-12-03 10:07:42.188','2025-12-03 10:07:42.188'),(13,1,'Garrafa 33cl','Garrafa de 33 centilitros',0.3300,'L',1,13,'2025-12-03 10:07:42.193','2025-12-03 10:07:42.193'),(14,1,'Garrafa 25cl','Garrafa de 25 centilitros',0.2500,'L',1,14,'2025-12-03 10:07:42.197','2025-12-03 10:07:42.197'),(15,1,'Saco 25kg','Saco de 25 quilogramas',25.0000,'KG',1,1,'2025-12-03 10:07:42.202','2025-12-03 10:07:42.202'),(16,1,'Saco 20kg','Saco de 20 quilogramas',20.0000,'KG',1,2,'2025-12-03 10:07:42.205','2025-12-03 10:07:42.205'),(17,1,'Saco 10kg','Saco de 10 quilogramas',10.0000,'KG',1,3,'2025-12-03 10:07:42.211','2025-12-03 10:07:42.211'),(18,1,'Saco 5kg','Saco de 5 quilogramas',5.0000,'KG',1,4,'2025-12-03 10:07:42.214','2025-12-03 10:07:42.214'),(19,1,'Saco 2kg','Saco de 2 quilogramas',2.0000,'KG',1,5,'2025-12-03 10:07:42.217','2025-12-03 10:07:42.217'),(20,1,'Saco 1kg','Saco de 1 quilograma',1.0000,'KG',1,6,'2025-12-03 10:07:42.221','2025-12-03 10:07:42.221'),(21,1,'Caixa 10kg','Caixa de 10 quilogramas',10.0000,'KG',1,7,'2025-12-03 10:07:42.225','2025-12-03 10:07:42.225'),(22,1,'Caixa 5kg','Caixa de 5 quilogramas',5.0000,'KG',1,8,'2025-12-03 10:07:42.229','2025-12-03 10:07:42.229'),(23,1,'Embalagem 500g','Embalagem de 500 gramas',0.5000,'KG',1,9,'2025-12-03 10:07:42.233','2025-12-03 10:07:42.233'),(24,1,'Unidade','Unidade individual',1.0000,'Unidade',1,1,'2025-12-03 10:07:42.237','2025-12-03 10:07:42.237'),(25,1,'Pack 6un','Pack de 6 unidades',6.0000,'Unidade',1,2,'2025-12-03 10:07:42.241','2025-12-03 10:07:42.241'),(26,1,'Pack 12un','Pack de 12 unidades',12.0000,'Unidade',1,3,'2025-12-03 10:07:42.245','2025-12-03 10:07:42.245'),(27,1,'Caixa 24un','Caixa de 24 unidades',24.0000,'Unidade',1,4,'2025-12-03 10:07:42.249','2025-12-03 10:07:42.249'),(28,1,'Caixa 48un','Caixa de 48 unidades',48.0000,'Unidade',1,5,'2025-12-03 10:07:42.253','2025-12-03 10:07:42.253'),(29,1,'Caixa 100un','Caixa de 100 unidades',100.0000,'Unidade',1,6,'2025-12-03 10:07:42.257','2025-12-03 10:07:42.257'),(30,1,'Dúzia','Dúzia (12 unidades)',12.0000,'Unidade',1,7,'2025-12-03 10:07:42.261','2025-12-03 10:07:42.261');
/*!40000 ALTER TABLE `template_variacao_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_limits`
--

DROP TABLE IF EXISTS `tenant_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_limits` (
  `tenant_id` int NOT NULL,
  `max_users` int NOT NULL DEFAULT '5',
  `max_produtos` int NOT NULL DEFAULT '100',
  `max_receitas` int NOT NULL DEFAULT '50',
  `max_storage_mb` int NOT NULL DEFAULT '500',
  `storage_usado_mb` int NOT NULL DEFAULT '0',
  `api_calls_per_day` int NOT NULL DEFAULT '1000',
  `ai_queries_per_month` int NOT NULL DEFAULT '100',
  `ai_queries_usado_mes_atual` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`tenant_id`),
  CONSTRAINT `tenant_limits_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_limits`
--

LOCK TABLES `tenant_limits` WRITE;
/*!40000 ALTER TABLE `tenant_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_restaurante` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nif` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `morada` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_contacto` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plano` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'trial',
  `data_expiracao_plano` datetime(3) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `configuracoes` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_uuid_key` (`uuid`),
  UNIQUE KEY `tenants_slug_key` (`slug`),
  UNIQUE KEY `tenants_nif_key` (`nif`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (1,'da7ac91f-4917-415f-b6d3-11c9fe8c69b8','Demo Restaurant','demo-restaurant',NULL,NULL,NULL,NULL,NULL,'enterprise',NULL,1,NULL,NULL,'2025-11-24 16:55:26.106','2025-11-24 16:55:26.106'),(2,'f00f959a-e735-4fda-922c-ee174e4518b8','Alambique Cafe Restaurante','Alambique Tondela','518634108','Tondela',NULL,NULL,NULL,'trial',NULL,1,NULL,NULL,'2025-11-27 16:52:28.544','2025-11-27 16:52:28.544');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_backup_codes`
--

DROP TABLE IF EXISTS `two_factor_backup_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_backup_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `code_hash` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT '0',
  `data_uso` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `two_factor_backup_codes_user_id_fkey` (`user_id`),
  CONSTRAINT `two_factor_backup_codes_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_backup_codes`
--

LOCK TABLES `two_factor_backup_codes` WRITE;
/*!40000 ALTER TABLE `two_factor_backup_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_backup_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tenants`
--

DROP TABLE IF EXISTS `user_tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tenants` (
  `user_id` int NOT NULL,
  `tenant_id` int NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'User role in this specific tenant',
  `ativo` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'Is user active in this tenant',
  `invited_by` int DEFAULT NULL COMMENT 'User ID who sent the invitation',
  `invited_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `activated_at` datetime(3) DEFAULT NULL COMMENT 'When user accepted invitation',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL ON UPDATE CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`user_id`,`tenant_id`),
  KEY `user_tenants_tenant_id_ativo_idx` (`tenant_id`,`ativo`),
  KEY `user_tenants_user_id_ativo_idx` (`user_id`,`ativo`),
  KEY `user_tenants_invited_by_fkey` (`invited_by`),
  CONSTRAINT `user_tenants_invited_by_fkey` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `user_tenants_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_tenants_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Many-to-many relationship between users and tenants';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tenants`
--

LOCK TABLES `user_tenants` WRITE;
/*!40000 ALTER TABLE `user_tenants` DISABLE KEYS */;
INSERT INTO `user_tenants` VALUES (1,1,'admin',1,NULL,'2025-12-17 16:47:31.360','2025-11-24 16:55:26.112','2025-11-24 16:55:26.112','2025-12-16 20:10:09.264'),(2,1,'operador',1,1,'2025-12-17 20:09:53.739','2025-12-17 20:12:32.862','2025-12-17 20:09:53.740','2025-12-17 20:12:32.864'),(2,2,'gestor',1,NULL,'2025-12-17 16:47:31.360','2025-11-27 16:52:28.553','2025-11-27 16:52:28.553','2025-12-18 10:31:56.931');
/*!40000 ALTER TABLE `user_tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_secret` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `email_verificado` tinyint(1) NOT NULL DEFAULT '0',
  `ultimo_login` datetime(3) DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `verification_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_code_expires_at` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_uuid_key` (`uuid`),
  UNIQUE KEY `users_email_key` (`email`),
  KEY `users_email_idx` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'904b2503-71d9-443f-9f4e-904c3e079912','Demo Owner','owner@demo.com','$2a$10$V6Xt/4z/ldsiGsrUjoo6reJlbdPENCaXkTxi5XdEhRER7PVeo5T.C',NULL,0,1,NULL,'2025-11-24 16:55:26.112','2025-12-16 20:10:09.264',NULL,NULL),(2,'2612cacb-8b3c-4a1d-a790-5fbc6c3aef77','Nuno Rogerio','nuno_rogerio@hotmail.com','$2a$10$jh2nh/VMrorPOjbe83j9X.AHOtPkbuzmodmzb3w7iyzfBhgY5OAoS',NULL,0,1,NULL,'2025-11-27 16:52:28.553','2025-12-17 20:12:32.864',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `variacoes_produto`
--

DROP TABLE IF EXISTS `variacoes_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variacoes_produto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `produto_id` int NOT NULL,
  `tipo_unidade_compra` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `unidades_por_compra` decimal(10,4) NOT NULL,
  `preco_compra` decimal(10,2) NOT NULL,
  `preco_unitario` decimal(10,4) NOT NULL,
  `fornecedor` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_fornecedor` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data_ultima_compra` datetime(3) DEFAULT NULL,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `template_id` int DEFAULT NULL,
  `volume_por_unidade` decimal(10,4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variacoes_produto_tenant_id_fkey` (`tenant_id`),
  KEY `variacoes_produto_produto_id_fkey` (`produto_id`),
  KEY `variacoes_produto_template_id_fkey` (`template_id`),
  CONSTRAINT `variacoes_produto_produto_id_fkey` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `variacoes_produto_template_id_fkey` FOREIGN KEY (`template_id`) REFERENCES `template_variacao_compra` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `variacoes_produto_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variacoes_produto`
--

LOCK TABLES `variacoes_produto` WRITE;
/*!40000 ALTER TABLE `variacoes_produto` DISABLE KEYS */;
INSERT INTO `variacoes_produto` VALUES (1,1,1,'Por KG',1.0000,13.60,13.6000,'','',NULL,1,'2025-11-24 17:06:02.877','2025-11-26 13:04:50.017',NULL,NULL),(2,1,2,'Por KG',1.0000,14.00,14.0000,'','',NULL,1,'2025-11-24 17:06:02.897','2025-11-25 20:18:37.355',NULL,NULL),(3,1,3,'Por KG',1.0000,18.00,18.0000,'','',NULL,1,'2025-11-24 17:06:02.910','2025-11-25 19:54:22.681',NULL,NULL),(4,1,4,'Por KG',1.0000,16.50,16.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:02.923','2025-11-24 17:06:02.923',NULL,NULL),(5,1,5,'Por KG',1.0000,13.90,13.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:02.941','2025-11-24 17:06:02.941',NULL,NULL),(6,1,6,'Por KG',1.0000,10.50,10.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:02.954','2025-11-24 17:06:02.954',NULL,NULL),(7,1,7,'Por KG',1.0000,15.80,15.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:02.975','2025-11-24 17:06:02.975',NULL,NULL),(8,1,8,'Por KG',1.0000,28.50,28.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:02.987','2025-11-24 17:06:02.987',NULL,NULL),(9,1,9,'Por KG',1.0000,6.80,6.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.005','2025-11-24 17:06:03.005',NULL,NULL),(10,1,10,'Por KG',1.0000,5.50,5.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.022','2025-11-24 17:06:03.022',NULL,NULL),(11,1,11,'Por KG',1.0000,4.90,4.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.036','2025-11-24 17:06:03.036',NULL,NULL),(12,1,12,'Por KG',1.0000,5.20,5.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.052','2025-11-24 17:06:03.052',NULL,NULL),(13,1,13,'Por KG',1.0000,5.80,5.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.081','2025-11-24 17:06:03.081',NULL,NULL),(14,1,14,'Por KG',1.0000,4.20,4.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.104','2025-11-24 17:06:03.104',NULL,NULL),(15,1,15,'Por KG',1.0000,3.80,3.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.119','2025-11-24 17:06:03.119',NULL,NULL),(16,1,16,'Por KG',1.0000,4.50,4.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.132','2025-11-24 17:06:03.132',NULL,NULL),(17,1,17,'Por KG',1.0000,8.90,8.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.145','2025-11-24 17:06:03.145',NULL,NULL),(18,1,18,'Por KG',1.0000,12.50,12.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.158','2025-11-24 17:06:03.158',NULL,NULL),(19,1,19,'Por KG',1.0000,22.50,22.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.187','2025-11-24 17:06:03.187',NULL,NULL),(20,1,20,'Por KG',1.0000,18.90,18.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.204','2025-11-24 17:06:03.204',NULL,NULL),(21,1,21,'Por KG',1.0000,14.50,14.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.219','2025-11-24 17:06:03.219',NULL,NULL),(22,1,22,'Por KG',1.0000,16.80,16.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.236','2025-11-24 17:06:03.236',NULL,NULL),(23,1,23,'Por KG',1.0000,15.50,15.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.247','2025-11-24 17:06:03.247',NULL,NULL),(24,1,24,'Por KG',1.0000,12.30,12.3000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.260','2025-11-24 17:06:03.260',NULL,NULL),(25,1,25,'Por KG',1.0000,18.90,18.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.273','2025-11-24 17:06:03.273',NULL,NULL),(26,1,26,'Por KG',1.0000,14.90,14.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.300','2025-11-24 17:06:03.300',NULL,NULL),(27,1,27,'Por KG',1.0000,19.50,19.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.315','2025-11-24 17:06:03.315',NULL,NULL),(28,1,28,'Por KG',1.0000,4.80,4.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.346','2025-11-24 17:06:03.346',NULL,NULL),(29,1,29,'Por KG',1.0000,5.20,5.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.362','2025-11-24 17:06:03.362',NULL,NULL),(30,1,30,'Por KG',1.0000,18.50,18.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.390','2025-11-24 17:06:03.390',NULL,NULL),(31,1,31,'Por KG',1.0000,8.90,8.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.417','2025-11-24 17:06:03.417',NULL,NULL),(32,1,32,'Por KG',1.0000,6.50,6.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.435','2025-11-24 17:06:03.435',NULL,NULL),(33,1,33,'Por KG',1.0000,16.80,16.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.460','2025-11-24 17:06:03.460',NULL,NULL),(34,1,34,'Por KG',1.0000,12.50,12.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.512','2025-11-24 17:06:03.512',NULL,NULL),(35,1,35,'Por KG',1.0000,0.85,0.8500,NULL,NULL,NULL,1,'2025-11-24 17:06:03.536','2025-11-24 17:06:03.536',NULL,NULL),(36,1,36,'Por KG',1.0000,0.64,0.6400,NULL,NULL,NULL,1,'2025-11-24 17:06:03.553','2025-12-15 16:22:28.323',NULL,NULL),(37,1,37,'Por KG',1.0000,0.75,0.7500,NULL,NULL,NULL,1,'2025-11-24 17:06:03.570','2025-11-24 17:06:03.570',NULL,NULL),(38,1,38,'Por KG',1.0000,6.50,6.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.581','2025-11-24 17:06:03.581',NULL,NULL),(39,1,39,'Por KG',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.604','2025-11-24 17:06:03.604',NULL,NULL),(40,1,40,'Por Unidade',1.0000,0.99,0.9900,NULL,NULL,NULL,1,'2025-11-24 17:06:03.621','2025-12-15 16:22:28.278',NULL,NULL),(41,1,41,'Por KG',1.0000,3.20,3.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.635','2025-11-24 17:06:03.635',NULL,NULL),(42,1,42,'Por KG',1.0000,1.50,1.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.652','2025-11-24 17:06:03.652',NULL,NULL),(43,1,43,'Por KG',1.0000,4.50,4.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.664','2025-11-24 17:06:03.664',NULL,NULL),(44,1,44,'Por KG',1.0000,0.89,0.8900,NULL,NULL,NULL,1,'2025-11-24 17:06:03.685','2025-12-15 16:22:28.268',NULL,NULL),(45,1,45,'Por KG',1.0000,2.44,2.4400,NULL,NULL,NULL,1,'2025-11-24 17:06:03.699','2025-12-15 16:22:28.344',NULL,NULL),(46,1,46,'Por KG',1.0000,1.95,1.9500,NULL,NULL,NULL,1,'2025-11-24 17:06:03.717','2025-11-24 17:06:03.717',NULL,NULL),(47,1,47,'Por KG',1.0000,1.60,1.6000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.754','2025-11-24 17:06:03.754',NULL,NULL),(48,1,48,'Por KG',1.0000,1.20,1.2000,'','',NULL,1,'2025-11-24 17:06:03.784','2025-12-03 09:25:38.402',NULL,NULL),(49,1,49,'Por KG',1.0000,3.50,3.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.820','2025-11-24 17:06:03.820',NULL,NULL),(50,1,50,'Por KG',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.844','2025-11-24 17:06:03.844',NULL,NULL),(51,1,51,'Por KG',1.0000,2.50,2.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.862','2025-11-24 17:06:03.862',NULL,NULL),(52,1,52,'Por KG',1.0000,2.20,2.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.876','2025-11-24 17:06:03.876',NULL,NULL),(53,1,53,'Por L',1.0000,0.95,0.9500,NULL,NULL,NULL,1,'2025-11-24 17:06:03.903','2025-11-24 17:06:03.903',NULL,NULL),(54,1,54,'Por L',1.0000,0.98,0.9800,NULL,NULL,NULL,1,'2025-11-24 17:06:03.936','2025-11-24 17:06:03.936',NULL,NULL),(55,1,55,'Por L',1.0000,3.50,3.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:03.951','2025-11-24 17:06:03.951',NULL,NULL),(56,1,56,'Por KG',1.0000,8.50,8.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.000','2025-11-24 17:06:04.000',NULL,NULL),(57,1,57,'Por KG',1.0000,15.80,15.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.040','2025-11-24 17:06:04.040',NULL,NULL),(58,1,58,'Por KG',1.0000,22.50,22.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.078','2025-11-24 17:06:04.078',NULL,NULL),(59,1,59,'Por KG',1.0000,6.20,6.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.105','2025-11-24 17:06:04.105',NULL,NULL),(60,1,60,'Por KG',1.0000,5.80,5.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.121','2025-11-24 17:06:04.121',NULL,NULL),(61,1,61,'Por L',1.0000,2.50,2.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.143','2025-11-24 17:06:04.143',NULL,NULL),(62,1,62,'Por KG',1.0000,4.80,4.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.156','2025-11-24 17:06:04.156',NULL,NULL),(63,1,63,'Por KG',1.0000,7.50,7.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.178','2025-11-24 17:06:04.178',NULL,NULL),(64,1,64,'Por KG',1.0000,7.80,7.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.193','2025-11-24 17:06:04.193',NULL,NULL),(65,1,65,'Por KG',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.224','2025-11-24 17:06:04.224',NULL,NULL),(66,1,66,'Por KG',1.0000,1.50,1.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.237','2025-11-24 17:06:04.237',NULL,NULL),(67,1,67,'Por KG',1.0000,0.85,0.8500,NULL,NULL,NULL,1,'2025-11-24 17:06:04.250','2025-11-24 17:06:04.250',NULL,NULL),(68,1,68,'Por KG',1.0000,2.20,2.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.266','2025-11-24 17:06:04.266',NULL,NULL),(69,1,69,'Por L',1.0000,8.50,8.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.287','2025-11-24 17:06:04.287',NULL,NULL),(70,1,70,'Por L',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.305','2025-11-24 17:06:04.305',NULL,NULL),(71,1,71,'Por KG',1.0000,0.60,0.6000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.327','2025-11-24 17:06:04.327',NULL,NULL),(72,1,72,'Por KG',1.0000,12.50,12.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.347','2025-11-24 17:06:04.347',NULL,NULL),(73,1,73,'Por KG',1.0000,0.95,0.9500,NULL,NULL,NULL,1,'2025-11-24 17:06:04.361','2025-11-24 17:06:04.361',NULL,NULL),(74,1,74,'Por L',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.376','2025-11-24 17:06:04.376',NULL,NULL),(75,1,75,'Por KG',1.0000,1.80,1.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.396','2025-11-24 17:06:04.396',NULL,NULL),(76,1,76,'Por KG',1.0000,3.50,3.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.407','2025-11-24 17:06:04.407',NULL,NULL),(77,1,77,'Por KG',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.423','2025-11-24 17:06:04.423',NULL,NULL),(78,1,78,'Por KG',1.0000,4.20,4.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.437','2025-11-24 17:06:04.437',NULL,NULL),(79,1,79,'Por L',1.0000,1.50,1.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.466','2025-11-24 17:06:04.466',NULL,NULL),(80,1,80,'Por L',1.0000,1.50,1.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.484','2025-11-24 17:06:04.484',NULL,NULL),(81,1,81,'Por L',1.0000,1.50,1.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.496','2025-11-24 17:06:04.496',NULL,NULL),(82,1,82,'Por L',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.517','2025-11-24 17:06:04.517',NULL,NULL),(83,1,83,'Por L',1.0000,2.50,2.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.534','2025-11-24 17:06:04.534',NULL,NULL),(84,1,84,'Por L',1.0000,0.50,0.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.557','2025-11-24 17:06:04.557',NULL,NULL),(85,1,85,'Por L',1.0000,0.65,0.6500,NULL,NULL,NULL,1,'2025-11-24 17:06:04.570','2025-11-24 17:06:04.570',NULL,NULL),(86,1,86,'Por L',1.0000,7.50,7.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.587','2025-11-24 17:06:04.587',NULL,NULL),(87,1,87,'Por L',1.0000,6.80,6.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.607','2025-11-24 17:06:04.607',NULL,NULL),(88,1,88,'Por L',1.0000,5.50,5.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.643','2025-11-24 17:06:04.643',NULL,NULL),(89,1,89,'Por L',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.678','2025-11-24 17:06:04.678',NULL,NULL),(90,1,90,'Por L',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:04.712','2025-11-24 17:06:04.712',NULL,NULL),(91,1,91,'Por KG',1.0000,4.50,4.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.117','2025-11-24 17:06:05.117',NULL,NULL),(92,1,92,'Por KG',1.0000,12.80,12.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.129','2025-11-24 17:06:05.129',NULL,NULL),(93,1,93,'Por KG',1.0000,18.50,18.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.143','2025-11-24 17:06:05.143',NULL,NULL),(94,1,94,'Por KG',1.0000,24.00,24.0000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.155','2025-11-24 17:06:05.155',NULL,NULL),(95,1,95,'Por KG',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.172','2025-11-24 17:06:05.172',NULL,NULL),(96,1,96,'Por KG',1.0000,2.50,2.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.186','2025-11-24 17:06:05.186',NULL,NULL),(97,1,97,'Por KG',1.0000,1.20,1.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.206','2025-11-24 17:06:05.206',NULL,NULL),(98,1,98,'Por KG',1.0000,0.99,0.9900,NULL,NULL,NULL,1,'2025-11-24 17:06:05.244','2025-12-15 16:51:03.894',NULL,NULL),(99,1,99,'Por KG',1.0000,1.40,1.4000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.279','2025-11-24 17:06:05.279',NULL,NULL),(100,1,100,'Por KG',1.0000,8.90,8.9000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.292','2025-11-24 17:06:05.292',NULL,NULL),(101,1,101,'Por KG',1.0000,7.50,7.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.307','2025-11-24 17:06:05.307',NULL,NULL),(102,1,102,'Por KG',1.0000,18.50,18.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.324','2025-11-24 17:06:05.324',NULL,NULL),(103,1,103,'Por KG',1.0000,3.20,3.2000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.339','2025-11-24 17:06:05.339',NULL,NULL),(104,1,104,'Por L',1.0000,12.50,12.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.354','2025-11-24 17:06:05.354',NULL,NULL),(105,1,105,'Por KG',1.0000,8.50,8.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.370','2025-11-24 17:06:05.370',NULL,NULL),(106,1,106,'Por KG',1.0000,12.00,12.0000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.391','2025-11-24 17:06:05.391',NULL,NULL),(107,1,107,'Por KG',1.0000,2.80,2.8000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.407','2025-11-24 17:06:05.407',NULL,NULL),(108,1,108,'Por KG',1.0000,8.50,8.5000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.427','2025-11-24 17:06:05.427',NULL,NULL),(109,1,109,'Por KG',1.0000,15.00,15.0000,NULL,NULL,NULL,1,'2025-11-24 17:06:05.441','2025-11-24 17:06:05.441',NULL,NULL),(110,1,110,'caixa 24',24.0000,6.00,0.2500,'Continente',NULL,NULL,1,'2025-12-01 19:06:26.980','2025-12-01 19:06:26.980',NULL,NULL),(111,1,73,'Caixa 10kg',10.0000,8.80,0.8800,'','',NULL,1,'2025-12-03 10:33:27.573','2025-12-03 14:52:13.007',21,NULL),(112,1,35,'Saco 10kg',10.0000,23.00,2.3000,'','','2025-12-04 21:10:08.174',1,'2025-12-04 21:10:08.175','2025-12-04 21:55:52.672',17,NULL),(113,1,111,'Garrafa 0,75',0.7500,8.24,10.9867,'',NULL,NULL,1,'2025-12-09 12:29:59.839','2025-12-09 12:29:59.839',NULL,NULL),(114,1,112,'Garrafa 0,75',0.7500,8.99,11.9867,'',NULL,NULL,1,'2025-12-09 17:26:21.831','2025-12-09 17:26:21.831',NULL,NULL),(115,1,113,'caixa 4kg',4.0000,7.35,7.3500,NULL,NULL,NULL,1,'2025-12-12 14:52:42.873','2025-12-12 15:12:49.431',NULL,NULL),(116,1,114,'caixa 2kg',2.0000,7.25,7.2500,NULL,NULL,NULL,1,'2025-12-12 14:54:17.527','2025-12-12 15:12:49.441',NULL,NULL),(117,1,115,'1 KG',1.0000,6.35,6.3500,NULL,NULL,NULL,1,'2025-12-12 15:00:33.431','2025-12-12 15:12:49.448',NULL,NULL),(118,1,116,'1 KG',1.0000,5.95,5.9500,NULL,NULL,NULL,1,'2025-12-12 15:01:45.791','2025-12-12 15:12:49.456',NULL,NULL),(119,1,117,'saco 800g',0.8000,8.50,8.5000,NULL,NULL,NULL,1,'2025-12-12 15:05:30.726','2025-12-12 15:12:49.464',NULL,NULL),(120,1,118,'saco 20un',20.0000,2.75,2.7500,NULL,NULL,NULL,1,'2025-12-12 15:07:29.488','2025-12-12 15:12:49.472',NULL,NULL),(121,1,119,'caixa 7,5 kg',7.5000,9.50,9.5000,NULL,NULL,NULL,1,'2025-12-12 15:09:50.674','2025-12-12 15:12:49.478',NULL,NULL),(122,1,120,'2.5 KG',2.5000,3.55,3.5500,NULL,NULL,NULL,1,'2025-12-12 15:12:40.593','2025-12-12 15:12:49.485',NULL,NULL),(123,1,89,'Garrafa 33cl',1.0000,0.60,0.6000,'','','2025-12-15 09:27:48.556',1,'2025-12-15 09:27:48.557','2025-12-15 15:17:23.366',13,0.3300),(124,1,89,'Grade 24x25cl ',24.0000,17.20,0.7167,'','','2025-12-15 14:58:14.282',1,'2025-12-15 14:58:14.283','2025-12-15 15:44:50.763',NULL,0.2500);
/*!40000 ALTER TABLE `variacoes_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vendas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tenant_id` int NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_venda` datetime(3) NOT NULL,
  `hora_venda` datetime(3) DEFAULT NULL,
  `menu_item_id` int DEFAULT NULL,
  `quantidade` int NOT NULL DEFAULT '1',
  `pvp_praticado` decimal(10,2) NOT NULL,
  `desconto_percentual` decimal(5,2) DEFAULT NULL,
  `desconto_valor` decimal(10,2) DEFAULT NULL,
  `receita_total` decimal(10,2) NOT NULL,
  `custo_total` decimal(10,2) DEFAULT NULL,
  `margem_bruta` decimal(10,2) DEFAULT NULL,
  `metodo_entrada` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `pos_transacao_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mesa` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colaborador` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacoes` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `tipo` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ITEM',
  PRIMARY KEY (`id`),
  KEY `vendas_user_id_fkey` (`user_id`),
  KEY `vendas_menu_item_id_fkey` (`menu_item_id`),
  KEY `vendas_tenant_id_data_venda_idx` (`tenant_id`,`data_venda`),
  CONSTRAINT `vendas_menu_item_id_fkey` FOREIGN KEY (`menu_item_id`) REFERENCES `menu` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `vendas_tenant_id_fkey` FOREIGN KEY (`tenant_id`) REFERENCES `tenants` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `vendas_user_id_fkey` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendas`
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
INSERT INTO `vendas` VALUES (1,1,'e2195df6-3f8f-49f0-9a6a-f1226a00b359','2025-11-25 00:00:00.000',NULL,1,12,9.00,NULL,NULL,108.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de inverno mas com sol',NULL,'2025-11-26 15:00:37.385','ITEM'),(2,1,'e575ff37-1c01-4984-b74c-a4f9564f9641','2025-11-25 00:00:00.000',NULL,3,6,13.50,NULL,NULL,81.00,NULL,NULL,'Manual',NULL,NULL,NULL,'',NULL,'2025-11-26 15:01:24.692','ITEM'),(3,1,'6fa190ad-5e3e-4d7a-b0c5-bbbf28c24017','2025-11-25 00:00:00.000',NULL,4,3,3.50,NULL,NULL,10.50,NULL,NULL,'Manual',NULL,NULL,NULL,'',NULL,'2025-11-26 15:04:01.303','ITEM'),(4,1,'6d2c8c55-1fc1-447f-9775-96906a34d670','2025-11-25 00:00:00.000',NULL,5,4,6.00,NULL,NULL,24.00,NULL,NULL,'Manual',NULL,NULL,NULL,'',NULL,'2025-11-26 15:04:01.307','ITEM'),(5,1,'e8cc09a9-adac-450f-b6b2-285bfaed133d','2025-11-25 00:00:00.000',NULL,2,8,13.00,NULL,NULL,104.00,NULL,NULL,'Manual',NULL,NULL,NULL,'',NULL,'2025-11-26 15:04:01.314','ITEM'),(6,1,'64c47a49-bb8e-431c-8478-ceddca92a989','2025-11-26 00:00:00.000',NULL,2,14,13.00,NULL,NULL,182.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de sol mas com muito frio, Jogo do sporting na Liga dos campeoes',NULL,'2025-11-27 10:00:45.375','ITEM'),(7,1,'eb5eb44c-45bb-4623-8752-f8a751540042','2025-11-26 00:00:00.000',NULL,5,10,6.00,NULL,NULL,60.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de sol mas com muito frio, Jogo do sporting na Liga dos campeoes',NULL,'2025-11-27 10:00:45.382','ITEM'),(8,1,'b0a76838-4313-41a0-b134-52e221496063','2025-11-26 00:00:00.000',NULL,3,9,13.50,NULL,NULL,121.50,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de sol mas com muito frio, Jogo do sporting na Liga dos campeoes',NULL,'2025-11-27 10:00:45.387','ITEM'),(9,1,'4bde39ad-59bc-41a6-aa3b-530c86edca5b','2025-11-26 00:00:00.000',NULL,4,8,3.50,NULL,NULL,28.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de sol mas com muito frio, Jogo do sporting na Liga dos campeoes',NULL,'2025-11-27 10:00:45.391','ITEM'),(10,1,'98663355-0af6-436b-8bd6-9c26ef6defc6','2025-11-26 00:00:00.000',NULL,1,5,9.00,NULL,NULL,45.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia de sol mas com muito frio, Jogo do sporting na Liga dos campeoes',NULL,'2025-11-27 10:00:45.393','ITEM'),(11,1,'8090ab43-0966-4f42-b6aa-e022a54f234a','2025-11-28 00:00:00.000',NULL,1,12,9.00,NULL,NULL,108.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia frio com chuva',NULL,'2025-12-01 15:06:02.337','ITEM'),(12,1,'0f3b4f03-285d-4f56-837f-efdaf8e81ed5','2025-11-28 00:00:00.000',NULL,3,4,13.50,NULL,NULL,54.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia frio com chuva',NULL,'2025-12-01 15:06:02.344','ITEM'),(13,1,'aa218b4d-2912-4db4-8560-f89c3db641b3','2025-11-28 00:00:00.000',NULL,2,7,13.00,NULL,NULL,91.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia frio com chuva',NULL,'2025-12-01 15:06:02.349','ITEM'),(14,1,'7e34f516-efa4-4343-9b61-b7cd1bca9bd1','2025-11-28 00:00:00.000',NULL,5,10,6.00,NULL,NULL,60.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia frio com chuva',NULL,'2025-12-01 15:06:02.355','ITEM'),(15,1,'8e9cbfc9-beba-4286-89e9-28ce75a0a51f','2025-11-28 00:00:00.000',NULL,4,7,3.50,NULL,NULL,24.50,NULL,NULL,'Manual',NULL,NULL,NULL,'Dia frio com chuva',NULL,'2025-12-01 15:06:02.358','ITEM'),(16,1,'df3854dc-759c-4ed6-bdd4-c4465d283948','2025-11-28 00:00:00.000',NULL,6,12,13.50,NULL,NULL,162.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Fim de semana com pouco movimento, fim de semana prolongado com o feriado de 1 Dezembo',NULL,'2025-12-01 18:33:55.768','ITEM'),(17,1,'7bff69cf-b820-4bba-b554-2f3a1d1ac008','2025-11-28 00:00:00.000',NULL,2,15,13.00,NULL,NULL,195.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Fim de semana com pouco movimento, fim de semana prolongado com o feriado de 1 Dezembo',NULL,'2025-12-01 18:33:55.786','ITEM'),(18,1,'46db5763-5f51-4a5c-9307-97dc0b2d28dc','2025-12-01 00:00:00.000',NULL,1,5,9.00,NULL,NULL,45.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Feriado Nacional, com chuva no final do dia',NULL,'2025-12-02 09:58:54.420','ITEM'),(19,1,'fddc7691-ed32-440c-ac1f-5dd1b88dbac1','2025-12-01 00:00:00.000',NULL,6,9,13.50,NULL,NULL,121.50,NULL,NULL,'Manual',NULL,NULL,NULL,'Feriado Nacional, com chuva no final do dia',NULL,'2025-12-02 09:58:54.429','ITEM'),(20,1,'01986d93-6dbd-4f21-bf56-76b0c08eb1e1','2025-12-01 00:00:00.000',NULL,2,12,13.00,NULL,NULL,156.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Feriado Nacional, com chuva no final do dia',NULL,'2025-12-02 09:58:54.434','ITEM'),(21,1,'283f0012-a136-42a3-8233-b0e634760e78','2025-12-01 00:00:00.000',NULL,4,3,3.50,NULL,NULL,10.50,NULL,NULL,'Manual',NULL,NULL,NULL,'Feriado Nacional, com chuva no final do dia',NULL,'2025-12-02 09:58:54.441','ITEM'),(22,1,'eadaaa2a-0b8b-45b4-b113-4e4de7c35c78','2025-12-02 00:00:00.000',NULL,8,15,2.00,NULL,NULL,30.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.134','ITEM'),(23,1,'4470cf2f-996e-415a-a8a7-728a46356e1a','2025-12-02 00:00:00.000',NULL,1,10,9.00,NULL,NULL,90.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.177','ITEM'),(24,1,'318cba2a-a5e8-40a6-97f5-4516605e68c8','2025-12-02 00:00:00.000',NULL,2,12,13.00,NULL,NULL,156.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.181','ITEM'),(25,1,'1ab76809-6a61-42b1-a04e-e046b1169949','2025-12-02 00:00:00.000',NULL,6,10,13.50,NULL,NULL,135.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.185','ITEM'),(26,1,'df8ed1ec-36c1-4c9b-856c-58690399ee76','2025-12-02 00:00:00.000',NULL,3,8,13.50,NULL,NULL,108.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.192','ITEM'),(27,1,'a712decd-17d3-439e-bd4d-956dfabe4a92','2025-12-02 00:00:00.000',NULL,5,10,6.00,NULL,NULL,60.00,NULL,NULL,'Manual',NULL,NULL,NULL,'Frio e Neve',NULL,'2025-12-03 19:55:01.196','ITEM');
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'rcm_db'
--

--
-- Dumping routines for database 'rcm_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-18 13:07:32
